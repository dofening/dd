import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { icuFoliaDataPlugin } from './upstream/dev/icuFolia/icuFoliaDataPlugin.mjs';
import { commandPinyinPlugin } from './upstream/dev/pinyin/commandPinyinPlugin.mjs';
import { traditionalLocalePlugin } from './upstream/dev/i18n/traditionalLocalePlugin.mjs';
import tailwind from '@tailwindcss/postcss';
import path from 'node:path';

export default defineConfig({
  base: './',
  plugins: [react(), icuFoliaDataPlugin(), commandPinyinPlugin(), traditionalLocalePlugin()],
  resolve: { alias: { '@': path.resolve(import.meta.dirname, 'upstream/src') } },
  css: { postcss: { plugins: [tailwind()] } },
  worker: { format: 'es' },
  build: { target: 'es2020', chunkSizeWarningLimit: 2000 },
  define: {
    __COMMIT_HASH__: JSON.stringify('folia-spotify-local'), __GIT_BRANCH__: JSON.stringify('local'),
    __BUILD_REPO__: JSON.stringify('chthollyphile/folia-major'), __BUILD_COMMIT__: JSON.stringify('0fc687372e3b83f85f474df51446a9d35cc52b10'),
    __BUILD_KIND__: JSON.stringify('unofficial'), __BUILD_HOST__: JSON.stringify(''),
    __APP_VERSION__: JSON.stringify('1.0.0'), __APP_VERSION_LABEL__: JSON.stringify('Folia Spotify 歌词'),
    __APP_RELEASE_CHANNEL__: JSON.stringify('local'), __DOCKER_STACK_VERSION__: JSON.stringify(''),
  },
});
