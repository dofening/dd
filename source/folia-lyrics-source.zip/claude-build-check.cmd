@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "NODE=E:\Program Files\nodejs\node.exe"
set "LOG=%~dp0claude-build-check.log"
echo [%date% %time%] build > "%LOG%"
"%NODE%" build.mjs >> "%LOG%" 2>&1
if errorlevel 1 (echo BUILD_FAILED>>"%LOG%" & goto :end)
echo [standalone] >> "%LOG%"
"%NODE%" build-standalone.mjs >> "%LOG%" 2>&1
if errorlevel 1 (echo STANDALONE_BUILD_FAILED>>"%LOG%" & goto :end)
echo [tests] >> "%LOG%"
"%NODE%" --test tests/lyrics.test.mjs tests/spotify.test.mjs >> "%LOG%" 2>&1
if errorlevel 1 (echo UNIT_TESTS_FAILED>>"%LOG%" & goto :end)
echo [integration] >> "%LOG%"
start "folia-qa" /min cmd /c "set FOLIA_PORT=18982&& set FOLIA_STATIC_DIR=dist-next&& "%NODE%" server.mjs > qa-runtime.out.log 2> qa-runtime.err.log"
ping -n 4 127.0.0.1 >nul
"%NODE%" tests\integration-ui.cjs >> "%LOG%" 2>&1
if errorlevel 1 (echo INTEGRATION_FAILED>>"%LOG%") else (echo INTEGRATION_PASSED>>"%LOG%")
"%NODE%" -e "fetch('http://127.0.0.1:18982/api/shutdown',{method:'POST',headers:{'Content-Type':'application/json'}}).catch(()=>{})" >nul 2>&1
echo [android] >> "%LOG%"
call "%~dp0android\build-apk.cmd"
type "%~dp0android\build-apk.log" >> "%LOG%"
:end
echo DONE>>"%LOG%"
