import { readFileSync } from 'node:fs';
import path from 'node:path';
import base from './vite.config.mjs';

// 手机 / 平板独立版：同一套界面，/api/* 改由页面内的 standalone/backend.ts 处理，不需要电脑。
// Spotify 应用标识是公开的 Client ID（授权用 PKCE，不含 Client Secret）。
const clientId = JSON.parse(readFileSync(path.join(import.meta.dirname, 'data', 'spotify-app.json'), 'utf8')).clientId;
if (!/^[a-f0-9]{32}$/i.test(clientId)) throw new Error('data/spotify-app.json 里没有有效的 Spotify Client ID');

export default {
  ...base,
  publicDir: 'standalone/public',
  resolve: { alias: { ...base.resolve.alias, 'node:crypto': path.resolve(import.meta.dirname, 'standalone/node-crypto.ts') } },
  define: { ...base.define, 'import.meta.env.VITE_FOLIA_STANDALONE': JSON.stringify('1'), 'import.meta.env.VITE_SPOTIFY_CLIENT_ID': JSON.stringify(clientId) },
  build: { ...base.build, outDir: 'dist-standalone', emptyOutDir: true, rollupOptions: { input: path.resolve(import.meta.dirname, 'standalone.html') } },
};
