using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

[assembly: AssemblyTitle("Spotify 歌词动画")]
[assembly: AssemblyProduct("Spotify 歌词动画")]
[assembly: AssemblyCompany("wzx")]
[assembly: AssemblyVersion("1.1.0.0")]

static class Program
{
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] static extern bool SetDllDirectory(string path);
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr window, int command);
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr window);
    [STAThread]
    static void Main(string[] args)
    {
        bool created;
        using (Mutex instance = new Mutex(true, "Local\\FoliaSpotifyLyricsDesktop", out created))
        {
            if (!created)
            {
                foreach (Process process in Process.GetProcessesByName(Path.GetFileNameWithoutExtension(Application.ExecutablePath)))
                    if (process.MainWindowHandle != IntPtr.Zero) { ShowWindow(process.MainWindowHandle, 9); SetForegroundWindow(process.MainWindowHandle); break; }
                return;
            }
            string native = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "native");
            SetDllDirectory(native);
            AppDomain.CurrentDomain.AssemblyResolve += delegate(object sender, ResolveEventArgs eventArgs)
            {
                string file = Path.Combine(native, new AssemblyName(eventArgs.Name).Name + ".dll");
                return File.Exists(file) ? Assembly.LoadFrom(file) : null;
            };
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LyricsWindow(Array.IndexOf(args, "--verify") >= 0));
        }
    }
}

sealed class LyricsWindow : Form
{
    readonly string root = AppDomain.CurrentDomain.BaseDirectory;
    readonly Uri home = new Uri("http://127.0.0.1:18981/");
    readonly HttpClient http = new HttpClient { Timeout = TimeSpan.FromSeconds(2) };
    readonly bool verify;
    WebView2 view;
    Process server;
    bool ownsServer;
    bool closing;
    Rectangle previousBounds;
    FormWindowState previousState;

    public LyricsWindow(bool verification)
    {
        verify = verification;
        Text = "Spotify 歌词动画";
        ClientSize = new Size(1280, 800);
        MinimumSize = new Size(680, 480);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(11, 16, 27);
        string icon = Path.Combine(root, "spotify.ico");
        if (File.Exists(icon)) Icon = new Icon(icon);
        Shown += async delegate { await Start(); };
        FormClosing += delegate { Cleanup(); };
    }
    async Task<bool> ServiceAvailable()
    {
        try { return (await http.GetStringAsync(new Uri(home, "api/health"))).Contains("folia-spotify-lyrics"); }
        catch { return false; }
    }
    async Task Start()
    {
        try
        {
            if (!await ServiceAvailable())
            {
                ProcessStartInfo start = new ProcessStartInfo(Path.Combine(root, "runtime", "node.exe"), "\"" + Path.Combine(root, "server.mjs") + "\"");
                start.WorkingDirectory = root;
                start.UseShellExecute = false;
                start.CreateNoWindow = true;
                start.RedirectStandardOutput = true;
                start.RedirectStandardError = true;
                server = new Process { StartInfo = start, EnableRaisingEvents = true };
                server.OutputDataReceived += delegate { };
                server.ErrorDataReceived += delegate { };
                server.Exited += delegate { if (!closing && IsHandleCreated) BeginInvoke((Action)delegate { Close(); }); };
                server.Start(); server.BeginOutputReadLine(); server.BeginErrorReadLine(); ownsServer = true;
                bool ready = false;
                for (int attempt = 0; attempt < 30; attempt++)
                {
                    await Task.Delay(200);
                    if (await ServiceAvailable()) { ready = true; break; }
                }
                if (!ready) throw new Exception("本机播放服务暂时无法启动，请重新打开软件。");
            }
            Directory.CreateDirectory(Path.Combine(root, "data"));
            view = new WebView2 { Dock = DockStyle.Fill, DefaultBackgroundColor = BackColor };
            Controls.Add(view);
            CoreWebView2Environment environment = await CoreWebView2Environment.CreateAsync(null, Path.Combine(root, "data", "webview"), null);
            await view.EnsureCoreWebView2Async(environment);
            view.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
            view.CoreWebView2.Settings.AreDevToolsEnabled = false;
            view.CoreWebView2.Settings.IsStatusBarEnabled = false;
            view.CoreWebView2.NavigationStarting += delegate(object sender, CoreWebView2NavigationStartingEventArgs e)
            {
                Uri destination;
                if (!Uri.TryCreate(e.Uri, UriKind.Absolute, out destination)) { e.Cancel = true; return; }
                if (destination.Scheme == "about") return;
                if (destination.Scheme == home.Scheme && destination.Host == home.Host && destination.Port == home.Port) return;
                e.Cancel = true;
                OpenAuthorization(destination);
            };
            view.CoreWebView2.NewWindowRequested += delegate(object sender, CoreWebView2NewWindowRequestedEventArgs e)
            {
                e.Handled = true;
                Uri destination;
                if (Uri.TryCreate(e.Uri, UriKind.Absolute, out destination)) OpenAuthorization(destination);
            };
            view.CoreWebView2.PermissionRequested += delegate(object sender, CoreWebView2PermissionRequestedEventArgs e) { e.State = CoreWebView2PermissionState.Deny; };
            view.CoreWebView2.ContainsFullScreenElementChanged += delegate
            {
                if (view.CoreWebView2.ContainsFullScreenElement)
                {
                    previousBounds = Bounds; previousState = WindowState;
                    WindowState = FormWindowState.Normal; FormBorderStyle = FormBorderStyle.None; WindowState = FormWindowState.Maximized;
                }
                else { WindowState = FormWindowState.Normal; FormBorderStyle = FormBorderStyle.Sizable; Bounds = previousBounds; WindowState = previousState; }
            };
            view.CoreWebView2.DOMContentLoaded += async delegate
            {
                File.WriteAllText(Path.Combine(root, "data", "native-status.json"), "{\"nativeWindow\":true,\"pageLoaded\":true,\"version\":\"1.1.0\"}");
                view.Focus();
                if (verify)
                {
                    await Task.Delay(3000);
                    using (FileStream output = File.Create(Path.Combine(root, "data", "native-preview.png")))
                        await view.CoreWebView2.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Png, output);
                    Close();
                }
            };
            view.CoreWebView2.Navigate(home.AbsoluteUri);
        }
        catch (Exception error)
        {
            File.WriteAllText(Path.Combine(root, "native-start-error.txt"), error.GetType().Name + ": " + error.Message);
            MessageBox.Show("软件暂时无法启动。请查看运行环境后重试。", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            Close();
        }
    }
    void OpenAuthorization(Uri destination)
    {
        // 播放控制永远留在本窗口；只有用户主动连接账号时打开官方授权页。
        if (destination.Scheme != "https") return;
        if (destination.Host != "accounts.spotify.com" && destination.Host != "developer.spotify.com") return;
        Process.Start(new ProcessStartInfo(destination.AbsoluteUri) { UseShellExecute = true });
    }
    void Cleanup()
    {
        if (closing) return;
        closing = true;
        if (ownsServer)
        {
            try { http.PostAsync(new Uri(home, "api/shutdown"), new StringContent("{}", System.Text.Encoding.UTF8, "application/json")).Wait(1000); }
            catch { }
        }
        if (view != null) view.Dispose();
        http.Dispose();
        if (server != null) server.Dispose();
    }
}
