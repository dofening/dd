$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot
$release=Join-Path $root 'release\latest'
$package=Join-Path $root 'packaging-deps\webview2-1.0.4314.35'
foreach($folder in @($release,(Join-Path $release 'native'),(Join-Path $release 'runtime'),(Join-Path $release 'node_modules'),(Join-Path $release 'data'))){New-Item -ItemType Directory -Path $folder -Force|Out-Null}
foreach($file in @('server.mjs','spotify.mjs','lyrics.mjs','position.mjs','media-session.ps1','spotify.ico')){Copy-Item -LiteralPath (Join-Path $root $file) -Destination $release -Force}
[IO.File]::WriteAllText((Join-Path $release 'package.json'),'{"name":"folia-spotify-lyrics-desktop","type":"module","version":"1.1.0"}',(New-Object Text.UTF8Encoding($false)))
$releaseDist=[IO.Path]::GetFullPath((Join-Path $release 'dist'))
if($releaseDist -ne ([IO.Path]::GetFullPath($release)+'\dist')){throw '成品目录不符合预期'}
if(Test-Path -LiteralPath $releaseDist){
    if((Get-Item -LiteralPath $releaseDist).Attributes -band [IO.FileAttributes]::ReparsePoint){throw '成品目录不能为目录联接'}
    Remove-Item -LiteralPath $releaseDist -Recurse -Force
}
Copy-Item -LiteralPath (Join-Path $root 'dist') -Destination $release -Recurse -Force
Copy-Item -LiteralPath 'E:\Program Files\nodejs\node.exe' -Destination (Join-Path $release 'runtime\node.exe') -Force
Copy-Item -LiteralPath (Join-Path $root 'node_modules\opencc-js') -Destination (Join-Path $release 'node_modules') -Recurse -Force
Copy-Item -LiteralPath (Join-Path $package 'lib\net462\Microsoft.Web.WebView2.Core.dll') -Destination (Join-Path $release 'native') -Force
Copy-Item -LiteralPath (Join-Path $package 'lib\net462\Microsoft.Web.WebView2.WinForms.dll') -Destination (Join-Path $release 'native') -Force
Copy-Item -LiteralPath (Join-Path $package 'runtimes\win-x64\native\WebView2Loader.dll') -Destination (Join-Path $release 'native') -Force
foreach($file in @('settings.json','spotify-app.json')){if((Test-Path -LiteralPath (Join-Path $root ('data\'+$file))) -and -not(Test-Path -LiteralPath (Join-Path $release ('data\'+$file)))){Copy-Item -LiteralPath (Join-Path $root ('data\'+$file)) -Destination (Join-Path $release 'data')}}
if(Test-Path -LiteralPath (Join-Path $root 'data\lyrics')){Copy-Item -LiteralPath (Join-Path $root 'data\lyrics') -Destination (Join-Path $release 'data') -Recurse -Force}
$compiler=Join-Path $env:SystemRoot 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$output=Join-Path $release 'Spotify 歌词动画.exe'
& $compiler /nologo /target:winexe /platform:x64 ('/out:'+$output) ('/win32icon:'+(Join-Path $root 'spotify.ico')) ('/win32manifest:'+(Join-Path $PSScriptRoot 'app.manifest')) /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Net.Http.dll ('/reference:'+(Join-Path $release 'native\Microsoft.Web.WebView2.Core.dll')) ('/reference:'+(Join-Path $release 'native\Microsoft.Web.WebView2.WinForms.dll')) (Join-Path $PSScriptRoot 'Program.cs')
if($LASTEXITCODE -ne 0){throw '独立软件编译失败'}
Copy-Item -LiteralPath (Join-Path $root 'README.md') -Destination $release -Force
Copy-Item -LiteralPath (Join-Path $root 'upstream\LICENSE') -Destination (Join-Path $release 'LICENSE-AGPL-3.0.txt') -Force
# 随成品保留对应源码；不包含账号配置、歌词缓存、依赖目录或生成物。
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$sourceZip=Join-Path $release '对应源码.zip'
$zipStream=[IO.File]::Open($sourceZip,[IO.FileMode]::Create)
$archive=New-Object IO.Compression.ZipArchive($zipStream,[IO.Compression.ZipArchiveMode]::Create)
try {
    $files=@(Get-ChildItem -LiteralPath $root -File | Where-Object {$_.Extension -in @('.tsx','.ts','.mjs','.css','.html','.json','.ico') -or $_.Name -eq 'README.md' -or $_.Name -eq 'media-session.ps1'})
    foreach($folder in @('desktop','tests','upstream','public','styles','standalone','android\src','android\res')){$files+=Get-ChildItem -LiteralPath (Join-Path $root $folder) -File -Recurse}
    foreach($file in $files){
        $relative=$file.FullName.Substring($root.Length+1).Replace('\','/')
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,$relative,[IO.Compression.CompressionLevel]::Optimal)|Out-Null
    }
} finally {$archive.Dispose();$zipStream.Dispose()}
Get-Item -LiteralPath $output | Select-Object FullName,Length
