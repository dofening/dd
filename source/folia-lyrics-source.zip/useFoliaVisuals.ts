import { useEffect, useMemo } from 'react';
import { useVisualizerSettingsStore } from './upstream/src/stores/useVisualizerSettingsStore';
import { useVisualizerAssetStore } from './upstream/src/stores/useVisualizerAssetStore';
import { useThemeSettingsStore } from './upstream/src/stores/useThemeSettingsStore';
import { useVisualizerBackgroundConfig } from './upstream/src/components/visualizer/useVisualizerBackgroundConfig';
import { useVisualizerTunings } from './upstream/src/components/visualizer/useVisualizerTunings';
import { useVisualizerStyleAssets } from './upstream/src/components/visualizer/useVisualizerStyleAssets';
import { backgroundTuningActions } from './upstream/src/components/visualizer/tuningRegistry';
import { getMonetBackgroundImage } from './upstream/src/services/monetBackgroundImage';
import { getMonetPortraitImage } from './upstream/src/services/monetPortraitImage';
import type { VisualizerBackgroundActions } from './upstream/src/components/visualizer/backgrounds/definition';

export function useFoliaVisuals(restoreAssets = false) {
  const settings = useVisualizerSettingsStore();
  const assets = useVisualizerAssetStore();
  const background = useVisualizerBackgroundConfig();
  const tunings = useVisualizerTunings();
  const styleAssets = useVisualizerStyleAssets();
  useEffect(() => {
    if (!restoreAssets) return;
    void getMonetBackgroundImage().then(image => useVisualizerAssetStore.setState({ storedMonetBackgroundImage: image, isLoadingMonetBackgroundImage: false }));
    void getMonetPortraitImage().then(image => useVisualizerAssetStore.setState({ storedMonetPortraitImage: image, isLoadingMonetPortraitImage: false }));
  }, [restoreAssets]);
  useEffect(() => {
    if (!restoreAssets) return;
    const image = assets.storedMonetBackgroundImage;
    if (!image) return;
    const url = URL.createObjectURL(image.blob);
    useVisualizerAssetStore.setState({ monetBackgroundImage: { ...image, url } });
    return () => URL.revokeObjectURL(url);
  }, [restoreAssets, assets.storedMonetBackgroundImage]);
  useEffect(() => {
    if (!restoreAssets) return;
    const image = assets.storedMonetPortraitImage;
    if (!image) return;
    const url = URL.createObjectURL(image.blob);
    useVisualizerAssetStore.setState({ monetPortraitImage: { ...image, url } });
    return () => URL.revokeObjectURL(url);
  }, [restoreAssets, assets.storedMonetPortraitImage]);
  const actions = useMemo<VisualizerBackgroundActions>(() => ({
    ...backgroundTuningActions(settings as unknown as Record<string, unknown>),
    onModeChange: settings.handleSetVisualizerBackgroundMode,
    common: {
      onCoverColorChange: useThemeSettingsStore.getState().handleToggleCoverColorBg,
      onOpacityChange: settings.handleSetBackgroundOpacity,
      onDisableGeometricChange: settings.handleToggleDisableVisualizerGeometricBackground,
      onDisableVignetteChange: settings.handleToggleDisableVisualizerVignette,
    },
    customImage: { onUpload: settings.handleUploadMonetBackgroundImage, onClear: settings.handleClearMonetBackgroundImage, isLoading: assets.isLoadingMonetBackgroundImage },
    url: { onAdd: settings.handleAddUrlBackgroundItem, onUpdate: settings.handleUpdateUrlBackgroundItem, onDelete: settings.handleDeleteUrlBackgroundItem, onSelect: settings.handleSetUrlBackgroundSelectedId },
  }), [settings, assets.isLoadingMonetBackgroundImage]);
  return { settings, background, tunings, styleAssets, backgroundActions: actions };
}
