import { cp, mkdir, rename, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const current = path.resolve(root, 'dist');
const candidate = path.resolve(root, 'dist-next');
const history = path.resolve(root, 'asset-history');
if (![current, candidate, history].every(target => target.startsWith(root + path.sep))) throw new Error('构建路径不符合预期');
await stat(path.join(candidate, 'index.html'));
await mkdir(history, { recursive: true });
try { await cp(path.join(current, 'assets'), path.join(history, 'assets'), { recursive: true, force: false }); } catch (error) { if (error.code !== 'ENOENT') throw error; }
const archive = path.resolve(root, 'build-history', `dist-${Date.now()}`);
if (!archive.startsWith(path.join(root, 'build-history') + path.sep)) throw new Error('构建备份路径不符合预期');
await mkdir(path.dirname(archive), { recursive: true });
try { await rename(current, archive); } catch (error) { if (error.code !== 'ENOENT') throw error; }
await rename(candidate, current);
console.log('已启用检查后的界面，旧版资源已保留，避免已打开的窗口切换动画时丢失文件。');
