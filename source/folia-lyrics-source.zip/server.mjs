import http from 'node:http';
import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { readFile, stat, mkdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { lookupLyrics, simplifyLyrics } from './lyrics.mjs';
import { SpotifyConnection } from './spotify.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.FOLIA_PORT || 18981);
const host = `127.0.0.1:${port}`;
const cacheRoot = path.join(root, 'data', 'lyrics');
let state = { connected: false, status: 'waiting', message: '正在连接 Spotify…' };
let reader;
let stopping = false;
let lastClient = Date.now();
let allowOnline = false;
const spotify = new SpotifyConnection(`http://${host}/spotify/callback`);
let playlistCache = null;
let playerCache = null;
let playerJob = null;
try { spotify.clientId = JSON.parse(await readFile(path.join(root, 'data', 'spotify-app.json'), 'utf8')).clientId || ''; } catch {}
try { allowOnline = JSON.parse(await readFile(path.join(root, 'data', 'settings.json'), 'utf8')).allowOnline === true; } catch {}
const script = await readFile(path.join(root, 'media-session.ps1'), 'utf8');
const powershell = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32/WindowsPowerShell/v1.0/powershell.exe');

function startReader() {
  reader = spawn(powershell, ['-NoProfile', '-NonInteractive', '-EncodedCommand',
    Buffer.from(script, 'utf16le').toString('base64')], { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] });
  createInterface({ input: reader.stdout }).on('line', line => {
    try { const next = JSON.parse(line); if (typeof next.connected === 'boolean') state = next; } catch {}
  });
  reader.on('error', () => { state = { connected: false, status: 'error', message: '系统媒体连接未能启动' }; });
  reader.on('exit', () => {
    if (!stopping) {
      state = { connected: false, status: 'error', message: '正在重新连接 Spotify…' };
      setTimeout(startReader, 2500).unref();
    }
  });
}

function json(response, status, data) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  response.end(JSON.stringify(data));
}

async function body(request) {
  const chunks = []; let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 2 * 1024 * 1024) throw new Error('歌词文件不能超过 2 MB');
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

const lyricJobs = new Map();
// 没查到的歌曲一分钟内不重复访问歌词库：窗口会定时重试，多种查询写法不应变成频繁请求。
const recentMisses = new Map();
function songKey(song) {
  return createHash('sha256').update(JSON.stringify([song.title, song.artist, Math.round(song.duration ?? 0)])).digest('hex');
}
async function lyrics(song, force = false) {
  // 所有歌词（含旧缓存和本地导入）在返回时统一转成简体；日文歌词保持原样。
  return simplifyLyrics(await findLyrics(song, force));
}
async function findLyrics(song, force = false) {
  const key = songKey(song);
  const file = path.join(cacheRoot, `${key}.json`);
  if (!force) { try { return JSON.parse(await readFile(file, 'utf8')); } catch {} }
  if (!allowOnline) return { status: 'offline', lines: '', message: '可以导入本地歌词，或在设置中允许自动匹配' };
  if (lyricJobs.has(key)) return lyricJobs.get(key);
  const miss = recentMisses.get(key);
  if (miss && Date.now() - miss.at < 60000) return miss.result;
  const job = lookupLyrics(song).then(async result => {
    if (result.status === 'missing' || result.status === 'plain') recentMisses.set(key, { at: Date.now(), result }); else recentMisses.delete(key);
    if (result.status === 'synced' || result.status === 'instrumental') {
      await mkdir(cacheRoot, { recursive: true });
      await writeFile(file, JSON.stringify(result));
    }
    return result;
  }).catch(error => ({ status: 'unavailable', lines: '', retryAfterMs: error.retryAfterMs || 30000, message: '歌词库暂时繁忙，正在自动重试' }))
    .finally(() => lyricJobs.delete(key));
  lyricJobs.set(key, job);
  return job;
}

const mime = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.woff2': 'font/woff2' };
const server = http.createServer(async (request, response) => {
  try {
    // 只对本机窗口开放，拒绝局域网、任意 Origin 和 DNS 重绑定。
    if (request.headers.host !== host || (request.headers.origin && request.headers.origin !== `http://${host}`)) {
      json(response, 403, { error: '只允许本机歌词窗口访问' }); return;
    }
    const url = new URL(request.url, `http://${host}`);
    if (url.pathname === '/spotify/callback' && request.method === 'GET') {
      try {
        if (url.searchParams.has('error')) throw new Error('授权取消');
        await spotify.finish(url.searchParams.get('code'), url.searchParams.get('state'));
        playlistCache = null;
        playerCache = null;
        response.writeHead(303, { Location: '/?spotify=connected', 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' }); response.end();
      } catch {
        response.writeHead(400, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' });
        response.end('<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>Spotify 授权</title><body style="background:#101820;color:#dbe8e0;font:16px sans-serif;padding:50px">Spotify 授权未能完成。请确认官方应用设置中的回调地址为 <b>http://127.0.0.1:18981/spotify/callback</b>，然后<a href="/" style="color:#8cdfaf">返回歌词窗口</a>重新连接。</body></html>');
      }
      return;
    }
    if (url.pathname === '/api/spotify/status' && request.method === 'GET') { json(response, 200, spotify.state()); return; }
    if (url.pathname === '/api/spotify/player' && request.method === 'GET') {
      try {
        if (!spotify.state().connected) throw new Error('请先连接 Spotify');
        if (!playerCache || Date.now() - playerCache.receivedAt > 1500) {
          if (!playerJob) playerJob = spotify.player().then(value => { playerCache = { ...value, receivedAt: value.receivedAt ?? Date.now() }; return playerCache; }).finally(() => { playerJob = null; });
          await playerJob;
        }
        json(response, 200, playerCache);
      } catch (error) { json(response, 400, { error: error.message }); }
      return;
    }
    if (url.pathname === '/api/spotify/control' && request.method === 'POST') {
      try { const result = await spotify.control(await body(request)); playerCache = result.player || null; json(response, 200, result); }
      catch (error) { json(response, 400, { error: error.message }); }
      return;
    }
    if (url.pathname === '/api/spotify/connect' && request.method === 'POST') {
      try {
        const input = await body(request);
        const clientId = input.clientId || spotify.clientId;
        const authorizeUrl = spotify.start(clientId);
        await mkdir(path.join(root, 'data'), { recursive: true });
        // 仅保存公开应用标识，不接受、不保存 Client Secret。
        await writeFile(path.join(root, 'data', 'spotify-app.json'), JSON.stringify({ clientId }));
        json(response, 200, { url: authorizeUrl });
      } catch (error) { json(response, 400, { error: error.message }); }
      return;
    }
    if (url.pathname === '/api/spotify/disconnect' && request.method === 'POST') {
      spotify.disconnect(); playlistCache = null; playerCache = null; json(response, 200, { connected: false }); return;
    }
    if (url.pathname === '/api/spotify/playlists' && request.method === 'GET') {
      try {
        if (!spotify.state().connected) throw new Error('请先连接 Spotify');
        if (!playlistCache || Date.now() - playlistCache.syncedAt > 60000 || url.searchParams.get('refresh') === '1') playlistCache = await spotify.playlists();
        json(response, 200, playlistCache);
      } catch (error) { json(response, 400, { error: error.message }); }
      return;
    }
    if (url.pathname === '/api/spotify/tracks' && request.method === 'GET') {
      try {
        const offset = Number(url.searchParams.get('offset') || 0);
        if (!Number.isInteger(offset) || offset < 0 || offset > 100000) throw new Error('无效的歌曲页码');
        json(response, 200, await spotify.tracks(url.searchParams.get('id'), offset));
      } catch (error) { json(response, 400, { error: error.message }); }
      return;
    }
    if (url.pathname === '/api/spotify/art' && request.method === 'GET') {
      try {
        const image = new URL(url.searchParams.get('url'));
        if (image.protocol !== 'https:' || image.port || image.username || image.password || !/\.(scdn\.co|spotifycdn\.com)$/.test(image.hostname)) throw new Error();
        const art = await fetch(image, { signal: AbortSignal.timeout(10000), redirect: 'error' });
        if (!art.ok || !art.headers.get('content-type')?.startsWith('image/')) throw new Error();
        const bytes = Buffer.from(await art.arrayBuffer()); if (bytes.length > 5 * 1024 * 1024) throw new Error();
        response.writeHead(200, { 'Content-Type': art.headers.get('content-type'), 'Cache-Control': 'private, max-age=3600', 'X-Content-Type-Options': 'nosniff' }); response.end(bytes);
      } catch { response.writeHead(404); response.end(); }
      return;
    }
    if (url.pathname === '/api/health') { json(response, 200, { app: 'folia-spotify-lyrics', version: '1.1.0' }); return; }
    if (url.pathname === '/api/shutdown' && request.method === 'POST') { json(response, 200, { stopped: true }); setTimeout(stop, 100); return; }
    if (url.pathname === '/api/state' && request.method === 'GET') {
      lastClient = Date.now();
      const stale = !state.receivedAt || Date.now() - state.receivedAt > 4000;
      json(response, 200, { ...state, ...(stale ? { connected: false, status: 'error', message: 'Spotify 连接暂时中断，正在重试…' } : {}), allowOnline }); return;
    }
    if (url.pathname === '/api/settings' && request.method === 'POST') {
      const settings = await body(request);
      allowOnline = settings.allowOnline === true;
      await mkdir(path.join(root, 'data'), { recursive: true });
      await writeFile(path.join(root, 'data', 'settings.json'), JSON.stringify({ allowOnline }));
      json(response, 200, { allowOnline }); return;
    }
    if (url.pathname === '/api/lyrics' && request.method === 'GET') {
      if (!state.connected || !state.title) { json(response, 200, { status: 'waiting', lines: '' }); return; }
      // 只查询实际正在播放的歌曲，网页不能任意代理外网查询。
      const song = { title: state.title, artist: state.artist, duration: state.duration };
      json(response, 200, { key: songKey(song), ...await lyrics(song, url.searchParams.get('refresh') === '1') }); return;
    }
    if (url.pathname === '/api/import' && request.method === 'POST') {
      if (!state.connected || !state.title) { json(response, 409, { error: '请先在 Spotify 播放需要导入歌词的歌曲' }); return; }
      const input = await body(request);
      if (!['lrc', 'ttml', 'yrc', 'qrc', 'krc'].includes(input.format) || typeof input.lines !== 'string' || !input.lines.trim()) {
        json(response, 400, { error: '请选择有效的 LRC、TTML、YRC、QRC 或 KRC 文本歌词' }); return;
      }
      // 防止文件选择期间切歌，把上一首歌词错误绑定给下一首。
      if (input.title !== state.title || input.artist !== state.artist) { json(response, 409, { error: 'Spotify 已切歌，请为当前歌曲重新导入' }); return; }
      const result = { status: 'synced', source: '本地导入', lines: input.lines, format: input.format, wordTimed: input.format !== 'lrc' };
      await mkdir(cacheRoot, { recursive: true });
      await writeFile(path.join(cacheRoot, `${songKey(state)}.json`), JSON.stringify(result));
      json(response, 200, simplifyLyrics(result)); return;
    }
    if (url.pathname.startsWith('/api/')) { json(response, 404, { error: '没有这个接口' }); return; }
    if (request.method !== 'GET' && request.method !== 'HEAD') { json(response, 405, { error: '不支持的操作' }); return; }
    const publicRoot = path.resolve(root, process.env.FOLIA_STATIC_DIR || 'dist');
    if (!publicRoot.startsWith(root + path.sep)) throw new Error('无效界面目录');
    const pathname = decodeURIComponent(url.pathname);
    let file = path.resolve(publicRoot, '.' + (pathname === '/' ? '/index.html' : pathname));
    if (!file.startsWith(publicRoot + path.sep)) { json(response, 403, { error: '无效路径' }); return; }
    let info;
    try { info = await stat(file); } catch (error) {
      if (error.code !== 'ENOENT' || !pathname.startsWith('/assets/')) throw error;
      file = path.resolve(root, 'asset-history', '.' + pathname);
      if (!file.startsWith(path.join(root, 'asset-history', 'assets') + path.sep)) throw error;
      info = await stat(file);
    }
    if (!info.isFile()) throw new Error('not a file');
    response.writeHead(200, {
      'Content-Type': mime[path.extname(file)] || 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-cache',
      'Content-Security-Policy': "default-src 'self' data: blob:; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' data: blob:; worker-src 'self' blob:; font-src 'self' data:; frame-src 'self' https: blob:",
    });
    response.end(request.method === 'HEAD' ? undefined : await readFile(file));
  } catch { if (!response.headersSent) json(response, 400, { error: '无法处理请求或文件不存在' }); else response.end(); }
});

server.on('error', error => { console.error(error.code === 'EADDRINUSE' ? '歌词窗口已经启动，或本机端口被其他程序占用。' : '歌词窗口启动失败。'); stop(); });
function stop() { stopping = true; reader?.kill(); server.close(); setTimeout(() => process.exit(0), 100).unref(); }
process.on('SIGINT', stop); process.on('SIGTERM', stop);
server.listen(port, '127.0.0.1', () => { startReader(); console.log(`Folia Spotify 歌词 http://${host}`); });
// 窗口长期关闭后退出，不留无限运行的后台任务。
setInterval(() => { if (Date.now() - lastClient > 30 * 60 * 1000) stop(); }, 60000).unref();
