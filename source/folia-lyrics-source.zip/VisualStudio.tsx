import React from 'react';
import VisPlayground from './upstream/src/components/visualizer/window/VisPlayground';
import type { Theme } from './upstream/src/types';
import { useFoliaVisuals } from './useFoliaVisuals';

export default function VisualStudio({ theme, mode, section, fontScale, onMode, onFontScale, onClose }: {
  theme: Theme; mode: string; section: 'background' | 'visualizer'; fontScale: number;
  onMode: (mode: string) => void; onFontScale: (value: number) => void; onClose: () => void;
}) {
  const visuals = useFoliaVisuals();
  return <div className="original-visual-studio">
    <VisPlayground theme={theme} isDaylight={false} visualizerMode={mode} initialEditSection={section}
      visualizerOpacity={visuals.settings.visualizerOpacity} backgroundConfig={visuals.background} backgroundActions={visuals.backgroundActions}
      fontStyle={theme.fontStyle} fontScale={fontScale} fontWeight={theme.fontWeight ?? null}
      customFontFamily={null} customFontLabel={null}
      onFontStyleChange={value => { localStorage.setItem('folia_spotify_font_style', value); window.dispatchEvent(new Event('folia-appearance')); }}
      onFontScaleChange={onFontScale}
      onFontWeightChange={value => { localStorage.setItem('folia_spotify_font_weight', String(value ?? '')); window.dispatchEvent(new Event('folia-appearance')); }}
      onCustomFontChange={() => {}}
      onVisualizerModeChange={onMode} onVisualizerOpacityChange={visuals.settings.handleSetVisualizerOpacity}
      onClose={onClose}/>
  </div>;
}
