// 只在两次系统快照之间补时；失联后最多补三秒，避免歌词无限前进。
export function getPosition(snapshot, now = Date.now()) {
  if (!snapshot?.connected) return 0;
  const elapsed = snapshot.playing ? Math.min(3, Math.max(0, (now - snapshot.receivedAt) / 1000)) : 0;
  const position = Math.max(0, Number(snapshot.position) + elapsed);
  return snapshot.duration > 0 ? Math.min(snapshot.duration, position) : position;
}

const PRECISE_TUNING = { jump: 0.6, gain: 0.5, maxRate: 0.15 };
const COARSE_TUNING = { jump: 2, gain: 0.05, maxRate: 0.06 };

// 系统会连续报告同一个整秒位置。不能把每份快照都当成新的计时起点。
export function createPlaybackClock() {
  let key = ''; let position = 0; let previousTime = 0; let lastStamp = -1;
  let lastReported = 0; let wasPlaying = false; let speed = 1; let pendingSeek = null;
  return {
    seek(value, now = Date.now()) { position = Math.max(0, value); previousTime = now; pendingSeek = { value: position, until: now + 2500 }; },
    tick(snapshot, now = Date.now()) {
      if (!snapshot?.connected) { key = ''; previousTime = now; return 0; }
      const nextKey = `${snapshot.title}\u0000${snapshot.artist}\u0000${snapshot.duration}`;
      const elapsed = previousTime ? Math.max(0, Math.min(0.25, (now - previousTime) / 1000)) : 0;
      previousTime = now;
      if (snapshot.playing && wasPlaying) position += elapsed * speed;
      const fresh = Number(snapshot.receivedAt) > lastStamp;
      // Spotify 接口给毫秒进度：偏差超过 0.6 秒直接对齐，小偏差约 2 秒内追平。
      // 系统媒体会话可能是整秒快照，仍用原来更宽松的参数，避免来回跳。
      const tuning = snapshot.precise ? PRECISE_TUNING : COARSE_TUNING;
      if (key !== nextKey) {
        key = nextKey; position = getPosition(snapshot, now); speed = 1; pendingSeek = null;
        lastReported = Number(snapshot.position) || 0; lastStamp = Number(snapshot.receivedAt); wasPlaying = !!snapshot.playing;
      } else if (fresh) {
        const target = getPosition(snapshot, now);
        const reported = Number(snapshot.position) || 0;
        if (pendingSeek && (Math.abs(target - pendingSeek.value) < 1.5 || now > pendingSeek.until)) pendingSeek = null;
        if (!pendingSeek) {
          const changed = reported !== lastReported;
          const backwardSeek = reported < lastReported - 0.3;
          if (!snapshot.playing) {
            if (wasPlaying || changed) position = target;
            speed = 1;
          } else if (changed && (backwardSeek || Math.abs(target - position) > tuning.jump)) {
            position = target; speed = 1;
          } else if (changed) {
            speed = Math.max(1 - tuning.maxRate, Math.min(1 + tuning.maxRate, 1 + (target - position) * tuning.gain));
          }
        }
        lastReported = reported; lastStamp = Number(snapshot.receivedAt); wasPlaying = !!snapshot.playing;
      }
      position = Math.max(0, snapshot.duration > 0 ? Math.min(snapshot.duration, position) : position);
      return position;
    },
  };
}
