// 桌面版与独立版（手机 / 平板）的少量差异集中在这里。
export const STANDALONE = import.meta.env.VITE_FOLIA_STANDALONE === '1';
// 专辑封面：桌面版经本机后台转发；独立版直接加载 Spotify 的图片地址。
export const artUrl = (url?: string | null) => !url ? undefined
  : url.startsWith('/') || url.startsWith('./') || url.startsWith('data:') ? url
    : STANDALONE ? url : `/api/spotify/art?url=${encodeURIComponent(url)}`;
// 站内静态文件：独立版可能放在子目录（如 GitHub Pages 的 /仓库名/），用相对路径。
export const assetUrl = (name: string) => STANDALONE ? `./${name}` : `/${name}`;
