import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { LibraryBig, Maximize, Minimize, SlidersHorizontal } from 'lucide-react';
import { createRoot } from 'react-dom/client';
// 本窗口的安全策略禁止 eval；商籁、凝彩、绘光、花火用 Pixi 绘制，需加载 Pixi 官方的免 eval 着色器模块，否则只剩静态文字。
import 'pixi.js/unsafe-eval';
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import zh from './upstream/src/i18n/locales/zh-CN';
import VisualizerRenderer from './upstream/src/components/visualizer/VisualizerRenderer';
import { VISUALIZER_REGISTRY } from './upstream/src/components/visualizer/registry';
// 自制的墨染、直书、星轨三种动画，需在读取动画列表前注册。
import './styles/register';
import { VISUALIZER_BACKGROUND_REGISTRY } from './upstream/src/components/visualizer/backgrounds/registry';
import { parseLyricsByFormat } from './upstream/src/utils/lyrics/parserCore';
import { PlayerState, type Line, type Theme } from './upstream/src/types';
import { lyricCurrentTime as clock, currentTime, audioPower as power, audioBands as bands } from './upstream/src/stores/motionSignals';
import { usePlaybackStore } from './upstream/src/stores/usePlaybackStore';
import { NO_LYRIC_LINES } from './upstream/src/utils/lyrics/noLyricLines';
import { useFoliaVisuals } from './useFoliaVisuals';
import VisualStudio from './VisualStudio';
import PlaybackControls, { type SpotifyPlayer } from './PlaybackControls';
import LyricsTimelineModal from './upstream/src/components/modal/LyricsTimelineModal';
import { createPlaybackClock } from './position.mjs';
import Library from './Library';
import { STANDALONE, artUrl } from './platform';
import { extractColors } from './upstream/src/utils/colorExtractor';
import { useTouchPlayback } from './useTouchPlayback';
import { hdrGlyphImage, useHdrDisplay, useHdrGlyphFill } from './HdrGlow';
import { HdrGlyphFillContext } from './upstream/src/components/visualizer/hdrGlyphFill';
import { HanabiHdrContext, type HanabiHdrStatus } from './upstream/src/components/visualizer/hanabi/hanabiHdrContext';
import { generateBuiltinDualTheme } from './upstream/src/utils/builtinTheme/generateBuiltinDualTheme';
import './upstream/src/index.css';
import './style.css';
import './library.css';

void i18n.use(initReactI18next).init({ lng: 'zh-CN', resources: { 'zh-CN': { translation: zh } }, interpolation: { escapeValue: false } });

type Snapshot = { precise?: boolean; connected: boolean; status: string; title?: string; artist?: string; album?: string; playing?: boolean; position?: number; duration?: number; receivedAt?: number; message?: string; allowOnline?: boolean; coverUrl?: string };
type Lyrics = { status: string; message?: string; lines?: string; format?: string; source?: string; plain?: string; wordTimed?: boolean; retryAfterMs?: number };
const palettes: Theme[] = [
  { name: '月光', backgroundColor: '#0b101b', primaryColor: '#e7f0ff', accentColor: '#a5bfed', secondaryColor: '#697caa', fontStyle: 'sans', animationIntensity: 'normal' },
  { name: '暖金', backgroundColor: '#18120e', primaryColor: '#fff0d5', accentColor: '#f3ca88', secondaryColor: '#92724b', fontStyle: 'serif', animationIntensity: 'normal' },
  { name: '翠绿', backgroundColor: '#08150f', primaryColor: '#e6ffeb', accentColor: '#87dbaa', secondaryColor: '#44795f', fontStyle: 'sans', animationIntensity: 'normal' },
];
// 第 4 种色调“跟随封面”：用 Folia 自带的封面取色生成深色主题，每首歌固定种子，切回同一首颜色不变。
const COVER_PALETTE = palettes.length;
const paletteNames = [...palettes.map(item => item.name), '跟随封面'];
const seededRandom = (text: string) => {
  let seed = 2166136261;
  for (const char of text) seed = Math.imul(seed ^ char.charCodeAt(0), 16777619);
  return () => { seed = Math.imul(seed ^ (seed >>> 15), 2246822507) ^ Math.imul(seed ^ (seed >>> 13), 3266489909); return ((seed >>>= 0) % 100000) / 100000; };
};
const saved = (name: string, fallback: string) => { try { return localStorage.getItem(name) ?? fallback; } catch { return fallback; } };
const timeLabel = (seconds = 0) => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;
const store = (name: string, value: string) => { try { localStorage.setItem(name, value); } catch { /* 存储不可用时只影响记忆，不影响播放 */ } };
const keyOf = (state: Snapshot) => state.connected ? `${state.title}\u0000${state.artist}\u0000${Math.round(state.duration ?? 0)}` : '';

function App() {
  const [snapshot, setSnapshot] = useState<Snapshot>({ connected: false, status: 'waiting', message: '正在连接 Spotify…' });
  const snapshotRef = useRef(snapshot);
  const [lyrics, setLyrics] = useState<Lyrics>({ status: 'waiting' });
  const [lines, setLines] = useState<Line[]>([]);
  const [lineIndex, setLineIndex] = useState(-1);
  const [mode, setMode] = useState(() => saved('folia_spotify_mode', 'classic'));
  const [palette, setPalette] = useState(() => Math.max(0, Math.min(COVER_PALETTE, Number(saved('folia_spotify_palette', String(COVER_PALETTE))) || 0)));
  const [coverTheme, setCoverTheme] = useState<{ key: string; theme: Theme } | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  // 主屏幕模式不等于元素全屏：iPad 仍需保留隐藏系统状态栏的真正全屏入口。
  const fullscreenSupported = typeof document.documentElement.requestFullscreen === 'function'
    || typeof (document.documentElement as any).webkitRequestFullscreen === 'function';
  const [fontScale, setFontScale] = useState(() => Number(saved('folia_spotify_font', '1')) || 1);
  const [settings, setSettings] = useState(false);
  const [hdrEnabled, setHdrEnabled] = useState(() => saved('folia_hdr_glow', 'off') === 'on');
  const [hanabiHdrStatus, setHanabiHdrStatus] = useState<HanabiHdrStatus>('starting');
  const [library, setLibrary] = useState(() => new URLSearchParams(location.search).get('spotify') === 'connected');
  const [studio, setStudio] = useState<'background' | 'visualizer' | null>(null);
  const [appearance, setAppearance] = useState(0);
  const [timeline, setTimeline] = useState(false);
  const remotePlayer = useRef<SpotifyPlayer>({});
  const [player, setPlayer] = useState<SpotifyPlayer>({});
  const [volumePreview, setVolumePreview] = useState<number | null>(null);
  const playbackClock = useRef(createPlaybackClock());
  const visuals = useFoliaVisuals(true);
  const [notice, setNotice] = useState('');
  const [refresh, setRefresh] = useState(0);
  const previousRefresh = useRef(0);
  const previousLyricKey = useRef('');
  const lyricContent = useRef('');
  const [offset, setOffset] = useState(0);
  const [quiet, setQuiet] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const lastInput = useRef(Date.now());
  const key = keyOf(snapshot);
  const linesRef = useRef(lines);
  linesRef.current = lines;
  snapshotRef.current = snapshot;

  useEffect(() => {
    const update = () => setAppearance(value => value + 1);
    window.addEventListener('folia-appearance', update);
    return () => window.removeEventListener('folia-appearance', update);
  }, []);
  useEffect(() => {
    usePlaybackStore.setState({ currentSong: snapshot.connected ? {
      id: key as any, name: snapshot.title ?? '', artists: [{ id: 'spotify', name: snapshot.artist ?? '' }],
      album: { id: 'spotify', name: snapshot.album ?? '', picUrl: snapshot.coverUrl ?? '' }, durationMs: (snapshot.duration ?? 0) * 1000,
    } as any : null, lyrics: lines.length ? { lines } : null, cachedCoverUrl: snapshot.coverUrl ?? null,
      duration: snapshot.duration ?? 0, playerState: snapshot.playing ? PlayerState.PLAYING : PlayerState.PAUSED, currentLineIndex: lineIndex });
  }, [key, lines, snapshot.playing, snapshot.coverUrl, snapshot.duration, lineIndex]);

  useEffect(() => {
    let stopped = false; let timer: ReturnType<typeof setTimeout>;
    async function poll() {
      try {
        const response = await fetch('/api/state', { signal: AbortSignal.timeout(2500) });
        if (!response.ok) throw new Error();
        const value = await response.json();
        if (!stopped) {
          const remote = remotePlayer.current;
          if (remote.available && remote.title && Date.now() - (remote.receivedAt ?? 0) < (STANDALONE ? 30000 : 5000)) {
            setSnapshot({ ...value, connected: true, precise: true, title: remote.title, artist: remote.artist, album: remote.album,
              playing: remote.playing, duration: remote.duration, position: remote.position, receivedAt: remote.receivedAt,
              coverUrl: artUrl(remote.cover) });
          } else setSnapshot(value);
        }
      } catch { if (!stopped) setSnapshot({ connected: false, status: 'error', message: '连接已断开，请重新打开桌面歌词入口' }); }
      if (!stopped) timer = setTimeout(poll, 500);
    }
    void poll();
    return () => { stopped = true; clearTimeout(timer); };
  }, []);

  useEffect(() => {
    const changedSong = previousLyricKey.current !== key;
    previousLyricKey.current = key;
    if (changedSong) {
      setLines([]); setLineIndex(-1); setNotice(''); lyricContent.current = '';
      setOffset(Number(saved(`offset:${key}`, '0')) || 0);
    }
    if (!key) { setLyrics({ status: 'waiting' }); return; }
    const controller = new AbortController();
    if (changedSong || !linesRef.current.length) setLyrics({ status: 'loading', message: '正在主动匹配歌词…' });
    const forceRefresh = previousRefresh.current !== refresh;
    previousRefresh.current = refresh;
    fetch(`/api/lyrics${forceRefresh ? '?refresh=1' : ''}`, { signal: controller.signal })
      .then(response => response.json()).then(value => {
        if (!controller.signal.aborted) applyLyrics(value, !changedSong);
      }).catch(() => { if (!controller.signal.aborted && !linesRef.current.length) setLyrics({ status: 'error', message: '歌词暂时不可用，稍后自动重试' }); });
    return () => controller.abort();
  }, [key, snapshot.allowOnline, refresh]);

  useEffect(() => {
    if (!snapshot.allowOnline || !key || lyrics.status === 'loading' || lyrics.status === 'waiting' || lyrics.status === 'instrumental' || lyrics.source === '本地导入') return;
    const delay = lyrics.status === 'synced' ? 60000 : Math.max(15000, lyrics.retryAfterMs || 20000);
    const retry = setTimeout(() => setRefresh(value => value + 1), delay);
    return () => clearTimeout(retry);
  }, [lyrics.status, lyrics.source, lyrics.retryAfterMs, snapshot.allowOnline, key, refresh]);
  useEffect(() => {
    let lastWake = 0;
    const wake = () => { if (snapshotRef.current.connected && document.visibilityState === 'visible' && Date.now() - lastWake > 3000) { lastWake = Date.now(); setRefresh(value => value + 1); } };
    window.addEventListener('focus', wake); document.addEventListener('visibilitychange', wake);
    return () => { window.removeEventListener('focus', wake); document.removeEventListener('visibilitychange', wake); };
  }, []);

  useEffect(() => {
    if (palette !== COVER_PALETTE || !snapshot.coverUrl || !key) return;
    let cancelled = false; const songKey = key;
    void extractColors(snapshot.coverUrl, 5).then(colors => {
      if (cancelled || !colors.length) return;
      const generated = generateBuiltinDualTheme({ coverColors: colors, random: seededRandom(songKey) }).dark;
      setCoverTheme({ key: songKey, theme: { ...generated, fontStyle: 'sans', animationIntensity: 'normal' } });
    }).catch(() => {});
    return () => { cancelled = true; };
  }, [palette, snapshot.coverUrl, key]);
  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(''), 3200);
    return () => clearTimeout(timer);
  }, [notice]);
  // 独立版在播放时保持屏幕常亮（iPadOS 16.4+ / 安卓支持），暂停或切到后台即释放。
  useEffect(() => {
    if (!STANDALONE || !snapshot.playing || !('wakeLock' in navigator)) return;
    let lock: { release: () => Promise<void> } | null = null; let cancelled = false;
    const acquire = () => { if (document.visibilityState === 'visible') (navigator as any).wakeLock.request('screen').then((value: any) => { if (cancelled) void value.release(); else lock = value; }).catch(() => {}); };
    acquire(); document.addEventListener('visibilitychange', acquire);
    return () => { cancelled = true; document.removeEventListener('visibilitychange', acquire); void lock?.release().catch(() => {}); };
  }, [snapshot.playing]);
  useEffect(() => {
    const update = () => setIsFullscreen(!!(document.fullscreenElement || (document as any).webkitFullscreenElement));
    update();
    document.addEventListener('fullscreenchange', update);
    document.addEventListener('webkitfullscreenchange', update);
    return () => { document.removeEventListener('fullscreenchange', update); document.removeEventListener('webkitfullscreenchange', update); };
  }, []);

  function applyLyrics(value: Lyrics, keepExisting = false) {
    if (keepExisting && linesRef.current.length && value.status !== 'synced') return;
    setLyrics(value);
    if (value.status !== 'synced' || !value.lines) { setLines([]); return; }
    const content = `${value.format || 'lrc'}:${value.lines}`;
    if (lyricContent.current === content) return;
    try {
      const parsed = parseLyricsByFormat((value.format ?? 'lrc') as any, value.lines);
      const valid = parsed.lines.filter(line => Number.isFinite(line.startTime) && Number.isFinite(line.endTime));
      if (!valid.length) throw new Error();
      lyricContent.current = content;
      setLines(valid);
    } catch { setLines([]); setLyrics({ status: 'invalid', message: '歌词时间格式无法识别，请换一份歌词文件' }); }
  }

  useEffect(() => {
    // 触屏设备多给几秒再隐藏控制栏：先轻点呼出，再点按钮。独立版网络慢时，Spotify 播放信息最长保留 30 秒，不让画面闪回空白。
    const quietAfter = typeof matchMedia === 'function' && matchMedia('(hover: none)').matches ? 8000 : 4500;
    let frame = 0; let lastActive = -2; let lastQuiet: boolean | null = null; let searchFrom = 0;
    const tick = () => {
      const value = snapshotRef.current;
      const position = playbackClock.current.tick(value);
      currentTime.set(position);
      clock.set(Math.max(0, position + offset));
      // 从上一行附近往后找当前行；跳转或换歌时退回从头找。
      const currentLines = linesRef.current; const time = clock.get();
      if (searchFrom >= currentLines.length || (searchFrom > 0 && currentLines[searchFrom].startTime > time)) searchFrom = 0;
      let active = searchFrom - 1;
      for (let index = searchFrom; index < currentLines.length && currentLines[index].startTime <= time; index++) active = index;
      searchFrom = Math.max(0, active);
      if (active !== lastActive) { lastActive = active; setLineIndex(active); }
      const nextQuiet = Date.now() - lastInput.current > quietAfter;
      if (nextQuiet !== lastQuiet) { lastQuiet = nextQuiet; setQuiet(nextQuiet); }
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [offset]);

  useEffect(() => {
    const active = (event: Event) => {
      // 画面轻点由单独的手势逻辑切换显隐，不能在 pointerdown 时提前强制呼出。
      if (event instanceof PointerEvent && (event.pointerType !== 'mouse' && event.type === 'pointermove'
        || event.type === 'pointerdown' && event.target instanceof Element && !event.target.closest('.chrome,button,a,input,select,[role="dialog"],.library-backdrop,.original-visual-studio,.panel-backdrop'))) return;
      lastInput.current = Date.now(); setQuiet(false);
    };
    const keyboard = (event: KeyboardEvent) => {
      active();
      const editable = event.target instanceof HTMLElement && (event.target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(event.target.tagName));
      if (event.key === 'Escape') { setSettings(false); setLibrary(false); setStudio(null); setTimeline(false); }
      if ((event.key === 'f' || event.key === 'F') && !editable) void fullscreen();
      if ((event.key === '[' || event.key === ']') && !editable && !library && !studio && !timeline) nudgeOffset.current(event.key === ']' ? 0.05 : -0.05);
      if (event.key === ' ' && !editable && !settings && !library && !studio && !timeline && !(event.target instanceof HTMLElement && event.target.closest('button,a'))) {
        event.preventDefault(); if (!event.repeat) void sendControl('toggle',0);
      }
      if (!editable && !settings && !library && !studio && !timeline && ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) {
        event.preventDefault();
        if (event.repeat && performance.now() - lastControl.current < 180) return;
        lastControl.current = performance.now();
        const kind = event.key === 'ArrowLeft' || event.key === 'ArrowRight' ? 'seek' : 'volume';
        const delta = event.key === 'ArrowLeft' || event.key === 'ArrowDown' ? -5 : 5;
        void sendControl(kind, delta);
      }
    };
    window.addEventListener('pointermove', active); window.addEventListener('pointerdown', active); window.addEventListener('keydown', keyboard);
    return () => { window.removeEventListener('pointermove', active); window.removeEventListener('pointerdown', active); window.removeEventListener('keydown', keyboard); };
  }, [settings, library, studio, timeline]);

  const lastControl = useRef(0);
  const latestControl = useRef(0);
  async function sendControl(action: string, delta: number) {
    const sequence = ++latestControl.current;
    setNotice(action === 'volume' ? `正在${delta > 0 ? '调高' : '调低'}音量…` : action === 'seek' ? `正在${delta > 0 ? '前进' : '后退'} ${Math.abs(delta)} 秒…` : '正在切换播放状态…');
    try {
      const response = await fetch('/api/spotify/control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action, delta }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error);
      if (sequence !== latestControl.current) return;
      if (action === 'seek') playbackClock.current.seek(result.position);
      if (result.player) remotePlayer.current = result.player;
      setNotice(action === 'volume' ? `Spotify 音量 ${result.volume}%` : action === 'seek' ? `播放进度 ${timeLabel(result.position)}` : '已发送播放／暂停指令');
      window.dispatchEvent(new Event('spotify-control-updated'));
    } catch (error) { setNotice(error instanceof Error ? error.message : 'Spotify 暂时无法调整'); }
  }
  async function seekLyrics(time: number) {
    try {
      const response = await fetch('/api/spotify/control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'seek-to', position: Math.max(0, time - offset) }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error);
      playbackClock.current.seek(result.position);
      if (result.player) remotePlayer.current = result.player;
      window.dispatchEvent(new Event('spotify-control-updated'));
      setNotice(`Spotify 已跳到 ${timeLabel(result.position)}`);
    } catch (error) { setNotice(error instanceof Error ? error.message : '无法跳转歌词'); }
  }

  async function seekTrack(position: number) {
    try {
      const response = await fetch('/api/spotify/control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'seek-to', position: Math.max(0, position) }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error);
      playbackClock.current.seek(result.position);
      if (result.player) remotePlayer.current = result.player;
      window.dispatchEvent(new Event('spotify-control-updated'));
      setNotice(`播放进度 ${timeLabel(result.position)}`);
    } catch (error) { setNotice(error instanceof Error ? error.message : 'Spotify 暂时无法跳转'); }
  }
  async function setVolume(volume: number) {
    try {
      const response = await fetch('/api/spotify/control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'volume-to', volume }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error);
      if (result.player) { remotePlayer.current = result.player; setPlayer(result.player); }
      window.dispatchEvent(new Event('spotify-control-updated')); setNotice(`Spotify 音量 ${result.volume}%`);
    } catch (error) { setNotice(error instanceof Error ? error.message : '无法调整音量，请使用设备音量键'); }
  }
  const wakeControls = () => { lastInput.current = Date.now(); setQuiet(false); };
  const touch = useTouchPlayback({
    enabled: (STANDALONE || isFullscreen) && snapshot.connected && !settings && !library && !studio && !timeline,
    songKey: key, duration: snapshot.duration ?? 0, position: () => currentTime.get(),
    volume: () => remotePlayer.current.volume ?? null,
    canVolume: () => remotePlayer.current.available === true && remotePlayer.current.supportsVolume !== false && remotePlayer.current.volume != null,
    seek: position => void seekTrack(position), setVolume: value => void setVolume(value),
    toggle: () => void sendControl('toggle', 0), wake: wakeControls,
    tap: () => { lastInput.current = quiet ? Date.now() : Number.NEGATIVE_INFINITY; setQuiet(!quiet); },
  });
  // 渲染器拿到的回调保持同一个引用，避免每次重渲染都让动画重新接收参数。
  const seekLyricsRef = useRef(seekLyrics); seekLyricsRef.current = seekLyrics;
  const onLyricLineSeek = useCallback((time: number) => void seekLyricsRef.current(time), []);

  async function fullscreen() {
    const root = document.documentElement as HTMLElement & { webkitRequestFullscreen?: () => Promise<void> | void };
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else if ((document as any).webkitFullscreenElement) await (document as any).webkitExitFullscreen();
      else if (root.requestFullscreen) await root.requestFullscreen();
      else if (root.webkitRequestFullscreen) await root.webkitRequestFullscreen();
      else throw new Error('unsupported');
    } catch {
      // 平板和手机没有 F11：给出对应设备上的全屏办法。
      setNotice(STANDALONE ? '系统未允许完整全屏。请在 Safari 中打开后点全屏；主屏幕模式本身可能保留状态栏' : '当前窗口未允许全屏，请重试');
    }
  }
  function changeOffset(value: number) {
    const next = Math.round(Math.max(-10, Math.min(10, value)) * 20) / 20;
    setOffset(next); store(`offset:${key}`, String(next));
    return next;
  }
  const nudgeOffset = useRef((delta: number) => {});
  nudgeOffset.current = delta => { const next = changeOffset(offset + delta); setNotice(`歌词时间 ${next > 0 ? '+' : ''}${next.toFixed(2)} 秒`); };
  async function importFile(file?: File) {
    if (!file) return;
    const song = snapshotRef.current;
    if (!song.connected) { setNotice('请先在 Spotify 播放一首歌'); return; }
    if (file.size > 2 * 1024 * 1024) { setNotice('歌词文件不能超过 2 MB'); return; }
    const format = file.name.split('.').pop()?.toLowerCase() ?? '';
    if (!['lrc', 'ttml', 'yrc', 'qrc', 'krc'].includes(format)) { setNotice('请选择 LRC / TTML / YRC / QRC / KRC 文本歌词'); return; }
    try {
      const text = await file.text();
      const parsed = parseLyricsByFormat(format as any, text);
      if (!parsed.lines.length) throw new Error('这份文件没有可识别的时间歌词');
      const response = await fetch('/api/import', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lines: text, format, title: song.title, artist: song.artist }) });
      const value = await response.json();
      if (!response.ok) throw new Error(value.error);
      if (keyOf(snapshotRef.current) === keyOf(song)) applyLyrics(value);
      setNotice('已为这首歌保存本地歌词');
    } catch (error) { setNotice(error instanceof Error ? error.message : '导入失败，请重试'); }
    if (fileRef.current) fileRef.current.value = '';
  }

  // 主题只在色调、封面主题或外观设置变化时重建；每次都新建会让各个动画每秒数次重新接收整首歌的参数。
  const theme = useMemo<Theme>(() => {
    // 新封面取色完成前沿用上一首的封面主题，切歌时不会先闪回固定色调。
    const base = palette === COVER_PALETTE ? coverTheme?.theme ?? palettes[0] : palettes[palette];
    return { ...base, fontStyle: saved('folia_spotify_font_style', base.fontStyle) as Theme['fontStyle'], fontWeight: Number(saved('folia_spotify_font_weight', '')) || undefined };
  }, [palette, coverTheme, appearance]);
  const showEmpty = !snapshot.connected || !lines.length;
  const hdrDisplay = useHdrDisplay(STANDALONE && hdrEnabled);
  const hdrStatus = useHdrGlyphFill(STANDALONE && hdrEnabled, mode, hdrDisplay);
  const hdrLyrics = hdrStatus === 'active';
  const hanabiHdr = useMemo(() => ({ requested: hdrDisplay, report: setHanabiHdrStatus }), [hdrDisplay]);
  const hdrLabel = mode === 'hanabi' && hdrDisplay ? {
    starting: '正在开启花火 HDR…',
    active: '花火 HDR 已启用，原有辉光的亮部随动画提亮。',
    unavailable: '当前浏览器未能开启花火 HDR，继续显示原动画。',
  }[hanabiHdrStatus] : {
    starting: '正在检测当前显示环境…',
    sdr: '当前屏幕或显示模式未提供 HDR，歌词保持动画自带的普通高亮。',
    unavailable: '当前浏览器无法加载 HDR 字形填充，歌词保持原有动画。',
    unsupported: '当前动画暂不支持 HDR 字形填充，仍使用原有动画和高亮。',
    active: 'HDR 字形高光已启用。唱到的字换用 HDR 填充，原动画继续播放。',
  }[mode === 'hanabi' ? 'sdr' : hdrStatus];
  function changeMode(value: string) { setMode(value); store('folia_spotify_mode', value); visuals.settings.handleSetVisualizerMode(value); }
  function changeFontScale(value: number) { setFontScale(value); store('folia_spotify_font', String(value)); }
  return <main {...touch.handlers} className={`companion ${quiet && !settings && !library && !studio && !timeline ? 'quiet' : ''} ${isFullscreen ? 'element-fullscreen' : ''}`}
    style={{ background: theme.backgroundColor, ['--folia-hdr-image' as string]: hdrLyrics ? hdrGlyphImage : undefined }}
    data-hdr-fill={hdrLyrics ? '' : undefined} data-palette={palette === COVER_PALETTE ? 'cover' : 'fixed'}>
    {snapshot.connected && <div className="stage" aria-label="Folia 歌词动画" data-style={mode} data-background={visuals.background.mode || 'latent'}
      onClick={event => { const target = (event.target as HTMLElement).closest<HTMLElement>('[data-lyric-time]'); if (target) { const time = Number(target.dataset.lyricTime); const line = lines.find(value => value.startTime <= time && value.endTime >= time); void seekLyrics(lyrics.wordTimed ? time : line?.startTime ?? time); } }}>
      <RecoveringBoundary>
      <HdrGlyphFillContext.Provider value={hdrLyrics}>
      <HanabiHdrContext.Provider value={hanabiHdr}>
      <VisualizerRenderer mode={mode} animateStyleSwitch currentTime={clock} duration={snapshot.duration}
        currentLineIndex={lineIndex} lines={lines.length ? lines : NO_LYRIC_LINES} theme={theme} audioPower={power} audioBands={bands}
        songTitle={snapshot.title} songArtist={snapshot.artist} songAlbum={snapshot.album} seed={key}
        paused={!snapshot.playing} showText={lines.length > 0} isPlayerChromeHidden hideTranslationSubtitle={false}
        coverUrl={snapshot.coverUrl} visualizerTunings={visuals.tunings} {...visuals.styleAssets}
        onLyricLineSeek={onLyricLineSeek}
        visualizerOpacity={visuals.settings.visualizerOpacity}
        lyricsFontScale={fontScale} subtitleFontScale={0.85} isPreviewMode
        background={visuals.background} />
      </HanabiHdrContext.Provider>
      </HdrGlyphFillContext.Provider>
      </RecoveringBoundary>
    </div>}
    <header className="top chrome">
      <div className="brand"><span className="mark">◉</span><span>FOLIA <small>FOR SPOTIFY</small></span></div>
      <div className="top-actions">
        <span className={`connection ${snapshot.connected ? 'online' : ''}`}><i/>{snapshot.connected ? snapshot.playing ? '跟随播放' : '已暂停' : '等待 Spotify'}</span>
        <button onClick={() => setLibrary(true)} aria-label="打开 Spotify 歌单" title="你的 Spotify 歌单"><LibraryBig size={18}/></button>
        {(fullscreenSupported || STANDALONE) && <button onClick={() => void fullscreen()} aria-label="全屏" title={isFullscreen ? '退出完整全屏' : '完整全屏 · 隐藏系统状态栏'}>{isFullscreen ? <Minimize size={17}/> : <Maximize size={17}/>}</button>}
        <button onClick={() => setSettings(!settings)} aria-label="显示设置" title="显示设置"><SlidersHorizontal size={17}/></button>
      </div>
    </header>
    {showEmpty && <section className={`empty ${snapshot.connected ? 'lyrics-unavailable' : ''}`} aria-live="polite">
      <div className="empty-orbit"><span>♪</span></div>
      <h1>{snapshot.connected ? snapshot.title : '让歌词，跟着音乐流动'}</h1>
      <p>{snapshot.connected ? lyrics.message || '等待歌词' : snapshot.message}</p>
      {lyrics.plain && <div className="plain-lyrics">{lyrics.plain}</div>}
      {snapshot.connected && lyrics.status !== 'loading' && <div className="empty-actions">
        <button onClick={() => setRefresh(value => value + 1)}>重新匹配</button>
        <button onClick={() => fileRef.current?.click()}>导入歌词</button>
      </div>}
      {!snapshot.connected && <button className="open-spotify" onClick={()=>setLibrary(true)}>连接 Spotify</button>}
    </section>}
    <footer className="bottom chrome">
      <div className="song">{snapshot.coverUrl ? <img className="song-cover" key={snapshot.coverUrl} src={snapshot.coverUrl} alt=""/> : <span className="spotify-dot">●</span>}<div><strong>{snapshot.title || 'Spotify 歌词动画'}</strong><span>{snapshot.artist || 'Spotify 播放 · Folia 呈现'}</span></div></div>
      <div className="playback-center"><PlaybackControls onPlayer={value => { remotePlayer.current = value; setPlayer(value); }} onNotice={setNotice} onTimeline={() => setTimeline(true)} hasLyrics={lines.length > 0}/>
      <TrackProgress duration={snapshot.duration ?? 0} onSeek={seekTrack}/></div>
      <div className="lyric-kind">{lines.length > 0 ? lyrics.wordTimed ? `${lyrics.source} · 逐字同步` : `${lyrics.source} · 逐行同步 / 字效估算` : '仅显示歌词 · 声音来自 Spotify'}</div>
    </footer>
    {settings && <div className="panel-backdrop" onClick={() => setSettings(false)}><aside className="settings" role="dialog" aria-modal="true" aria-label="歌词显示设置" onClick={event => event.stopPropagation()}>
      <div className="panel-title"><h2>让画面合你心意</h2><button onClick={() => setSettings(false)} aria-label="关闭设置">×</button></div>
      <label>歌词动画<select aria-label="歌词动画样式" value={mode} onChange={event => changeMode(event.target.value)}>
        {VISUALIZER_REGISTRY.map(entry => <option key={entry.mode} value={entry.mode}>{i18n.t(entry.labelKey) || entry.labelFallback}</option>)}
      </select></label>
      <label>背景<select aria-label="背景样式" value={visuals.background.mode || 'latent'} onChange={event => visuals.settings.handleSetVisualizerBackgroundMode(event.target.value)}>
        {VISUALIZER_BACKGROUND_REGISTRY.map(entry => <option key={entry.mode} value={entry.mode}>{i18n.t(entry.labelKey) || entry.labelFallback}</option>)}
      </select></label>
      <div className="studio-buttons"><button onClick={() => { setSettings(false); setStudio('visualizer'); }}>原版动画工作台</button><button onClick={() => { setSettings(false); setStudio('background'); }}>背景与图片设置</button></div>
      <label>色调<div className="palette-row">{paletteNames.map((name, index) => <button key={name} className={palette === index ? 'selected' : ''} onClick={() => { setPalette(index); store('folia_spotify_palette', String(index)); }}>{name}</button>)}</div></label>
      <label>歌词大小 <span>{Math.round(fontScale * 100)}%</span><input aria-label="歌词大小" type="range" min="0.6" max="1.5" step="0.05" value={fontScale} onChange={event => changeFontScale(Number(event.target.value))}/></label>
      <label>画面亮度 <span>{touch.brightness}%</span><input aria-label="画面亮度" type="range" min="25" max="100" value={touch.brightness} onChange={event => touch.changeBrightness(Number(event.target.value))}/></label>
      <p className="setting-note">只调整本页画面的明暗，不更改 iPad 系统亮度。</p>
      {STANDALONE && <>
        <label className="online-switch"><span>HDR 高光</span><input aria-label="HDR 高光" type="checkbox" checked={hdrEnabled} onChange={event => {
          const enabled = event.target.checked;
          setHanabiHdrStatus('starting');
          setHdrEnabled(enabled);
          store('folia_hdr_glow', enabled ? 'on' : 'off');
        }}/></label>
        <p className="setting-note" role="status">{hdrEnabled ? hdrLabel : mode === 'hanabi' ? '在支持的设备上，花火原有辉光的亮部可以亮过普通白色。' : '在支持的屏幕和动画中，唱到的歌词可以亮过普通白色。'}</p>
      </>}
      <label>Spotify 音量 <span>{player.volume == null ? '不可用' : `${volumePreview ?? player.volume}%`}</span><input aria-label="Spotify 音量" type="range" min="0" max="100" value={volumePreview ?? player.volume ?? 0} disabled={!player.available || player.supportsVolume === false || player.volume == null}
        onChange={event => setVolumePreview(Number(event.target.value))}
        onPointerUp={event => { void setVolume(Number(event.currentTarget.value)).finally(() => setVolumePreview(null)); }} onPointerCancel={() => setVolumePreview(null)}
        onKeyUp={event => { if (['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End','PageUp','PageDown'].includes(event.key)) void setVolume(Number(event.currentTarget.value)).finally(() => setVolumePreview(null)); }}/></label>
      <p className="setting-note">轻点画面隐藏／呼出按键；双击播放／暂停；横滑预览进度，松手跳转；左侧竖滑调画面亮度，右侧竖滑调 Spotify 音量。不支持远程音量的播放设备请用音量键。全屏按钮会申请隐藏系统状态栏，系统退出全屏后可再次点入。</p>
      <label>歌词时间微调 <span>{offset > 0 ? '+' : ''}{offset.toFixed(2)} 秒</span><div className="offset-row"><button onClick={() => changeOffset(offset - 0.25)}>慢 0.25</button><button onClick={() => changeOffset(offset - 0.05)}>慢 0.05</button><button onClick={() => changeOffset(0)}>复位</button><button onClick={() => changeOffset(offset + 0.05)}>快 0.05</button><button onClick={() => changeOffset(offset + 0.25)}>快 0.25</button></div></label>
      <div className="divider"/>
      <label className="online-switch"><span>自动匹配歌词</span><input aria-label="自动匹配歌词" type="checkbox" checked={snapshot.allowOnline ?? false} onChange={async event => {
        const allowOnline = event.target.checked;
        try { const response = await fetch('/api/settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ allowOnline }) }); if (!response.ok) throw new Error(); setSnapshot(value => ({ ...value, allowOnline })); }
        catch { setNotice('设置未能保存，请重试'); }
      }}/></label>
      <p className="setting-note">开启后，将当前歌名、歌手发送到 LRCLIB 查找歌词。歌词会保存在这台设备。</p>
      <button className="import" onClick={() => fileRef.current?.click()}>为当前歌曲导入歌词</button>
      <p className="setting-note">支持 LRC、TTML、YRC、QRC、KRC 文本。逐字时间来自歌词文件；普通 LRC 的字效由 Folia 估算。</p>
      <p className="credits">Folia 原版动画 · 本机独立窗口<br/>音乐由 Spotify 播放</p>
      <p className="setting-note">播放页方向键：← / → 调整 5 秒，↑ / ↓ 调整音量；[ / ] 微调歌词 0.05 秒；点进度条可跳转。没有同步歌词时，仍显示你选择的背景；工作台可预览全部动画。</p>
    </aside></div>}
    {notice && <button className="notice" key={notice} onClick={() => setNotice('')}>{notice}</button>}
    {library && <Library close={() => setLibrary(false)}/>}
    {studio && <VisualStudio theme={theme} mode={mode} section={studio} fontScale={fontScale} onMode={changeMode} onFontScale={changeFontScale} onClose={() => setStudio(null)}/>}
    {timeline && <div className="lyric-timeline"><LyricsTimelineModal isOpen onClose={() => setTimeline(false)} lyrics={{ lines }} duration={snapshot.duration ?? 0} currentTime={clock} onSeek={time => void seekLyrics(time)} theme={theme} isDaylight={false}/></div>}
    <div className="screen-dimmer" aria-hidden="true" style={{ opacity: (100 - touch.brightness) / 100 }}/>
    {touch.hud && <div className="gesture-hud" role="status">{touch.hud}</div>}
    <input ref={fileRef} type="file" accept=".lrc,.ttml,.yrc,.qrc,.krc" className="file-input" aria-label="导入歌词文件" onChange={event => void importFile(event.target.files?.[0])}/>
  </main>;
}

// 进度条单独订阅歌词时钟，每 250 毫秒只重绘自己，不再带着整个动画层一起重渲染。
function TrackProgress({ duration, onSeek }: { duration: number; onSeek: (position: number) => void }) {
  const [position, setPosition] = useState(() => currentTime.get());
  const [preview, setPreview] = useState<number | null>(null);
  const dragging = useRef(false);
  const releasedUntil = useRef(0);
  useEffect(() => {
    const timer = setInterval(() => setPosition(currentTime.get()), 250);
    return () => clearInterval(timer);
  }, []);
  const shown = Math.max(0, Math.min(duration, preview ?? position));
  const percent = duration ? shown / duration * 100 : 0;
  return <div className="track-progress"><span>{timeLabel(shown)}</span>
    <input className="track-range" type="range" aria-label="播放进度" aria-valuetext={`${timeLabel(shown)} / ${timeLabel(duration)}`}
      min={0} max={duration || 1} step="0.1" value={shown} disabled={!duration}
      style={{ '--progress': `${percent}%` } as React.CSSProperties}
      onPointerDown={() => { dragging.current = true; }}
      onChange={event => { if (Date.now() < releasedUntil.current) return; setPreview(Number(event.target.value)); }}
      onPointerUp={event => { if (dragging.current) { dragging.current = false; releasedUntil.current = Date.now() + 200; onSeek(Number(event.currentTarget.value)); setPreview(null); } }}
      onKeyUp={event => { if (['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End','PageUp','PageDown'].includes(event.key)) { onSeek(Number(event.currentTarget.value)); setPreview(null); } }}
      onPointerCancel={() => { dragging.current = false; releasedUntil.current = Date.now() + 200; setPreview(null); }}
      onBlur={() => { dragging.current = false; setPreview(null); }}/>
    <span>{timeLabel(duration)}</span></div>;
}

// Folia 上游在“静止”与其他动画之间快速来回切换时，偶尔会在过渡里读到尚未就绪的图层而报错（与本应用改动无关，
// 只切换内置动画也会出现）。这类错误是一瞬间的：这里接住后重新挂载动画层，几秒内连续失败三次才交给外层的恢复提示。
class RecoveringBoundary extends React.Component<{ children: React.ReactNode }, { attempt: number; failed: boolean }> {
  state = { attempt: 0, failed: false };
  failures: number[] = [];
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(error: unknown) {
    const now = Date.now(); this.failures = [...this.failures.filter(time => now - time < 10000), now];
    if (this.failures.length >= 3) throw error;
    setTimeout(() => this.setState(state => ({ attempt: state.attempt + 1, failed: false })), 120);
  }
  render() { return this.state.failed ? null : <React.Fragment key={this.state.attempt}>{this.props.children}</React.Fragment>; }
}

class Boundary extends React.Component<{ children: React.ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() { return this.state.failed ? <div className="fatal">动画暂时无法显示。<button onClick={() => { store('folia_spotify_mode', 'classic'); location.reload(); }}>恢复默认动画</button></div> : this.props.children; }
}
createRoot(document.getElementById('root')!).render(<Boundary><App/></Boundary>);
