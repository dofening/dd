import { spawn } from 'node:child_process';
import { rename, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
// 构建手机 / 平板独立版到 dist-standalone/，并把入口改名为 index.html（GitHub Pages 和安卓 App 都从它打开）。
const root = path.dirname(fileURLToPath(import.meta.url));
const out = path.join(root, 'dist-standalone');
const code = await new Promise(resolve => spawn(process.execPath, [path.join(root, 'node_modules/vite/bin/vite.js'), 'build', '--configLoader', 'native', '--config', 'vite.standalone.config.mjs'], { cwd: root, stdio: 'inherit' }).on('exit', resolve));
if (code !== 0) process.exit(code ?? 1);
await rename(path.join(out, 'standalone.html'), path.join(out, 'index.html'));
await stat(path.join(out, 'sw.js'));
console.log('独立版已生成：dist-standalone/index.html');
