import React, { useEffect, useRef, useState } from 'react';
import { Grid3DSlider } from './upstream/src/library/suites/grid/home/Grid3DSlider';
import { artUrl, assetUrl } from './platform';

type Playlist = { id: string; name: string; count: number; owner: string; uri: string; cover?: string };
type Track = { id: string; title: string; artist: string; duration: number; uri: string; cover?: string; album?: string };
async function api(url: string, options?: RequestInit) {
  const response = await fetch(url, options); const value = await response.json();
  if (!response.ok) throw new Error(value.error || '暂时连接不上 Spotify'); return value;
}
export default function Library({ close }: { close: () => void }) {
  const [connection, setConnection] = useState({ connected: false, configured: false, redirectUri: '' });
  const [clientId, setClientId] = useState('');
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [selected, setSelected] = useState<Playlist | null>(null);
  const [tracks, setTracks] = useState<Track[]>([]);
  const [nextOffset, setNextOffset] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('');
  const [syncedAt, setSyncedAt] = useState(0);
  const [complete, setComplete] = useState(true);
  const [setup, setSetup] = useState(false);
  const [focused, setFocused] = useState(0);
  const [libraryView, setLibraryView] = useState(() => localStorage.getItem('spotify_library_view') || '3d');
  const [songView, setSongView] = useState(() => localStorage.getItem('spotify_song_view') || '3d');
  const [focusedTrack, setFocusedTrack] = useState(0);
  const panel = useRef<HTMLDivElement>(null);
  const trackRequest = useRef(0);

  async function sync(force = false) {
    setBusy(true); setError('');
    try {
      const state = await api('/api/spotify/status'); setConnection(state);
      if (state.connected) {
        const data = await api(`/api/spotify/playlists${force ? '?refresh=1' : ''}`);
        setPlaylists([{ id: 'liked', name: '已点赞的歌曲', count: 0, owner: '你的音乐库', uri: 'spotify:collection:tracks', cover: assetUrl('liked.svg') }, ...data.items]);
        setSyncedAt(data.syncedAt); setComplete(data.complete);
      }
    } catch (error) { setError(error instanceof Error ? error.message : '同步失败'); }
    finally { setBusy(false); }
  }
  useEffect(() => { void sync(); const timer = setInterval(() => void sync(), 5 * 60 * 1000); return () => clearInterval(timer); }, []);
  useEffect(() => { panel.current?.focus({ preventScroll: true }); }, []);
  useEffect(() => {
    if (connection.connected) return;
    const timer = setInterval(() => void sync(), 3000);
    return () => clearInterval(timer);
  }, [connection.connected]);
  useEffect(() => { setFocusedTrack(0); panel.current?.focus({ preventScroll: true }); }, [selected?.id]);
  useEffect(() => {
    panel.current?.querySelector<HTMLElement>('.is-keyboard-selected')?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }, [focused, focusedTrack, selected?.id, libraryView, songView]);
  async function connect() {
    setBusy(true); setError('');
    try {
      const result = await api('/api/spotify/connect', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ clientId: clientId.trim() || undefined }) });
      location.assign(result.url);
    } catch (error) { setError(error instanceof Error ? error.message : '连接失败'); setSetup(true); }
    finally { setBusy(false); }
  }
  async function load(playlist: Playlist, offset = 0) {
    const requestId = ++trackRequest.current;
    setSelected(playlist); setBusy(true); setError('');
    if (!offset) setTracks([]);
    try {
      const data = await api(`/api/spotify/tracks?id=${encodeURIComponent(playlist.id)}&offset=${offset}`);
      if (requestId !== trackRequest.current) return;
      setTracks(previous => offset ? [...previous, ...data.items] : data.items); setNextOffset(data.nextOffset);
    } catch (error) { if (requestId === trackRequest.current) { setNextOffset(null); setError(error instanceof Error ? error.message : '无法读取歌曲'); } }
    finally { if (requestId === trackRequest.current) setBusy(false); }
  }
  async function playTrack(event: React.MouseEvent | null, track: Track) {
    event?.preventDefault(); if (busy) return; setBusy(true); setError('');
    try {
      const index = Math.max(0, tracks.findIndex(item => item.id === track.id));
      const queueIds = tracks.slice(Math.max(0, index - 20), Math.max(0, index - 20) + 100).map(item => item.id);
      await api('/api/spotify/control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'play-track', id: track.id, playlistId: selected?.id, queueIds }) });
      window.dispatchEvent(new Event('spotify-control-updated'));
      close();
    } catch (error) { setError(error instanceof Error ? error.message : 'Spotify 未能播放，请检查连接后再试'); }
    finally { setBusy(false); }
  }
  async function playPlaylist() {
    if (!selected || busy) return;
    if (selected.id === 'liked') { if (tracks[0]) await playTrack(null, tracks[0]); return; }
    setBusy(true); setError('');
    try {
      await api('/api/spotify/control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'play-playlist', playlistId: selected.id }) });
      window.dispatchEvent(new Event('spotify-control-updated')); close();
    } catch (error) { setError(error instanceof Error ? error.message : '暂时无法播放歌单'); }
    finally { setBusy(false); }
  }
  function backToPlaylists() { trackRequest.current++; setBusy(false); setSelected(null); setTracks([]); setFilter(''); setError(''); panel.current?.focus(); }
  const shown = selected ? tracks.filter(track => `${track.title} ${track.artist}`.toLocaleLowerCase().includes(filter.toLocaleLowerCase())) :
    playlists.filter(playlist => playlist.name.toLocaleLowerCase().includes(filter.toLocaleLowerCase()));
  const art = (value?: string) => artUrl(value);
  function keyboard(event: React.KeyboardEvent) {
    const target = event.target as HTMLElement;
    if (target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName) || event.altKey || event.ctrlKey || event.metaKey) return;
    if (event.key === 'Backspace' && selected) { event.preventDefault(); event.stopPropagation(); backToPlaylists(); return; }
    if (event.key === 'Enter' || event.key === ' ') {
      if (target.closest('button,a') && !target.closest('[data-library-choice]')) return;
      event.preventDefault(); event.stopPropagation(); if (event.repeat || busy) return;
      if (selected) { const track = (shown as Track[])[Math.min(focusedTrack, shown.length - 1)]; if (track) void playTrack(null, track); }
      else { const playlist = (shown as Playlist[])[Math.min(focused, shown.length - 1)]; if (playlist) void load(playlist); }
      return;
    }
    if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key) || !shown.length) return;
    event.preventDefault(); event.stopPropagation(); panel.current?.focus({ preventScroll: true });
    let step = event.key === 'ArrowLeft' || event.key === 'ArrowUp' ? -1 : 1;
    if (!selected && libraryView === 'grid' && (event.key === 'ArrowUp' || event.key === 'ArrowDown')) {
      const cards = Array.from(panel.current?.querySelectorAll('.playlist-card') ?? []);
      const firstTop = cards[0]?.getBoundingClientRect().top ?? 0;
      const row = cards.findIndex(card => card.getBoundingClientRect().top > firstTop + 5);
      step *= row > 0 ? row : Math.max(1, cards.length);
    }
    if (selected) setFocusedTrack(value => Math.max(0, Math.min(shown.length - 1, value + step)));
    else setFocused(value => Math.max(0, Math.min(shown.length - 1, value + step)));
  }
  return <div ref={panel} tabIndex={-1} onKeyDownCapture={keyboard} className="library-backdrop" role="dialog" aria-modal="true" aria-label="Spotify 歌单">
    <section className="library-panel">
      <header className="library-header"><div><span className="eyebrow">YOUR SPOTIFY</span><h2>{selected ? selected.name : '你的音乐库'}</h2></div>
        <div className="library-actions">{selected && <button onClick={backToPlaylists}>全部歌单</button>}<button onClick={close} aria-label="关闭歌单">×</button></div></header>
      {!connection.connected ? <div className="spotify-connect">
        <h3>把你的歌单带到这里</h3><p>通过 Spotify 官方授权同步音乐库，并在这里直接控制播放。</p>
        <button className="connect-button" onClick={() => void connect()} disabled={busy}>连接 Spotify</button>
        {(!connection.configured || setup) && <div className="spotify-setup">
          <p>首次使用需要在 Spotify 为本机窗口登记应用。打开官方设置，新建应用并添加下面的回调地址，再将 Client ID 填入此处。</p>
          <a href="https://developer.spotify.com/dashboard" target="_blank" rel="noreferrer">打开 Spotify 官方应用设置 ↗</a>
          <label>回调地址<input readOnly value={connection.redirectUri || 'http://127.0.0.1:18981/spotify/callback'} aria-label="Spotify 回调地址"/></label>
          <label>Client ID<input value={clientId} onChange={event => setClientId(event.target.value)} placeholder="Spotify 应用的公开标识，无需密钥" aria-label="Spotify Client ID" spellCheck={false}/></label>
          <p className="setting-note">无需 Client Secret、密码或 Cookie。授权凭据仅存在运行内存中，关闭服务后需要重新授权。</p>
        </div>}
      </div> : <>
        <div className="library-toolbar"><input placeholder={selected ? '搜索当前已加载的歌曲' : '搜索歌单'} aria-label="搜索音乐库" value={filter} onChange={event => setFilter(event.target.value)}/>
          {!selected && <button onClick={() => { const next = libraryView === '3d' ? 'grid' : '3d'; setLibraryView(next); localStorage.setItem('spotify_library_view', next); }}>{libraryView === '3d' ? '平铺歌单' : '立体歌单'}</button>}
          {selected && <button onClick={() => { const next = songView === '3d' ? 'list' : '3d'; setSongView(next); localStorage.setItem('spotify_song_view', next); }}>{songView === '3d' ? '列表选歌' : '立体选歌'}</button>}
          <button onClick={() => void (selected ? load(selected) : sync(true))} disabled={busy}>同步</button>
          {!selected && <button onClick={async () => { await api('/api/spotify/disconnect', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); setConnection(value => ({ ...value, connected: false })); setPlaylists([]); }}>断开</button>}
        </div>
        <div className="library-note">{busy ? '正在处理…' : syncedAt ? `上次同步 ${new Date(syncedAt).toLocaleTimeString('zh-CN', {timeZone:'Asia/Shanghai'})} · 方向键选择，空格 / 回车确认${selected ? '，退格返回歌单' : ''}` : ''}{!complete && ' · 歌单较多，当前仅显示已读取部分'}</div>
        {selected ? <><div className={songView === '3d' ? 'spotify-original-carousel' : 'tracks-list'} aria-label={songView === '3d' ? 'Folia 原版立体选歌' : '歌曲列表'}>
          {songView === '3d' ? <Grid3DSlider items={(shown as Track[]).map(track => ({id:track.id,name:track.title,coverUrl:art(track.cover || selected.cover),description:track.artist,summary:track.album,type:'song'}))}
            focusedIndex={Math.min(focusedTrack,Math.max(0,shown.length-1))} onFocusedIndexChange={setFocusedTrack} onSelect={item => {const track=tracks.find(value=>value.id===item.id);if(track)void playTrack(null,track);}}
            isInteractive={!busy} isDaylight={false} isLoading={busy && !tracks.length}/>
          : (shown as Track[]).map((track, index) => <button data-library-choice key={`${track.id}-${index}`} className={`track-row ${index === focusedTrack ? 'is-keyboard-selected' : ''}`} title="直接播放" onFocus={()=>setFocusedTrack(index)} onClick={event => void playTrack(event, track)} disabled={busy}>
          <span className="track-number">{index + 1}</span><span><strong>{track.title}</strong><small>{track.artist}</small></span><span className="track-duration">{Math.floor(track.duration / 60)}:{String(Math.floor(track.duration % 60)).padStart(2, '0')} ↗</span>
        </button>)}</div><div className="song-library-footer">{nextOffset !== null && <button disabled={busy} onClick={() => void load(selected, nextOffset)}>加载更多歌曲</button>}
          <button className="open-playlist" disabled={busy} onClick={()=>void playPlaylist()}>直接播放整个歌单</button></div></> : libraryView === '3d' ? <div className="spotify-original-carousel" aria-label="Folia 原版立体歌单">
            <Grid3DSlider items={(shown as Playlist[]).map(playlist => ({ id: playlist.id, name: playlist.name,
              coverUrl: artUrl(playlist.cover),
              description: playlist.owner, trackCount: playlist.count, type: 'playlist' }))}
              focusedIndex={focused} onFocusedIndexChange={setFocused}
              onSelect={item => { const playlist = playlists.find(value => value.id === item.id); if (playlist) { setFilter(''); void load(playlist); } }}
              isInteractive isDaylight={false} isLoading={busy && playlists.length === 0}/>
          </div> : <div className="playlist-grid">{(shown as Playlist[]).map((playlist,index) => <button data-library-choice key={playlist.id} className={`playlist-card ${index===focused?'is-keyboard-selected':''}`} onFocus={()=>setFocused(index)} onClick={() => { setFilter(''); void load(playlist); }}>
          {playlist.cover ? <img src={artUrl(playlist.cover)} alt="" loading="lazy"/> : <div className="playlist-placeholder">{playlist.id === 'liked' ? '♥' : '♫'}</div>}
          <strong>{playlist.name}</strong><small>{playlist.owner}{playlist.count ? ` · ${playlist.count} 首` : ''}</small></button>)}</div>}
      </>}
      {error && <p className="library-error" role="status">{error}</p>}
    </section>
  </div>;
}
