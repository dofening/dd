// 独立版（手机 / 平板）界面检查：本地静态服务提供 dist-standalone/，用模拟的 Spotify 与 LRCLIB 响应，
// 在 iPhone、iPad 尺寸下检查登录回跳、跟随播放、歌词显示（含繁转简）、播放控制和全部动画能否打开。
// 用法：node tests/standalone-ui.cjs [Playwright 模块路径]
const http = require('node:http'); const fs = require('node:fs'); const path = require('node:path'); const assert = require('node:assert/strict');
const { chromium, devices } = require(process.argv[2] || 'playwright');
const root = path.resolve(__dirname, '..', 'dist-standalone'); const shots = path.resolve(__dirname, '..', 'checks');
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.woff2': 'font/woff2', '.wasm': 'application/wasm' };
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x'); let file = path.join(root, decodeURIComponent(url.pathname));
  if (!file.startsWith(root)) { res.writeHead(403).end(); return; }
  if (fs.existsSync(file) && fs.statSync(file).isDirectory()) file = path.join(file, 'index.html');
  if (!fs.existsSync(file)) { res.writeHead(404).end(); return; }
  res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' }); fs.createReadStream(file).pipe(res);
});
const lrc = Array.from({ length: 12 }, (_, i) => `[00:${String(i * 5).padStart(2, '0')}.00]${['戀戀不捨又念念不忘', 'hold me tight 別說再見', '覆蓋了屬於我的海洋'][i % 3]}${i}`).join('\n');

(async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}/`;
  const browser = await chromium.launch();
  const results = [];
  for (const [name, device] of [['iphone', devices['iPhone 13']], ['ipad', devices['iPad (gen 7) landscape']]]) {
    const context = await browser.newContext({ ...device });
    const page = await context.newPage();
    const errors = []; const commands = []; let position = 12, playing = true, authorized = false;
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => { if (message.type() === 'error' && /unsafe-eval|TypeError|ReferenceError/.test(message.text())) errors.push(message.text().slice(0, 200)); });
    await page.route('https://accounts.spotify.com/authorize**', route => {
      const url = new URL(route.request().url()); authorized = url.searchParams.get('code_challenge_method') === 'S256';
      return route.fulfill({ status: 302, headers: { Location: `${url.searchParams.get('redirect_uri')}?code=test-code&state=${url.searchParams.get('state')}` } });
    });
    await page.route('https://accounts.spotify.com/api/token', route => route.fulfill({ json: { access_token: 'test-access', refresh_token: 'test-refresh', expires_in: 3600, scope: 'user-read-playback-state' } }));
    await page.route('https://api.spotify.com/v1/**', async route => {
      const url = new URL(route.request().url()); const method = route.request().method();
      if (url.pathname === '/v1/me/player' && method === 'GET') return route.fulfill({ json: { is_playing: playing, progress_ms: position * 1000, shuffle_state: false, repeat_state: 'off',
        device: { id: 'pad', name: 'iPad', type: 'Tablet', volume_percent: 60 }, item: { name: '致你', duration_ms: 256000, artists: [{ name: 'Yihuik苡慧' }], album: { name: '致你', images: [{ url: 'https://i.scdn.co/image/test' }] } } } });
      if (url.pathname === '/v1/me/playlists') return route.fulfill({ json: { items: [{ id: 'a'.repeat(22), name: '练习歌单', images: [], items: { total: 1 }, owner: { display_name: '测试' } }], next: null } });
      commands.push(`${method} ${url.pathname}`);
      if (url.pathname.endsWith('/pause')) playing = false; if (url.pathname.endsWith('/play')) playing = true;
      return route.fulfill({ status: 204, body: '' });
    });
    await page.route('https://i.scdn.co/**', route => route.fulfill({ contentType: 'image/svg+xml', headers: { 'Access-Control-Allow-Origin': '*' }, body: '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect width="64" height="64" fill="#a04060"/></svg>' }));
    await page.route('https://lrclib.net/**', route => route.fulfill({ headers: { 'Access-Control-Allow-Origin': '*' }, json: [{ id: 1, trackName: '致你', artistName: 'yihuik', duration: 253, syncedLyrics: lrc }] }));
    try {
      await page.goto(base, { waitUntil: 'networkidle' });
      await page.getByRole('button', { name: '连接 Spotify' }).click();
      await page.locator('.connect-button').click();
      await page.waitForURL(/spotify=connected/, { timeout: 8000 });
      assert.ok(authorized, '应使用 PKCE 授权');
      // 登录回来会自动打开歌单；关掉它回到歌词画面。
      await page.locator('.library-backdrop [aria-label*="关闭"]').first().click();
      await page.locator('.library-backdrop').waitFor({ state: 'detached', timeout: 5000 });
      await page.locator('.stage').waitFor({ timeout: 8000 });
      await page.waitForFunction(() => document.querySelector('.lyric-kind')?.textContent?.includes('LRCLIB'), null, { timeout: 10000 });
      const text = await page.locator('.stage').innerText();
      assert.ok(!/戀|捨|蓋|屬/.test(text), `歌词应转成简体：${text.slice(0, 80)}`);
      assert.equal(await page.locator('.song strong').innerText(), '致你');
      // 控制栏几秒无操作会自动隐藏；先轻点画面把它呼出来，再点暂停。
      const box = page.viewportSize(); await page.touchscreen.tap(box.width / 2, box.height / 3); await page.waitForTimeout(700);
      await page.getByRole('button', { name: '暂停' }).click(); await page.waitForTimeout(400);
      assert.ok(commands.some(c => c.endsWith('/pause')), '暂停应发送 Spotify 指令');
      await page.screenshot({ path: path.join(shots, `standalone-${name}.png`) });
      await page.touchscreen.tap(box.width / 2, box.height / 3); await page.waitForTimeout(700);
      await page.getByLabel('显示设置', { exact: true }).click();
      const modes = await page.getByLabel('歌词动画样式', { exact: true }).locator('option').evaluateAll(rows => rows.map(r => r.value));
      for (const mode of modes) {
        await page.getByLabel('歌词动画样式', { exact: true }).selectOption(mode); await page.waitForTimeout(350);
        assert.equal(await page.locator('.fatal').count(), 0, mode);
      }
      await page.getByLabel('关闭设置', { exact: true }).click();
      // 上游在快速切换动画时偶发的过渡报错已由界面自动恢复（RecoveringBoundary），不算失败；其余错误都算。
      assert.deepEqual(errors.filter(text => !/reading 'leaving'/.test(text)), []);
      results.push({ device: name, passed: true, styles: modes.length, commands: commands.length });
    } catch (error) {
      await page.screenshot({ path: path.join(shots, `standalone-${name}-failure.png`) }).catch(() => {});
      results.push({ device: name, passed: false, error: String(error && error.message || error).slice(0, 400), errors });
    } finally { await context.close(); }
  }
  await browser.close(); server.close();
  console.log(JSON.stringify(results));
  if (!results.every(r => r.passed)) process.exitCode = 1;
})();
