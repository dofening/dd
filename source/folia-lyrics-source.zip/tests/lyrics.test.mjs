import test from 'node:test';
import assert from 'node:assert/strict';
import { chooseLyrics, lookupLyrics, toSimplifiedText, simplifyLyrics } from '../lyrics.mjs';
import { getPosition, createPlaybackClock } from '../position.mjs';

test('歌词必须同时匹配歌名、歌手和录音时长', () => {
  const song = { title: 'Test Song', artist: 'Artist', duration: 200 };
  const good = { trackName: 'Test Song', artistName: 'Artist', duration: 201, syncedLyrics: '[00:01.00]test' };
  assert.equal(chooseLyrics([
    { ...good, artistName: 'Other' }, { ...good, trackName: 'Test Song (Live)' },
    { ...good, duration: 230 }, good,
  ], song), good);
  assert.equal(chooseLyrics([{ ...good, duration: 230 }], song), null);
  assert.ok(chooseLyrics([{ ...good, duration: 197 }], song), '平台间相差 3 秒的同一录音应能匹配');
  assert.equal(chooseLyrics([{ ...good, duration: 206 }], song), null);
  assert.equal(chooseLyrics([{ ...good, artistName: 'OtherArtist' }], song), null);
  assert.ok(chooseLyrics([{ trackName: '阴天', artistName: '莫文蔚', duration: 242 }], { title: '陰天', artist: '莫文蔚', duration: 242 }));
});

test('同一录音优先选带时间歌词，文本歌词不能冒充同步歌词', async () => {
  const song = { title: 'Test', artist: 'Singer', duration: 200 };
  const base = { trackName: 'Test', artistName: 'Singer', duration: 200 };
  const result = await lookupLyrics(song, async () => ({ ok: true, json: async () => [{ ...base, plainLyrics: 'text' }] }));
  assert.equal(result.status, 'plain'); assert.equal(result.lines, '');
  const match = chooseLyrics([{ ...base, plainLyrics: 'text' }, { ...base, syncedLyrics: '[00:01.00]text' }], song);
  assert.ok(match.syncedLyrics);
});

test('时钟跟随播放、暂停和跳转，网络中断时不无限自行前进', () => {
  const base = { connected: true, position: 20, duration: 100, receivedAt: 10000, playing: true };
  assert.equal(getPosition(base, 11000), 21);
  assert.equal(getPosition({ ...base, playing: false }, 11000), 20);
  assert.equal(getPosition({ ...base, position: 80, receivedAt: 11000 }, 11500), 80.5);
  assert.equal(getPosition(base, 1000000), 23);
  assert.equal(getPosition({ ...base, position: 99 }, 12000), 100);
  assert.equal(getPosition({ connected: false }, 12000), 0);
});

test('歌词服务失败会明确报错', async () => {
  await assert.rejects(lookupLyrics({ title: 'Test', artist: 'Singer' }, async () => ({ ok: false })), /暂时不可用/);
});

test('整秒快照重复上报不会让播放中的歌词时钟回跳，真实后退仍生效', () => {
  const clock = createPlaybackClock(); let previous = 0;
  for (let now = 10000; now < 15000; now += 20) {
    const snapshotTime = Math.floor((now - 10000) / 400) * 400 + 10000;
    const value = clock.tick({ connected: true, title: 'Test', artist: 'Artist', duration: 60,
      position: 10 + Math.floor((snapshotTime - 10000) / 1000), receivedAt: snapshotTime, playing: true }, now);
    assert.ok(value >= previous, `时钟不应回跳: ${previous} -> ${value}`); previous = value;
  }
  clock.seek(5, 15000);
  assert.ok(clock.tick({ connected: true, title: 'Test', artist: 'Artist', duration: 60, position: 14, receivedAt: 15000, playing: true }, 15020) < 6);
  assert.ok(clock.tick({ connected: true, title: 'Test', artist: 'Artist', duration: 60, position: 5, receivedAt: 15400, playing: true }, 15420) < 6);
  const paused = clock.tick({ connected: true, title: 'Test', artist: 'Artist', duration: 60, position: 5.4, receivedAt: 15500, playing: false }, 15500);
  assert.equal(clock.tick({ connected: true, title: 'Test', artist: 'Artist', duration: 60, position: 5.4, receivedAt: 15600, playing: false }, 15600), paused);
});

test('毫秒级进度来源下，小偏差几秒内追平，大偏差直接对齐', () => {
  for (const error of [0.4, 1.5]) {
    const clock = createPlaybackClock();
    let snapshot = { connected: true, precise: true, title: 'Test', artist: 'Artist', duration: 300, position: 10, receivedAt: 0, playing: true };
    clock.tick(snapshot, 0); let value = 0;
    for (let now = 16; now <= 6000; now += 16) {
      if (now % 1800 < 16) snapshot = { ...snapshot, position: 10 + now / 1000 + error, receivedAt: now };
      value = clock.tick(snapshot, now);
    }
    assert.ok(Math.abs(10 + 6 + error - value) < 0.1, `偏差 ${error} 秒应在 6 秒内追平，实际剩 ${(10 + 6 + error - value).toFixed(2)}`);
  }
});

test('歌手写法不同、Spotify 多歌手连写、歌名带版本说明时仍能找到同一录音', async () => {
  const song = { title: '致你', artist: 'Yihuik苡慧', duration: 256 };
  assert.ok(chooseLyrics([{ trackName: '致你', artistName: 'yihuik', duration: 253, syncedLyrics: '[00:18.39]x' }], song));
  assert.equal(chooseLyrics([{ trackName: '致你·2023', artistName: '王赫野', duration: 253, syncedLyrics: '[00:18.39]x' }], song), null);
  assert.ok(chooseLyrics([{ trackName: 'Song', artistName: 'A', duration: 200, syncedLyrics: 'x' }], { title: 'Song - 2011 Remaster', artist: 'A / B', duration: 200 }));
  const asked = [];
  const result = await lookupLyrics({ title: '致你', artist: 'Yihuik苡慧 / 某某', duration: 256 }, async url => {
    asked.push(new URL(url).searchParams.toString());
    const rows = url.includes('q=') ? [{ id: 1, trackName: '致你', artistName: 'Yihuik苡慧', duration: 253, syncedLyrics: '[00:18.39]戀戀不捨' }] : [];
    return { ok: true, json: async () => rows };
  });
  assert.equal(result.status, 'synced');
  assert.ok(asked.length >= 3, '前面的写法没找到时要换写法继续查');
});

test('繁体歌词自动转简体，日文歌词保持原样', () => {
  assert.equal(toSimplifiedText('[00:18.39]戀戀不捨又念念不忘'), '[00:18.39]恋恋不舍又念念不忘');
  assert.equal(toSimplifiedText('[00:10.26]君と話そうか'), '[00:10.26]君と話そうか');
  assert.deepEqual(simplifyLyrics({ status: 'plain', plain: '覆蓋', lines: '' }), { status: 'plain', plain: '覆盖', lines: '' });
});
