const { chromium } = require('E:/Codex/RuntimeCache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs = require('node:fs/promises');
const path = require('node:path');
const assert = require('node:assert/strict');
const base = 'http://127.0.0.1:18982';
const root = path.resolve(__dirname, '..');
const fixture = Array.from({ length: 20 }, (_, i) => `[${String(Math.floor(i * 8 / 60)).padStart(2, '0')}:${String(i * 8 % 60).padStart(2, '0')}.00]${['微光照亮今天的方向', '让每个音符缓缓流淌', '新的故事正在路上', '在平凡日子里歌唱'][i % 4]}${i}`).join('\n');

(async () => {
 const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
 const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
 const errors=[]; const commands=[]; const styles=[]; const backgrounds=[]; let lyricRequests=0;
 let playing=true, shuffle=false, repeat='off', position=12, volume=55;
 page.on('pageerror', error => errors.push(error.message));
 // Pixi 样式因安全策略缺少免 eval 模块而退回静态文字时，只在控制台报错，这里也算失败。
 page.on('console', message => { if (message.type() === 'error' && /unsafe-eval/.test(message.text())) errors.push(message.text().slice(0, 200)); });
 const image=await fs.readFile(path.join(root,'public/liked.svg'));
 await page.route('**/api/state', route => route.fulfill({ json:{connected:true,status:'ok',title:'本地界面检查',artist:'示例歌手',album:'示例专辑',duration:160,position,playing,receivedAt:Date.now(),allowOnline:true} }));
 await page.route('**/api/lyrics*', async route => {lyricRequests++;if(route.request().url().includes('refresh=1'))await new Promise(resolve=>setTimeout(resolve,300));return route.fulfill({ json:{status:'synced',source:'自写测试歌词',lines:fixture,format:'lrc',wordTimed:false} });});
 await page.route('**/api/spotify/**', async route=>{
   const u=new URL(route.request().url());
   if(u.pathname.endsWith('/player')) return route.fulfill({json:{available:true,title:'本地界面检查',artist:'示例歌手',album:'示例专辑',duration:160,position,playing,shuffle,smartShuffle:null,repeat,volume,device:'本机测试',cover:'https://i.scdn.co/image/example',receivedAt:Date.now()}});
   if(u.pathname.endsWith('/status')) return route.fulfill({json:{connected:true,configured:true}});
   if(u.pathname.endsWith('/playlists')) return route.fulfill({json:{items:[{id:'a'.repeat(22),name:'练习歌单',owner:'本地测试',count:2,uri:'spotify:playlist:'+'a'.repeat(22),cover:'/liked.svg'},{id:'b'.repeat(22),name:'第二歌单',owner:'本地测试',count:1,uri:'spotify:playlist:'+'b'.repeat(22),cover:'/liked.svg'}],complete:true,syncedAt:Date.now()}});
   if(u.pathname.endsWith('/tracks')) return route.fulfill({json:{items:[{id:'c'.repeat(22),title:'测试歌曲甲',artist:'示例歌手',duration:160,uri:'spotify:track:'+'c'.repeat(22)},{id:'d'.repeat(22),title:'测试歌曲乙',artist:'示例歌手',duration:180,uri:'spotify:track:'+'d'.repeat(22)}],nextOffset:null}});
   if(u.pathname.endsWith('/art')) return route.fulfill({contentType:'image/svg+xml',body:image});
   if(u.pathname.endsWith('/control')) {
     const data=route.request().postDataJSON();commands.push(data);
     if(data.action==='seek') position+=data.delta;
     if(data.action==='seek-to') position=data.position;
     if(data.action==='volume') volume+=data.delta;
     if(data.action==='toggle') playing=!playing;
     if(data.action==='shuffle') shuffle=!shuffle;
     if(data.action==='repeat') repeat=repeat==='off'?'context':repeat==='context'?'track':'off';
     return route.fulfill({json:{accepted:true,position,volume}});
   }
   return route.fulfill({json:{}});
 });
 try {
   await page.goto(base,{waitUntil:'networkidle'});
   await page.getByLabel('Folia 歌词动画',{exact:true}).waitFor();
   await page.getByLabel('显示设置',{exact:true}).click();
   const modes=await page.getByLabel('歌词动画样式',{exact:true}).locator('option').evaluateAll(rows=>rows.map(r=>r.value));
   for(const mode of modes){
     await page.getByLabel('歌词动画样式',{exact:true}).selectOption(mode);
     await page.getByLabel('关闭设置',{exact:true}).click();
     await page.waitForTimeout(700);
     assert.equal(await page.locator('.fatal').count(),0,mode);
     await page.screenshot({path:path.join(root,'checks',`repaired-${mode}.png`)});
     styles.push(mode);
     await page.mouse.move(20,20); await page.getByLabel('显示设置',{exact:true}).click();
   }
   await page.getByLabel('歌词动画样式',{exact:true}).selectOption('classic');
   const choices=await page.getByLabel('背景样式',{exact:true}).locator('option').evaluateAll(rows=>rows.map(r=>r.value));
   for(const mode of choices){
     await page.getByLabel('背景样式',{exact:true}).selectOption(mode);
     await page.getByLabel('关闭设置',{exact:true}).click();
     await page.waitForTimeout(850);
     assert.equal(await page.locator('.stage').getAttribute('data-background'),mode);
     assert.equal(await page.locator('.fatal').count(),0,mode);
     await page.screenshot({path:path.join(root,'checks',`background-${mode}.png`)});
     backgrounds.push(mode);
     await page.mouse.move(20,20); await page.getByLabel('显示设置',{exact:true}).click();
   }
   await page.getByLabel('背景样式',{exact:true}).selectOption('common');
   await page.getByRole('button',{name:'背景与图片设置',exact:true}).click();
   await page.locator('.original-visual-studio').waitFor();
   await page.waitForTimeout(1300);
   assert.equal(await page.locator('.fatal').count(),0);
   await page.screenshot({path:path.join(root,'checks','original-background-studio.png')});
   // 此处关闭宿主的工作台，不操作任何 Spotify 账号页面。
   await page.keyboard.press('Escape');
   await page.waitForTimeout(350);
   await page.keyboard.press('ArrowRight'); await page.waitForTimeout(100);
   await page.keyboard.press('ArrowUp'); await page.waitForTimeout(100);
   assert.ok(commands.some(c=>c.action==='seek'&&c.delta===5));
   assert.ok(commands.some(c=>c.action==='volume'&&c.delta===5));
   await page.getByLabel('随机播放',{exact:true}).click(); await page.waitForTimeout(300);
   await page.getByLabel('循环模式',{exact:true}).click(); await page.waitForTimeout(300);
   assert.ok(commands.some(c=>c.action==='shuffle')); assert.ok(commands.some(c=>c.action==='repeat'));
   await page.getByLabel('歌词列表与跳转',{exact:true}).click();
   await page.locator('.lyric-timeline p:visible').filter({hasText:/^新的故事正在路上2$/}).first().click();
   await page.waitForTimeout(200);
   assert.ok(commands.some(c=>c.action==='seek-to'&&Math.abs(c.position-16)<0.01));
   await page.keyboard.press('Escape');
   await page.getByLabel('打开 Spotify 歌单',{exact:true}).click();
   await page.getByLabel('Folia 原版立体歌单',{exact:true}).waitFor();
   await page.waitForTimeout(1000);
   await page.screenshot({path:path.join(root,'checks','original-playlist-carousel.png')});
   await page.getByRole('button',{name:'平铺歌单',exact:true}).click();
   await page.locator('.playlist-card img').first().waitFor();
   assert.ok(await page.locator('.playlist-card img').evaluateAll(imgs=>imgs.every(img=>img.complete&&img.naturalWidth>0)));
   await page.locator('.playlist-card').filter({hasText:'练习歌单'}).click();
   await page.getByLabel('Folia 原版立体选歌',{exact:true}).waitFor();
   await page.waitForTimeout(800);
   await page.screenshot({path:path.join(root,'checks','original-song-carousel.png')});
   await page.getByLabel('Spotify 歌单',{exact:true}).focus();
   await page.keyboard.press('ArrowRight');
   await page.keyboard.press('Space');
   await page.waitForTimeout(200);
   assert.ok(commands.some(c=>c.action==='play-track'&&c.playlistId==='a'.repeat(22)&&c.id==='d'.repeat(22)));
   assert.equal(await page.locator('.library-backdrop').count(),0);
   const toggles=commands.filter(c=>c.action==='toggle').length;
   await page.keyboard.press('Space'); await page.waitForTimeout(120);
   assert.equal(commands.filter(c=>c.action==='toggle').length,toggles+1);
   const beforeRefresh=lyricRequests;
   await page.evaluate(()=>window.dispatchEvent(new Event('focus')));
   await page.waitForTimeout(80);
   assert.equal(await page.locator('.lyrics-unavailable').count(),0,'后台重新匹配期间应保留当前歌词');
   await page.waitForTimeout(400);assert.ok(lyricRequests>beforeRefresh,'返回前台应主动重新匹配');
   assert.deepEqual(errors,[]);
   await fs.writeFile(path.join(root,'checks','integration-ui.json'),JSON.stringify({passed:true,styles,backgrounds,originalStudio:true,originalPlaylistCarousel:true,originalSongCarousel:true,imagesLoaded:true,keyboardControls:true,keyboardSelectsAndPlaysTrack:true,spaceTogglesPlayback:true,shuffleAndRepeat:true,lyricClickSeeks:true,clickTrackPlays:true,automaticRematchKeepsLyrics:true,pageErrors:errors},null,2));
   console.log(JSON.stringify({passed:true,styles:styles.length,backgrounds:backgrounds.length,controls:commands.length}));
 }catch(error){await page.screenshot({path:path.join(root,'checks','integration-failure.png')});console.error(error);console.error((await page.locator('body').innerText()).slice(0,1300));throw error}
 finally{await browser.close()}
})().catch(()=>{process.exitCode=1});
