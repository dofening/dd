import test from 'node:test';
import assert from 'node:assert/strict';
import { SpotifyConnection, SPOTIFY_SCOPES, summarizeTrack } from '../spotify.mjs';
test('授权使用 PKCE 并校验回调 state，不申请修改歌单或收藏的权限', async () => {
  const connection = new SpotifyConnection('http://127.0.0.1:18981/spotify/callback', async () => { throw new Error('unexpected request'); });
  assert.throws(() => connection.start('not-an-id'));
  const url = new URL(connection.start('a'.repeat(32)));
  assert.equal(url.origin, 'https://accounts.spotify.com');
  assert.equal(url.searchParams.get('scope'), SPOTIFY_SCOPES);
  assert.equal(url.searchParams.get('code_challenge_method'), 'S256');
  assert.equal(url.searchParams.has('client_secret'), false);
  assert.equal(SPOTIFY_SCOPES.includes('playlist-modify'), false);
  assert.ok(SPOTIFY_SCOPES.includes('user-modify-playback-state'));
  await assert.rejects(connection.finish('code', 'wrong-state'));
  assert.equal(connection.state().connected, false);
});

test('方向键、循环和点歌发送真实 Spotify 指令并保留歌单上下文', async () => {
  const writes = [];
  const connection = new SpotifyConnection('http://127.0.0.1/callback', async (url, options) => {
    if (options.method) { writes.push({ url: new URL(url), method: options.method, body: options.body ? JSON.parse(options.body) : null }); return { ok: true, status: 204 }; }
    return { ok: true, status: 200, json: async () => ({ is_playing: true, shuffle_state: false, repeat_state: 'context', progress_ms: 19000,
      item: { duration_ms: 20000 }, device: { id: 'device', volume_percent: 98, supports_volume: true } }) };
  });
  connection.session = { access: 'test-only', expiresAt: Date.now() + 3600000 };
  assert.equal((await connection.control({ action: 'seek', delta: 5 })).position, 20);
  assert.equal(writes.at(-1).url.searchParams.get('position_ms'), '20000');
  assert.equal((await connection.control({ action: 'volume', delta: 5 })).volume, 100);
  await connection.control({ action: 'toggle' }); assert.ok(writes.at(-1).url.pathname.endsWith('/pause'));
  await connection.control({ action: 'next' }); assert.equal(writes.at(-1).method, 'POST');
  await connection.control({ action: 'repeat' }); assert.equal(writes.at(-1).url.searchParams.get('state'), 'track');
  await connection.control({ action: 'shuffle' }); assert.equal(writes.at(-1).url.searchParams.get('state'), 'true');
  await connection.control({ action: 'seek-to', position: 7.25 }); assert.equal(writes.at(-1).url.searchParams.get('position_ms'), '7250');
  await connection.control({ action: 'play-track', id: 'a'.repeat(22), playlistId: 'b'.repeat(22) });
  assert.deepEqual(writes.at(-1).body, { context_uri: 'spotify:playlist:' + 'b'.repeat(22), offset: { uri: 'spotify:track:' + 'a'.repeat(22) } });
  await assert.rejects(connection.control({ action: 'seek-to', position: NaN }), /无效/);
});
test('歌单分页完整读取，识别新的 item 字段与旧的 track 字段', async () => {
  const calls = [];
  const connection = new SpotifyConnection('http://127.0.0.1/callback', async url => {
    calls.push(url);
    const page = new URL(url).searchParams.get('offset') === '0' ? { items: [{ id: 'a'.repeat(22), name: 'First', items: { total: 5 } }], next: 'next' } : { items: [{ id: 'b'.repeat(22), name: 'Second', tracks: { total: 8 } }], next: null };
    return { ok: true, status: 200, json: async () => page };
  });
  connection.session = { access: 'test-only', expiresAt: Date.now() + 3600000 };
  const result = await connection.playlists();
  assert.equal(result.items.length, 2); assert.equal(result.complete, true);
  assert.equal(result.items[0].count, 5); assert.equal(result.items[1].count, 8); assert.equal(calls.length, 2);
  const track = { id: 'a'.repeat(22), type: 'track', name: 'Example', artists: [{ name: 'Artist' }], duration_ms: 123000 };
  assert.deepEqual(summarizeTrack({ item: track }), summarizeTrack({ track }));
  assert.equal(summarizeTrack({ item: null }), null);
});
test('Spotify 限流期间不再请求，403 不冒充空歌单', async () => {
  let calls = 0;
  const connection = new SpotifyConnection('http://127.0.0.1/callback', async () => { calls++; return { status: 429, headers: { get: () => '120' } }; });
  connection.session = { access: 'test-only', expiresAt: Date.now() + 3600000 };
  await assert.rejects(connection.playlists(), /稍后/); await assert.rejects(connection.playlists(), /稍后/);
  assert.equal(calls, 1);
  const restricted = new SpotifyConnection('http://127.0.0.1/callback', async () => ({ status: 403 }));
  restricted.session = { access: 'test-only', expiresAt: Date.now() + 3600000 };
  await assert.rejects(restricted.tracks('a'.repeat(22)), /自建或协作/);
});

test('连续按键合并待执行调整，不为每个按键重新查询播放信息', async () => {
  let reads=0; const positions=[];
  const connection=new SpotifyConnection('http://127.0.0.1/callback',async(url,options)=>{
    if(options.method){positions.push(Number(new URL(url).searchParams.get('position_ms')));await new Promise(resolve=>setTimeout(resolve,20));return{ok:true,status:204};}
    reads++;return{ok:true,status:200,json:async()=>({is_playing:false,progress_ms:10000,item:{duration_ms:300000},device:{id:'pc',volume_percent:50,supports_volume:true}})};
  });
  connection.session={access:'test-only',expiresAt:Date.now()+3600000};
  const first=connection.control({action:'seek',delta:5});
  await new Promise(resolve=>setTimeout(resolve,2));
  await Promise.all([first,...Array.from({length:9},()=>connection.control({action:'seek',delta:5}))]);
  assert.equal(reads,1);assert.ok(positions.length<=2);assert.equal(positions.at(-1),60000);
});
