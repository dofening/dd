const { chromium } = require('E:/Codex/RuntimeCache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs = require('node:fs/promises');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const base = 'http://127.0.0.1:18981';
const fixture = '[00:00.00]窗外的微光\n[00:05.00]照亮此刻的方向\n[00:10.00]让音乐缓缓流淌\n[00:15.00]在平凡日子里歌唱\n[00:20.00]新的故事正在路上\n[00:25.00]让每个音符闪亮';

(async () => {
  await fs.mkdir(path.join(root, 'checks'), { recursive: true });
  const browser = await chromium.launch({ executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', headless: true });
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  const errors = []; const external = [];
  page.on('pageerror', error => errors.push(error.message));
  let position = 7; let playing = true; let title = '动画验收'; let connected = true;
  await page.route('**/api/state', route => route.fulfill({ json: { connected, status: 'ok', title, artist: '本地测试', album: '动画检查', duration: 30, position, receivedAt: Date.now(), playing, allowOnline: true } }));
  await page.route('**/api/lyrics*', route => route.fulfill({ json: { status: 'synced', source: '测试歌词', lines: fixture, format: 'lrc', wordTimed: false } }));
  page.on('request', request => { if (new URL(request.url()).origin !== base && !request.url().startsWith('data:') && !request.url().startsWith('blob:')) external.push(request.url()); });
  try {
    await page.goto(base, { waitUntil: 'networkidle' });
    await page.getByLabel('Folia 歌词动画').waitFor();
    await page.waitForTimeout(1600);
    await page.screenshot({ path: path.join(root, 'checks', 'classic.png') });
    assert.equal(await page.locator('.fatal').count(), 0);
    const screenshots = [];
    await page.getByLabel('显示设置', { exact: true }).click();
    const styles = await page.getByLabel('歌词动画样式').locator('option').evaluateAll(options => options.map(option => ({ id: option.value, text: option.textContent })));
    for (const style of styles) {
      await page.getByLabel('歌词动画样式').selectOption(style.id);
      await page.getByLabel('关闭设置').click();
      await page.mouse.move(640, 400);
      await page.waitForTimeout(1100);
      assert.equal(await page.locator('.fatal').count(), 0, style.id + ' crashed');
      await page.screenshot({ path: path.join(root, 'checks', style.id + '.png') });
      screenshots.push(style.id);
      await page.mouse.move(100, 100);
      await page.getByLabel('显示设置', { exact: true }).click();
    }
    await page.getByLabel('歌词动画样式').selectOption('classic');
    await page.getByLabel('关闭设置').click();
    playing = false; position = 22;
    await page.waitForTimeout(800);
    await page.getByText('已暂停', { exact: true }).waitFor();
    assert.equal(await page.locator('.track-progress').innerText().then(text => text.includes('0:22')), true);
    playing = true; position = 3; title = '切歌验收';
    await page.waitForTimeout(800);
    await page.locator('.song strong').filter({ hasText: '切歌验收' }).waitFor();
    connected = false;
    await page.waitForTimeout(800);
    assert.equal(await page.getByLabel('Folia 歌词动画').count(), 0);
    connected = true;
    await page.setViewportSize({ width: 640, height: 480 });
    await page.waitForTimeout(800);
    await page.getByLabel('显示设置', { exact: true }).click();
    await page.screenshot({ path: path.join(root, 'checks', 'settings-small.png') });
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    assert.deepEqual(errors, []);
    await fs.writeFile(path.join(root, 'checks', 'browser-check.json'), JSON.stringify({ passed: true, modes: screenshots, pauseAndSeek: true, songChange: true, disconnectClearsLyrics: true, smallWindow: true, pageErrors: errors, externalRequests: external }, null, 2));
    console.log(JSON.stringify({ passed: true, modes: screenshots.length, externalRequests: external.length }));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
