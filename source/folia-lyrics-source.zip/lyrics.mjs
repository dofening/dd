import * as OpenCC from 'opencc-js';
// 复用 Folia 已有的繁简转换依赖。先按香港字形、再按台湾字形转成简体，覆盖“裏/裡”等两地写法。
const fromHongKong = OpenCC.Converter({ from: 'hk', to: 'cn' });
const fromTaiwan = OpenCC.Converter({ from: 'tw', to: 'cn' });
const simplify = value => fromTaiwan(fromHongKong(value));
// 歌曲和歌手的字形差异不应导致错过同一录音。
export const normalize = value => simplify(String(value ?? '')).normalize('NFKC').toLocaleLowerCase().replace(/[\p{P}\p{Z}\p{S}]/gu, '');

// 日文歌词里的汉字不能按中文规则简化（如“話”“髪”），含假名的文本保持原样。
const KANA = /[぀-ヿㇰ-ㇿｦ-ﾟ]/;
export function toSimplifiedText(text) {
  if (typeof text !== 'string' || !text || KANA.test(text)) return text;
  return simplify(text);
}
// 只转换显示给用户的歌词文字；时间标签和 TTML/YRC 等标记都是 ASCII，不受影响。缓存文件保留原文。
export function simplifyLyrics(result) {
  if (!result || typeof result !== 'object') return result;
  const output = { ...result };
  for (const field of ['lines', 'plain']) if (typeof output[field] === 'string') output[field] = toSimplifiedText(output[field]);
  return output;
}

// 同一录音在不同平台的标称时长常差 2～4 秒（片尾静音、取整）；超过 4 秒多半是另一个版本。
const DURATION_TOLERANCE = 4;
// Spotify 用“ / ”连接多位歌手；歌词库里也常见 feat.、&、x 等写法。
const ARTIST_SEPARATOR = /\s*(?:[,，;；/&、×]|\bfeat\.?(?=\s)|\bft\.?(?=\s)|\bwith\b|\s+x\s+)\s*/i;
const rawArtists = value => String(value ?? '').split(ARTIST_SEPARATOR).map(item => item.trim()).filter(Boolean);
const splitArtists = value => rawArtists(value).map(normalize).filter(Boolean);
// 括号里的版本说明、“ - Remastered”之类后缀只用于放宽比对，原歌名仍然优先。
const DECORATION = /\s*[（(\[【〔「][^）)\]】〕」]*[）)\]】〕」]\s*|\s+[-–—]\s+.*$/g;
const plainTitle = value => String(value ?? '').replace(DECORATION, ' ').trim() || String(value ?? '');
const coreTitle = value => normalize(plainTitle(value));

// 2 = 完全一致，1 = 去掉版本说明后一致，0 = 不是同一首。
function titleScore(candidate, song) {
  const exact = normalize(song.title); const name = normalize(candidate);
  if (!exact || !name) return 0;
  if (name === exact) return 2;
  const core = coreTitle(song.title); const candidateCore = coreTitle(candidate);
  return core && (candidateCore === core || name === core || candidateCore === exact) ? 1 : 0;
}
// 2 = 某位歌手完全一致，1 = 一方包含另一方（如“Yihuik苡慧”与“yihuik”），0 = 不同歌手。
function artistScore(candidate, song) {
  const wanted = splitArtists(song.artist); const found = splitArtists(candidate);
  if (!wanted.length || !found.length) return 0;
  if (wanted.some(name => found.includes(name))) return 2;
  // 只接受“拉丁名 + 中日韩名”这种双语写法互相包含；“Artist”与“OtherArtist”不算同一人。
  const latin = text => /^[a-z0-9]+$/.test(text);
  const bilingual = (whole, part) => {
    if (part.length < 2 || !whole.includes(part) || whole === part) return false;
    const rest = whole.replace(part, '');
    return latin(part) ? !/[a-z]/.test(rest) : latin(rest);
  };
  return wanted.some(a => found.some(b => bilingual(a, b) || bilingual(b, a))) ? 1 : 0;
}

export function chooseLyrics(rows, song) {
  if (!Array.isArray(rows)) return null;
  let best = null; let bestScore = -Infinity;
  for (const row of rows) {
    if (!row) continue;
    const title = titleScore(row.trackName, song); const artist = artistScore(row.artistName, song);
    const gap = song.duration && Number(row.duration) ? Math.abs(Number(row.duration) - song.duration) : 0;
    if (!title || !artist || gap > DURATION_TOLERANCE) continue;
    const score = Number(!!row.syncedLyrics) * 100 + title * 10 + artist * 5 - gap;
    if (score > bestScore) { best = row; bestScore = score; }
  }
  return best;
}

// 第一种查询结果里没有合适版本时，换几种写法再查：只用第一位歌手、去掉版本说明、只按歌名全文检索。
export function lyricQueries(song) {
  const first = rawArtists(song.artist)[0] || String(song.artist ?? '');
  const title = String(song.title ?? ''); const core = plainTitle(title);
  const queries = [
    { track_name: title, artist_name: String(song.artist ?? '') },
    { track_name: title, artist_name: first },
    { q: `${core} ${first}`.trim() },
    { q: core },
  ].filter(query => Object.values(query).every(Boolean));
  const seen = new Set();
  return queries.filter(query => { const key = JSON.stringify(query); if (seen.has(key)) return false; seen.add(key); return true; });
}

let nextAllowedRequest = 0;
async function search(query, fetcher) {
  if (fetcher === fetch && Date.now() < nextAllowedRequest) {
    const error = new Error('歌词服务暂时不可用'); error.retryAfterMs = nextAllowedRequest - Date.now(); throw error;
  }
  const response = await fetcher(`https://lrclib.net/api/search?${new URLSearchParams(query)}`, {
    signal: AbortSignal.timeout(12000),
    headers: { 'User-Agent': 'FoliaSpotifyLyrics/1.2 (https://github.com/chthollyphile/folia-major; personal desktop companion)' },
  });
  if (!response.ok) {
    const error = new Error('歌词服务暂时不可用');
    error.retryAfterMs = Math.max(15000, (Number(response.headers?.get('Retry-After')) || 30) * 1000);
    if (fetcher === fetch) nextAllowedRequest = Date.now() + error.retryAfterMs;
    throw error;
  }
  const rows = await response.json();
  return Array.isArray(rows) ? rows : [];
}

export async function lookupLyrics(song, fetcher = fetch) {
  const rows = new Map(); let match = null;
  for (const query of lyricQueries(song)) {
    for (const row of await search(query, fetcher)) rows.set(row.id ?? `${rows.size}`, row);
    match = chooseLyrics([...rows.values()], song);
    if (match?.syncedLyrics) break; // 找到带时间的歌词就不再多发请求
  }
  if (!match) return { status: 'missing', message: '歌词库里没有找到这首歌的同一版本，可以导入 LRC / TTML', lines: '' };
  if (match.instrumental) return { status: 'instrumental', message: '纯音乐', lines: '' };
  if (!match.syncedLyrics) return { status: 'plain', message: '只有文本歌词，可以导入带时间的歌词', plain: match.plainLyrics ?? '', lines: '' };
  return { status: 'synced', source: 'LRCLIB', lines: match.syncedLyrics, format: 'lrc', wordTimed: false };
}
