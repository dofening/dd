param([switch]$Once)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType=WindowsRuntime]
$mediaType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType=WindowsRuntime]
$asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
} | Select-Object -First 1

function Wait-WinRT($Operation, $ResultType) {
    $task = $asTask.MakeGenericMethod($ResultType).Invoke($null, @($Operation))
    if (-not $task.Wait(5000)) { throw '读取系统媒体信息超时' }
    return $task.GetAwaiter().GetResult()
}

$manager = $null
$cachedIdentity = ''
$cachedMedia = $null
do {
    try {
        if ($null -eq $manager) {
            $manager = Wait-WinRT ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
        }
        # 只选择 Spotify，浏览器和其他音乐软件不会抢走歌词窗口。
        $session = @($manager.GetSessions()) | Where-Object { $_.SourceAppUserModelId -match '(?i)spotify' } | Select-Object -First 1
        if ($null -eq $session) {
            $cachedIdentity = ''
            $cachedMedia = $null
            $state = @{ connected=$false; status='waiting'; message='在 Spotify 播放一首歌，歌词会自动跟随'; receivedAt=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }
        } else {
            $media = Wait-WinRT ($session.TryGetMediaPropertiesAsync()) $mediaType
            $timeline = $session.GetTimelineProperties()
            $playback = $session.GetPlaybackInfo()
            $identity = "$($media.Title)|$($media.Artist)|$($media.AlbumTitle)"
            if ($identity -ne $cachedIdentity) {
                $cachedIdentity = $identity
                $cachedMedia = @{ title=$media.Title; artist=$media.Artist; album=$media.AlbumTitle }
            }
            $playing = [string]$playback.PlaybackStatus -eq 'Playing'
            $position = $timeline.Position.TotalSeconds
            # Windows 的 Position 是 LastUpdatedTime 时的位置；播放中补上经过的时间。
            if ($playing) {
                $elapsed = ([DateTimeOffset]::UtcNow - $timeline.LastUpdatedTime).TotalSeconds
                if ($elapsed -ge 0 -and $elapsed -lt 86400) { $position += $elapsed }
            }
            $duration = [Math]::Max(0, $timeline.EndTime.TotalSeconds)
            if ($duration -gt 0) { $position = [Math]::Min($duration, $position) }
            $state = @{
                connected=$true; status='ok'; title=$cachedMedia.title; artist=$cachedMedia.artist; album=$cachedMedia.album
                playing=$playing; position=[Math]::Max(0, $position); duration=$duration
                receivedAt=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
            }
        }
    } catch {
        $manager = $null
        $state = @{ connected=$false; status='error'; message='暂时无法读取 Spotify 播放信息，请重新打开歌词窗口'; receivedAt=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() }
    }
    [Console]::WriteLine(($state | ConvertTo-Json -Compress))
    if (-not $Once) { Start-Sleep -Milliseconds 500 }
} while (-not $Once)
