import React, { useEffect, useRef, useState } from 'react';

const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
const label = (value: number) => `${Math.floor(value / 60)}:${String(Math.floor(value % 60)).padStart(2, '0')}`;
type Options = {
  enabled: boolean; songKey: string; duration: number; position: () => number;
  volume: () => number | null; canVolume: () => boolean;
  seek: (position: number) => void; setVolume: (volume: number) => void;
  toggle: () => void; wake: () => void; tap: () => void;
};
type Gesture = { id: number; x: number; y: number; width: number; height: number; position: number; volume: number;
  brightness: number; songKey: string; mode: '' | 'seek' | 'brightness' | 'volume'; value: number; blocked: boolean };

// 只有歌词画面接管单指手势；控件、弹窗、多指操作保留系统行为。
export function useTouchPlayback(options: Options) {
  const [brightness, setBrightness] = useState(() => {
    try { return clamp(Number(localStorage.getItem('folia_screen_brightness') ?? 100) || 100, 25, 100); } catch { return 100; }
  });
  const [hud, setHud] = useState('');
  const gesture = useRef<Gesture | null>(null);
  const suppressedUntil = useRef(0);
  const lastTap = useRef({ at: 0, x: 0, y: 0 });
  const hudTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  useEffect(() => {
    const cancel = () => { gesture.current = null; setHud(''); };
    window.addEventListener('resize', cancel);
    return () => { clearTimeout(hudTimer.current); window.removeEventListener('resize', cancel); };
  }, []);
  function showHud(text: string) {
    clearTimeout(hudTimer.current); setHud(text);
    hudTimer.current = setTimeout(() => setHud(''), 1300);
  }
  function changeBrightness(value: number) {
    value = Math.round(clamp(value, 25, 100)); setBrightness(value);
    try { localStorage.setItem('folia_screen_brightness', String(value)); } catch { /* 只影响记忆 */ }
  }
  const interactive = (target: EventTarget | null) => target instanceof Element && !!target.closest('button,a,input,select,textarea,[role="dialog"],.chrome,.library-backdrop,.original-visual-studio,.lyric-timeline,.panel-backdrop');
  const handlers = {
    onPointerDownCapture(event: React.PointerEvent<HTMLElement>) {
      if (!event.isPrimary) { gesture.current = null; suppressedUntil.current = Date.now() + 600; return; }
      if (!options.enabled || event.pointerType === 'mouse' || interactive(event.target)) return;
      const box = event.currentTarget.getBoundingClientRect();
      gesture.current = { id: event.pointerId, x: event.clientX, y: event.clientY, width: box.width, height: box.height,
        position: options.position(), volume: options.volume() ?? 0, brightness, songKey: options.songKey, mode: '', value: 0, blocked: false };
    },
    onPointerMoveCapture(event: React.PointerEvent<HTMLElement>) {
      const start = gesture.current;
      if (!start || start.id !== event.pointerId) return;
      const dx = event.clientX - start.x, dy = event.clientY - start.y;
      if (!start.mode && Math.max(Math.abs(dx), Math.abs(dy)) < 14) return;
      if (!start.mode) {
        start.mode = Math.abs(dx) > Math.abs(dy) * 1.2 ? 'seek' : start.x < start.width / 2 ? 'brightness' : 'volume';
        try { event.currentTarget.setPointerCapture(event.pointerId); } catch { /* 已离开的指针无需捕获 */ }
      }
      event.preventDefault(); event.stopPropagation(); suppressedUntil.current = Date.now() + 700; options.wake();
      if (start.mode === 'seek') {
        start.value = clamp(start.position + dx / start.width * Math.min(180, options.duration), 0, options.duration);
        showHud(`进度 ${label(start.value)} / ${label(options.duration)} · 松手跳转`);
      } else if (start.mode === 'brightness') {
        start.value = clamp(start.brightness - dy / start.height * 100, 25, 100);
        changeBrightness(start.value); showHud(`画面亮度 ${Math.round(start.value)}%`);
      } else {
        start.blocked = !options.canVolume();
        start.value = Math.round(clamp(start.volume - dy / start.height * 100, 0, 100));
        showHud(start.blocked ? '此播放设备不支持远程音量，请用设备音量键' : `Spotify 音量 ${start.value}% · 松手确认`);
      }
    },
    onPointerUpCapture(event: React.PointerEvent<HTMLElement>) {
      const start = gesture.current; gesture.current = null;
      if (!start || start.id !== event.pointerId || !options.enabled) return;
      if (start.mode) {
        event.preventDefault(); event.stopPropagation(); suppressedUntil.current = Date.now() + 700;
        if (start.songKey !== options.songKey) { showHud('歌曲已切换，请重新调整'); return; }
        if (start.mode === 'seek' && options.duration > 0) options.seek(start.value);
        if (start.mode === 'volume' && !start.blocked) options.setVolume(start.value);
      }
    },
    onPointerCancelCapture() { gesture.current = null; suppressedUntil.current = Date.now() + 700; setHud(''); },
    onClickCapture(event: React.MouseEvent<HTMLElement>) {
      if (!options.enabled || interactive(event.target)) return;
      event.preventDefault(); event.stopPropagation();
      if (Date.now() < suppressedUntil.current) return;
      // 画面单击只切换控制栏，歌词跳转可在歌词列表中操作，避免隐藏按键时误跳进度。
      const previous = lastTap.current;
      if (Date.now() - previous.at < 300 && Math.hypot(event.clientX - previous.x, event.clientY - previous.y) < 45) {
        lastTap.current.at = 0; options.wake(); options.toggle();
      } else {
        lastTap.current = { at: Date.now(), x: event.clientX, y: event.clientY }; options.tap();
      }
    },
  };
  return { handlers, brightness, changeBrightness, hud };
}
