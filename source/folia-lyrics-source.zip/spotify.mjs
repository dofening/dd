import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const SPOTIFY_SCOPES = 'playlist-read-private playlist-read-collaborative user-library-read user-read-playback-state user-modify-playback-state';
const apiRoot = 'https://api.spotify.com/v1';
const authRoot = 'https://accounts.spotify.com';
export const validSpotifyId = value => /^[A-Za-z0-9]{22}$/.test(value);

export function summarizePlaylist(row) {
  return { id: row.id, name: row.name ?? '未命名歌单', description: String(row.description ?? '').replace(/<[^>]*>/g, ''),
    cover: row.images?.[0]?.url ?? '', count: row.items?.total ?? row.tracks?.total ?? 0,
    owner: row.owner?.display_name ?? '', uri: `spotify:playlist:${row.id}` };
}
export function summarizeTrack(row) {
  const track = row.item ?? row.track;
  if (!track || track.type !== 'track' || !validSpotifyId(track.id)) return null;
  return { id: track.id, title: track.name ?? '', artist: track.artists?.map(artist => artist.name).join(' / ') ?? '',
    album: track.album?.name ?? '', cover: track.album?.images?.[0]?.url ?? '', duration: (track.duration_ms ?? 0) / 1000, uri: `spotify:track:${track.id}` };
}

export class SpotifyConnection {
  // deviceTypes：没有正在播放的设备时，点歌优先交给哪类 Spotify 设备。桌面版只找电脑；
  // 手机 / 平板独立版传 null，表示任何设备都可以（正在活动的优先，只有一台时直接用它）。
  constructor(redirectUri, fetcher = fetch, { deviceTypes = ['computer'] } = {}) {
    this.redirectUri = redirectUri; this.fetcher = fetcher; this.clientId = ''; this.deviceTypes = deviceTypes;
    this.session = null; this.pending = null; this.refreshing = null; this.blockedUntil = 0;
    this.controlQueue = Promise.resolve();
    this.generation = 0;
    this.lastPlayer = null;
    this.relativePending = {};
  }
  state() { return { connected: !!this.session, configured: /^[a-f0-9]{32}$/i.test(this.clientId), redirectUri: this.redirectUri }; }
  start(clientId) {
    if (!/^[a-f0-9]{32}$/i.test(clientId)) throw new Error('请填写 Spotify 应用设置中的 Client ID，无需 Client Secret');
    this.clientId = clientId;
    const verifier = randomBytes(48).toString('base64url');
    const state = randomBytes(32).toString('base64url');
    this.pending = { verifier, state, createdAt: Date.now() };
    const query = new URLSearchParams({ client_id: clientId, response_type: 'code', redirect_uri: this.redirectUri,
      scope: SPOTIFY_SCOPES, state, code_challenge_method: 'S256', code_challenge: createHash('sha256').update(verifier).digest('base64url') });
    return `${authRoot}/authorize?${query}`;
  }
  async finish(code, state) {
    const pending = this.pending;
    if (!pending || Date.now() - pending.createdAt > 10 * 60 * 1000 || typeof state !== 'string' ||
      Buffer.byteLength(state) !== Buffer.byteLength(pending.state) || !timingSafeEqual(Buffer.from(state), Buffer.from(pending.state))) {
      throw new Error('Spotify 授权已过期或不属于本窗口，请重新连接');
    }
    this.pending = null;
    if (!code) throw new Error('没有完成 Spotify 授权');
    this.generation++;
    await this.exchange({ grant_type: 'authorization_code', code, redirect_uri: this.redirectUri, code_verifier: pending.verifier });
  }
  async exchange(fields) {
    const generation = this.generation;
    const response = await this.fetcher(`${authRoot}/api/token`, { method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ client_id: this.clientId, ...fields }), signal: AbortSignal.timeout(12000) });
    if (!response.ok) throw new Error('Spotify 授权未能完成，请检查应用的回调地址并重新连接');
    const data = await response.json();
    if (generation !== this.generation) throw new Error('Spotify 连接已变更');
    if (!data.access_token) throw new Error('Spotify 没有返回有效授权');
    // 凭据只在进程内存里，不输出到日志、文件或前端。
    this.session = { access: data.access_token, refresh: data.refresh_token ?? this.session?.refresh,
      scopes: data.scope ?? this.session?.scopes ?? '',
      expiresAt: Date.now() + Math.max(30, Number(data.expires_in) || 3600) * 1000 };
  }
  async refresh() {
    if (!this.session?.refresh) throw new Error('请先连接 Spotify');
    if (!this.refreshing) this.refreshing = this.exchange({ grant_type: 'refresh_token', refresh_token: this.session.refresh })
      .catch(error => { this.session = null; throw error; }).finally(() => { this.refreshing = null; });
    return this.refreshing;
  }
  async get(endpoint, retry = true) {
    if (!this.session) throw new Error('请先连接 Spotify');
    if (Date.now() < this.blockedUntil) throw new Error('Spotify 请求较多，请稍后再同步');
    if (this.session.expiresAt - Date.now() < 60000) await this.refresh();
    if (!/^\/(me\/(playlists|tracks|player(?:\/devices)?)|playlists\/[A-Za-z0-9]{22}\/items)(\?|$)/.test(endpoint)) throw new Error('无效的 Spotify 请求');
    const generation = this.generation;
    const response = await this.fetcher(apiRoot + endpoint, { headers: { Authorization: `Bearer ${this.session.access}` }, signal: AbortSignal.timeout(12000) });
    if (generation !== this.generation) throw new Error('Spotify 连接已变更');
    if (response.status === 401 && retry) { await this.refresh(); return this.get(endpoint, false); }
    if (response.status === 429) {
      this.blockedUntil = Date.now() + Math.max(30, Number(response.headers.get('Retry-After')) || 60) * 1000;
      throw new Error('Spotify 请求较多，请稍后再同步');
    }
    if (response.status === 403) throw new Error(endpoint.startsWith('/me/player') ? '请重新连接 Spotify，允许读取和控制播放状态' : 'Spotify 暂不允许读取此歌单的歌曲。可在原 Spotify 中打开；完整读取限自建或协作歌单');
    if (!response.ok) throw new Error('Spotify 暂时连接不上，请稍后再试');
    if (response.status === 204) return null;
    return response.json();
  }
  async player() {
    // progress_ms 对应请求途中的时刻；取发出与收到的中点，避免歌词固定晚半个网络往返。
    const requestedAt = Date.now();
    const data = await this.get('/me/player');
    const sampledAt = Math.round((requestedAt + Date.now()) / 2);
    if (!data) return { available: false };
    const player = { available: true, playing: !!data.is_playing, shuffle: !!data.shuffle_state,
      smartShuffle: typeof data.smart_shuffle === 'boolean' ? data.smart_shuffle : null,
      repeat: ['off', 'context', 'track'].includes(data.repeat_state) ? data.repeat_state : 'off',
      volume: data.device?.volume_percent ?? null, supportsVolume: data.device?.supports_volume !== false,
      device: data.device?.name ?? '', deviceId: data.device?.id ?? '',
      position: (data.progress_ms ?? 0) / 1000, duration: (data.item?.duration_ms ?? 0) / 1000,
      title: data.item?.name ?? '', artist: data.item?.artists?.map(item => item.name).join(' / ') ?? '',
      album: data.item?.album?.name ?? '', cover: data.item?.album?.images?.[0]?.url ?? '',
      receivedAt: sampledAt };
    this.lastPlayer = player; return player;
  }
  async writePlayer(endpoint, method = 'PUT', body, retry = true) {
    if (!this.session) throw new Error('请先连接 Spotify');
    if (Date.now() < this.blockedUntil) throw new Error('Spotify 请求较多，请稍后再试');
    if (this.session.expiresAt - Date.now() < 60000) await this.refresh();
    const response = await this.fetcher(apiRoot + endpoint, { method, headers: { Authorization: `Bearer ${this.session.access}`, ...(body ? { 'Content-Type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(10000) });
    if (response.status === 401 && retry) { await this.refresh(); return this.writePlayer(endpoint, method, body, false); }
    if (response.status === 429) { this.blockedUntil = Date.now() + Math.max(30, Number(response.headers.get('Retry-After')) || 60) * 1000; throw new Error('Spotify 请求较多，请稍后再试'); }
    if (response.status === 403) throw new Error('请重新连接 Spotify，允许控制播放；当前设备也需支持此操作');
    if (!response.ok) throw new Error('Spotify 未能执行，请确认桌面播放器已打开');
  }
  control(input) {
    const relative = input.action === 'seek' || input.action === 'volume';
    if (relative && (!Number.isFinite(input.delta) || Math.abs(input.delta) > (input.action === 'seek' ? 30 : 10))) return Promise.reject(new Error('无效的按键调整'));
    if (relative && this.relativePending[input.action]) {
      this.relativePending[input.action].input.delta += input.delta;
      return this.relativePending[input.action].job;
    }
    input = { ...input };
    const pending = { input, job: null };
    if (relative) this.relativePending[input.action] = pending;
    const command = async () => {
      if (relative && this.relativePending[input.action] === pending) delete this.relativePending[input.action];
      if (!['seek', 'seek-to', 'volume', 'toggle', 'previous', 'next', 'shuffle', 'repeat', 'play-track', 'play-playlist'].includes(input.action)) throw new Error('不支持的播放操作');
      let player = this.lastPlayer && Date.now() - this.lastPlayer.receivedAt < 4000 ? { ...this.lastPlayer } : await this.player();
      if (player.available && player.playing) player.position = Math.min(player.duration, player.position + Math.max(0, (Date.now() - player.receivedAt) / 1000));
      if (!player.available && (input.action === 'play-track' || input.action === 'play-playlist')) {
        const devices = await this.get('/me/player/devices');
        const computers = (devices?.devices ?? []).filter(item => !this.deviceTypes || this.deviceTypes.includes(item.type?.toLowerCase()));
        const device = computers.find(item => item.is_active) ?? (computers.length === 1 ? computers[0] : null);
        if (device) player = { available: true, deviceId: device.id };
      }
      if (!player.available) throw new Error('请先在 Spotify 播放一首歌');
      const device = player.deviceId ? { device_id: player.deviceId } : {};
      const send = (name, query = {}, method = 'PUT', body) => this.writePlayer(`/me/player/${name}?${new URLSearchParams({ ...device, ...query })}`, method, body);
      const remember = patch => { this.lastPlayer = { ...player, ...patch, receivedAt: Date.now() }; return this.lastPlayer; };
      if (input.action === 'seek-to') {
        if (!Number.isFinite(input.position) || input.position < 0) throw new Error('无效歌词时间');
        const position = Math.min(player.duration, input.position);
        await send('seek', { position_ms: String(Math.round(position * 1000)) }); return { position, player: remember({ position }) };
      }
      if (input.action === 'seek') {
        if (!Number.isFinite(input.delta) || Math.abs(input.delta) > 600) throw new Error('无效的进度调整');
        const position = Math.max(0, Math.min(player.duration, player.position + input.delta));
        await send('seek', { position_ms: String(Math.round(position * 1000)) }); return { position, player: remember({ position }) };
      }
      if (input.action === 'volume') {
        if (!Number.isFinite(input.delta) || Math.abs(input.delta) > 100 || player.volume === null || !player.supportsVolume) throw new Error('当前 Spotify 播放设备不支持调整音量');
        const volume = Math.max(0, Math.min(100, player.volume + input.delta));
        await send('volume', { volume_percent: String(volume) }); return { volume, player: remember({ volume }) };
      }
      if (input.action === 'toggle') await send(player.playing ? 'pause' : 'play');
      if (input.action === 'previous' || input.action === 'next') await send(input.action, {}, 'POST');
      if (input.action === 'shuffle') await send('shuffle', { state: String(!player.shuffle) });
      if (input.action === 'repeat') await send('repeat', { state: player.repeat === 'off' ? 'context' : player.repeat === 'context' ? 'track' : 'off' });
      if (input.action === 'play-playlist') {
        if (!validSpotifyId(input.playlistId)) throw new Error('无效歌单');
        await send('play', {}, 'PUT', { context_uri: `spotify:playlist:${input.playlistId}` });
      }
      if (input.action === 'play-track') {
        if (!validSpotifyId(input.id)) throw new Error('无效歌曲');
        if (validSpotifyId(input.playlistId)) {
          await send('play', {}, 'PUT', { context_uri: `spotify:playlist:${input.playlistId}`, offset: { uri: `spotify:track:${input.id}` } });
        } else {
          const queue = Array.isArray(input.queueIds) && input.queueIds.length <= 100 && input.queueIds.every(validSpotifyId) && input.queueIds.includes(input.id) ? input.queueIds : [input.id];
          await send('play', {}, 'PUT', { uris: queue.map(id => `spotify:track:${id}`), offset: { position: queue.indexOf(input.id) } });
        }
      }
      if (input.action === 'toggle') return { accepted: true, player: remember({ playing: !player.playing }) };
      if (input.action === 'shuffle') return { accepted: true, player: remember({ shuffle: !player.shuffle }) };
      if (input.action === 'repeat') return { accepted: true, player: remember({ repeat: player.repeat === 'off' ? 'context' : player.repeat === 'context' ? 'track' : 'off' }) };
      this.lastPlayer = null;
      return { accepted: true };
    };
    const job = this.controlQueue.catch(() => {}).then(command);
    pending.job = job;
    this.controlQueue = job; return job;
  }
  async playlists() {
    const result = []; let offset = 0;
    do {
      const page = await this.get(`/me/playlists?limit=50&offset=${offset}`);
      if (!Array.isArray(page.items)) throw new Error('Spotify 歌单数据不完整');
      result.push(...page.items.filter(row => row && validSpotifyId(row.id)).map(summarizePlaylist));
      offset += page.items.length;
      if (!page.next || !page.items.length) return { items: result, complete: true, syncedAt: Date.now() };
    } while (offset < 10000);
    return { items: result, complete: false, syncedAt: Date.now() };
  }
  async tracks(id, offset = 0) {
    if (id !== 'liked' && !validSpotifyId(id)) throw new Error('无效歌单');
    const path = id === 'liked' ? '/me/tracks' : `/playlists/${id}/items`;
    const page = await this.get(`${path}?limit=50&offset=${offset}`);
    if (!Array.isArray(page.items)) throw new Error('Spotify 歌曲数据不完整');
    return { items: page.items.map(summarizeTrack).filter(Boolean), total: page.total ?? 0,
      nextOffset: page.next && page.items.length ? offset + page.items.length : null };
  }
  disconnect() { this.generation++; this.session = null; this.pending = null; this.lastPlayer = null; }
}
