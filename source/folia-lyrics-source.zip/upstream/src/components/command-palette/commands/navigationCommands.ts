import type { CommandPaletteCommand } from '../types';
import { defineCommand, createToggleCommand, createHomeTabCommand } from '../commandFactories';
import { omni } from '../../../services/onlineMusic/omni';

// src/components/command-palette/commands/navigationCommands.ts
// Commands in the `navigation` group: moving between home tabs, the player, and window-level views.

export const navigationCommands: CommandPaletteCommand[] = [
    defineCommand({
        id: 'lattice-focus-current', group: 'navigation', scope: 'lattice',
        title: 'Lattice locate playing song', description: 'Centre the poster of the playing song on the collage',
        keywords: ['lattice', 'lattice focus', 'lattice locate', 'queue collage', 'recenter', 'now playing', '队列拼贴', '定位', '聚焦当前歌曲', '回到当前歌曲'],
        executeShortcut: 'c',
        // The wall's locate button, from the keyboard: there whenever that button is (a song plays).
        isAvailable: context => !context || Boolean(context.shared.currentSong),
        execute: (_input, context) => {
            context.navigation.locatePlayingSongOnWall();
            return true;
        },
    }),
    createToggleCommand('locate-playing-song', 'navigation', 'Locate the playing song', 'Open the album or playlist it is in and centre its card',
        ['locate', 'find playing song', 'now playing', 'where is this song', '定位', '定位当前歌曲', '正在播放的歌', '所在歌单'],
        context => context.navigation.locatePlayingSong(),
        { isAvailable: context => !context || Boolean(context.shared.currentSong) }),
    createToggleCommand('navigate-home', 'navigation', 'Go home', 'Return to home view', ['home', '首页', '主页'], context => context.navigation.navigateToHome()),
    createToggleCommand('navigate-player', 'navigation', 'Go player', 'Return to player view', ['player', '播放页', '播放器'], context => context.navigation.navigateToPlayer()),
    createToggleCommand('navigate-lattice', 'navigation', 'Lattice open', 'Show the play queue as a queue collage', ['lattice', 'queue collage', 'song wall', 'poster wall', '队列拼贴', '歌曲墙', '海报墙'], context => context.navigation.navigateToLattice(),
        // Already on the wall it is a no-op, and the wall renders the same control slots as the
        // main bar — a slot bound to it would otherwise sit there offering to go nowhere.
        // The stroke stays off the primary modifier keys macOS reserves: `ctrl` here resolves to
        // Cmd, and Electron's default app menu answers Cmd+Q with Quit before the renderer ever
        // sees the keydown. Same for W/M/R/H. Lattice.tsx matches this key to close the wall.
        { isAvailable: context => !context || context.scope.view !== 'lattice', openHotkey: { key: 'b', ctrl: true }, executeShortcut: 'w' }),
    {
        id: 'browser-fullscreen',
        group: 'navigation',
        title: 'Fullscreen',
        description: 'Toggle browser fullscreen',
        keywords: ['full screen', 'f11', 'browser fullscreen', '全屏', '浏览器全屏'],
        isAvailable: (context) => !context?.navigation.isWallpaperMode,
        execute: (_input, context) => context.navigation.toggleBrowserFullscreen(),
    },
    createHomeTabCommand('playlist', 'Open playlists', 'Open playlist home tab', ['playlist', 'playlists', '歌单']),
    createHomeTabCommand('local', 'Open local music', 'Open local music tab', ['local music', 'local', '本地', '本地音乐']),
    createHomeTabCommand('albums', 'Open albums', 'Open albums tab', ['albums', 'album', '专辑']),
    createHomeTabCommand('navidrome', 'Open Navidrome', 'Open Navidrome tab', ['navidrome', 'navi', '服务器']),
    createHomeTabCommand('radio', 'Open radio', 'Open radio tab', ['radio', 'fm', '电台']),
    {
        ...createHomeTabCommand('explore', 'Open explore', 'Open explore tab', ['explore', 'discover', 'recommendations', '探索', '推荐']),
        // Only a provider with a recommendation page of its own has the tab.
        isAvailable: () => omni.getActiveCapabilities().explore === true,
    },
    {
        id: 'desktop-toggle-remote-control',
        platform: ['electron'],
        group: 'navigation',
        title: 'Toggle remote control window',
        description: 'Open or close the remote control window',
        keywords: ['remote control', 'remote window', 'toggle remote', '遥控窗口', '切换遥控窗口', '打开遥控'],
        execute: (_input, context) => context.navigation.toggleRemoteControlWindow(),
    },
    {
        id: 'desktop-toggle-main-window-always-on-top',
        platform: ['electron'],
        group: 'navigation',
        title: 'Toggle main window always on top',
        description: 'Pin or unpin the main window above other windows',
        keywords: ['always on top', 'main window on top', 'pin main window', '主窗口置顶', '切换主窗口置顶', '取消主窗口置顶'],
        isAvailable: (context) => !context?.navigation.isWallpaperMode
            && context?.navigation.isWindowAlwaysOnTopSupported !== false,
        execute: (_input, context) => context.navigation.toggleMainWindowAlwaysOnTop(),
    }
];
