// src/audioNative/ytmPoToken.ts
// YouTube 的音频服务器只给带「来源证明」(PO token) 的请求发**缓存之外**的字节；
// 没有它，直链只有开头约 1MB 能下，后面一律 403（也就是"能读出时长、点播放没声音"）。
// 桌面版就是这么做的：electron/ytm/poToken.cjs —— 用 bgutils-js 把 Google 的 BotGuard
// 脚本跑起来，拿它的答案换一个 integrity token，再为每首歌 mint 一个 poToken。
//
// 手机上没有 Node 主进程，但 WebView 本来就是浏览器：BotGuard 这段第三方脚本放在一个隐藏
// iframe 里跑（自己的全局，不污染 App 页面），两趟网络请求走原生桥（ytmFetch）。
//
// 为什么 mint 函数要用闭包而不是每次去 globalThis 上取 signals：
// signals 是 BotGuard 的快照回调填出来的数组，只有**填它的那一次 eval** 里握着真实引用。
// 跨 eval 靠 globalThis.__foliaYtmSignals 传引用，一旦 iframe 被重建 / 全局被覆盖，
// 读到的就是个空数组或别的东西，报出来正是那句
// "globalThis.__foliaYtmSignals[0] is not a function"。所以这里在填完 signals 的同一个
// eval 里就把 mint 函数闭包着装到全局上，后面只调这一个函数，不再碰 signals 本身。
import { descrambleChallenge, getChallenge } from 'bgutils-js/botguard';
import { buildURL, getHeaders } from 'bgutils-js/utils';
import { ytmFetch } from './ytmHttp';

// YouTube 网页播放器向 BotGuard 要脚本时用的 key。
const REQUEST_KEY = 'O43z0dpjhgX20SCx4KAo';
const SIGNALS = '__foliaYtmSignals';
const INSTALL = '__foliaYtmInstall';
const MINT = '__foliaYtmMint';
const FRAME_MARK = '__foliaYtmFrameId';
// Google 会说 integrity token 能用多久（实测约 12 小时）；没说就按 6 小时算。
const DEFAULT_LIFETIME_MS = 6 * 60 * 60 * 1000;
// 每首歌都在等这一步，没回音就别一直挂着。
const REQUEST_LIMIT_MS = 15000;

type FrameWindow = Window & {
    eval: (code: string) => unknown;
    [key: string]: unknown;
};

let frameSeq = 0;
let framePromise: Promise<HTMLIFrameElement> | null = null;

/** 跑 BotGuard 用的隐藏 iframe（同源 about:blank）。 */
const getFrame = (): Promise<HTMLIFrameElement> => {
    if (framePromise) return framePromise;
    framePromise = new Promise<HTMLIFrameElement>((resolve, reject) => {
        if (typeof document === 'undefined') {
            reject(new Error('BotGuard needs a document'));
            return;
        }
        const frame = document.createElement('iframe');
        frame.style.display = 'none';
        frame.setAttribute('aria-hidden', 'true');
        frame.srcdoc = '<!doctype html><meta charset="utf-8"><title>ytm token</title>';
        frame.addEventListener('load', () => resolve(frame), { once: true });
        document.body.appendChild(frame);
    }).catch(error => {
        framePromise = null;
        throw error;
    });
    return framePromise;
};

const evaluate = async <T>(code: string): Promise<T> => {
    const frame = await getFrame();
    const win = frame.contentWindow as FrameWindow | null;
    if (!win) throw new Error('BotGuard sandbox is unavailable');
    return await win.eval(code) as T;
};

/** 给 iframe 打个号：日志里能看出 mint 时用的还是不是同一个 iframe。 */
const markFrame = async (): Promise<number> => {
    frameSeq += 1;
    const id = frameSeq;
    await evaluate(`globalThis[${JSON.stringify(FRAME_MARK)}] = ${id}; ${id}`);
    return id;
};

// 页面里执行的脚本：把 BotGuard 程序跑起来，解析出它的答案，
// 并**在同一个 eval 里**把安装器闭包着装到全局（见文件头说明）。
//
// 安装器是两段式（和 bgutils-js 的 WebPoMinter.create 一致）：
//   install(integrityTokenBytes) -> mintCallback     第一段：integrity token 换铸造函数
//   mintCallback(encode(binding)) -> Uint8Array      第二段：binding 换 poToken 字节
// 曾经把这两段合成一步、直接 return factory(bytes)，拿回来的是铸造函数而不是 token，
// 报出来正是 "BotGuard minter returned no bytes"。
const runProgram = (challenge: { globalName?: string; program?: string }) => `(async () => {
  const vm = globalThis[${JSON.stringify(challenge.globalName)}];
  if (!vm || typeof vm.a !== 'function') throw new Error('BotGuard is unavailable');
  let started;
  const functions = new Promise(resolve => { started = resolve; });
  const quiet = () => {};
  await vm.a(${JSON.stringify(challenge.program)}, snapshot => started(snapshot), true, undefined, quiet, [[], []], undefined, false, [quiet, quiet, quiet, quiet, quiet]);
  const snapshot = await functions;
  if (typeof snapshot !== 'function') throw new Error('BotGuard gave no snapshot function');
  const signals = [];
  const answer = await new Promise(resolve => snapshot(resolve, [undefined, undefined, signals, undefined]));
  globalThis.${SIGNALS} = signals;
  globalThis.${INSTALL} = async standardToken => {
    const factory = signals[0];
    if (typeof factory !== 'function') {
      throw new Error('signals[0] is ' + typeof factory + ' (len=' + signals.length + ')');
    }
    const mint = await factory(Uint8Array.from(atob(standardToken), char => char.charCodeAt(0)));
    if (typeof mint !== 'function') {
      throw new Error('BotGuard returned no minter (' + typeof mint + ')');
    }
    globalThis.${MINT} = async binding => {
      const bytes = await mint(new TextEncoder().encode(binding));
      if (!(bytes instanceof Uint8Array)) {
        throw new Error('mint returned ' + Object.prototype.toString.call(bytes));
      }
      return btoa(String.fromCharCode.apply(null, Array.from(bytes)))
        .split('+').join('-').split('/').join('_');
    };
    return true;
  };
  return { answer, signalsLen: signals.length, sig0: typeof signals[0] };
})()`;

// BotGuard 的挑战 / 换票请求**不能带 Origin / Referer**：实测（真机 WebView，
// bgutils-js@4.0.3）这两个头只要有一个在场，Google 就下发降级的 BotGuard 程序——
// 快照回调不再往 webPoSignalOutput 填 signals，PO Token 铸不出来，音频直链缺 pot，
// googlevideo 一律 403。UA 也不盖：bgutils-js 的 getHeaders() 在浏览器环境下本就刻意
// 不写 user-agent（只写 x-user-agent），盖成 grpc-web-javascript/0.1 反而制造矛盾特征。
// 细节见 ytmFetch 的 botguard 开关。
const ask = (input: string, init: RequestInit = {}) => ytmFetch(input, {
    ...init,
    // BotGuard 的请求不该带 App 的 YouTube 会话：它用的是自己的一套头。
    guest: true,
    botguard: true,
});

/** 第一段：把 integrity token 交给 iframe 里的安装器，换出 mint 函数（见 runProgram 的两段式）。 */
const installMinter = async (standardToken: string, frameId: number): Promise<void> => {
    const answer = await evaluate<unknown>(`(async () => {
      const install = globalThis[${JSON.stringify(INSTALL)}];
      if (typeof install !== 'function') {
        return { missing: true, installType: typeof install, frameId: globalThis[${JSON.stringify(FRAME_MARK)}] };
      }
      await install(${JSON.stringify(standardToken)});
      return { mintType: typeof globalThis[${JSON.stringify(MINT)}], frameId: globalThis[${JSON.stringify(FRAME_MARK)}] };
    })()`);
    const record = answer as { missing?: boolean; installType?: string; mintType?: string; frameId?: number } | null;
    if (record?.missing) {
        throw new Error(`minter installer missing in frame (expected ${frameId}, got ${record.frameId ?? 'none'}, install=${record.installType})`);
    }
    if (record?.mintType !== 'function') {
        throw new Error(`minter was not installed (mint=${record?.mintType ?? 'n/a'})`);
    }
};

/** 第二段：给一个 binding（videoId）调 mint，拿回 websafe base64 的 poToken。 */
const callMinter = async (binding: string, frameId: number): Promise<string> => {
    const minted = await evaluate<unknown>(`(async () => {
      const fn = globalThis[${JSON.stringify(MINT)}];
      if (typeof fn !== 'function') {
        const s = globalThis[${JSON.stringify(SIGNALS)}];
        return { missing: true, mintType: typeof fn, signalsType: typeof s,
                 signalsIsArray: Array.isArray(s), signalsLen: Array.isArray(s) ? s.length : -1,
                 signalsTypes: Array.isArray(s) ? s.map(x => typeof x) : null,
                 frameId: globalThis[${JSON.stringify(FRAME_MARK)}] };
      }
      return { token: await fn(${JSON.stringify(binding)}), frameId: globalThis[${JSON.stringify(FRAME_MARK)}] };
    })()`);
    const record = minted as {
        token?: string; missing?: boolean; frameId?: number;
        mintType?: string; signalsType?: string; signalsIsArray?: boolean;
        signalsLen?: number; signalsTypes?: string[] | null;
    } | null;
    if (record?.missing) {
        throw new Error(
            `minter missing in frame (expected frame ${frameId}, got ${record.frameId ?? 'none'}; `
            + `mint=${record.mintType}, signals=${record.signalsType}`
            + `${record.signalsIsArray ? `[${record.signalsLen}]:${JSON.stringify(record.signalsTypes)}` : ''})`,
        );
    }
    const token = String(record?.token ?? '');
    if (!token) throw new Error('BotGuard minter returned no bytes');
    return token;
};

let current: { mint: (binding: string) => Promise<string>; until: number } | null = null;
let setUpPromise: Promise<{ mint: (binding: string) => Promise<string>; until: number }> | null = null;

/** 跑一遍完整装配。 */
const setUp = async () => {
    const frameId = await markFrame();
    const challenge = await getChallenge({ fetchFunction: ask as unknown as typeof fetch, requestKey: REQUEST_KEY, useYouTubeAPI: true });
    const interpreter = challenge?.interpreterJavascript?.privateDoNotAccessOrElseSafeScriptWrappedValue;
    if (!interpreter || !challenge?.program || !challenge?.globalName) {
        throw new Error('BotGuard challenge is incomplete');
    }
    console.log(`[Ytm] PoToken: challenge interpreter=${interpreter.length} program=${String(challenge.program).length} global=${challenge.globalName} frame=${frameId}`);
    await evaluate(`(() => { ${interpreter}\n })(); true`);
    const ran = await evaluate<{ answer: unknown; signalsLen: number; sig0: string }>(runProgram(challenge));
    console.log(`[Ytm] PoToken: program answered ${typeof ran?.answer} signals=${ran?.signalsLen} sig0=${ran?.sig0} frame=${frameId}`);
    if (!ran || ran.signalsLen < 1 || ran.sig0 !== 'function') {
        // 快照回调没填 signals：这一轮的 challenge 是降级的，重试也没意义，
        // 直接把结论抛给上层去换 UA 再来（见 mintYtmPoToken）。
        throw new Error(`BotGuard filled no signals (len=${ran?.signalsLen ?? -1}, sig0=${ran?.sig0 ?? 'n/a'})`);
    }
    const response = await ask(buildURL('GenerateIT', true), {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify([REQUEST_KEY, ran?.answer]),
    });
    const raw = await response.text();
    if (!response.ok) throw new Error(`BotGuard answer was refused (status ${response.status}: ${raw.slice(0, 120)})`);
    let parsed: unknown = null;
    try { parsed = JSON.parse(raw); } catch { /* 下面报出来 */ }
    console.log(`[Ytm] PoToken: GenerateIT status=${response.status} head=${raw.slice(0, 160)}`);
    // Google 可能把回答打乱再发（[null, "<打乱的串>"]）：和 challenge 一样解一遍。
    let shaped = parsed as unknown;
    if (Array.isArray(shaped) && typeof shaped[1] === 'string') {
        const descrambled = descrambleChallenge(String(shaped[1]));
        if (descrambled) {
            try { shaped = JSON.parse(descrambled); } catch { /* 不是就打乱的，下面按原样报 */ }
        }
    }
    let integrityToken = '';
    let lifetimeSeconds = 0;
    if (Array.isArray(shaped)) {
        // 实测形状是 [null, 43200, null, "<token>"]：token 是那串长的，寿命是那个数。
        integrityToken = String(shaped.find(value => typeof value === 'string' && value.length > 40) ?? '');
        lifetimeSeconds = Number(shaped.find(value => typeof value === 'number' && Number(value) > 0) ?? 0);
    } else if (shaped && typeof shaped === 'object') {
        const record = shaped as { integrityToken?: unknown; estimatedTtlSecs?: unknown; ttlSecs?: unknown };
        integrityToken = String(record.integrityToken ?? '');
        lifetimeSeconds = Number(record.estimatedTtlSecs ?? record.ttlSecs ?? 0);
    }
    if (!integrityToken) throw new Error(`BotGuard returned no integrity token (${raw.slice(0, 100)})`);
    // websafe base64 → 标准 base64，atob 只认标准的。
    const standard = integrityToken.split('-').join('+').split('_').join('/').split('.').join('=');
    // 第一段：integrity token → mint 函数。装不上就别把这条会话当能用。
    await installMinter(standard, frameId);
    const mint = async (binding: string) => callMinter(binding, frameId);
    // 立刻验一次：能出字节才说明整条链真的通了。
    await mint('selftest');
    const lifetime = Number(lifetimeSeconds) > 0 ? Number(lifetimeSeconds) * 1000 : DEFAULT_LIFETIME_MS;
    console.log(`[Ytm] PoToken: BotGuard is set up, good for ${Math.round(lifetime / 60000)} min`);
    return { mint, until: Date.now() + lifetime };
};

/** 给 `videoId` mint 一个 poToken（绑定到这首歌）。失败就算了：调用方按没有 token 走。 */
export const mintYtmPoToken = async (videoId: string): Promise<string> => {
    try {
        if (!current || Date.now() >= current.until) {
            if (!setUpPromise) {
                setUpPromise = setUp()
                    .then(result => {
                        current = result;
                        return result;
                    })
                    .finally(() => { setUpPromise = null; });
            }
            current = await setUpPromise;
        }
        const token = await current.mint(videoId);
        console.log(`[Ytm] PoToken for ${videoId}: ${token.length} chars`);
        return token;
    } catch (error) {
        console.warn('[Ytm] PoToken could not be minted:', error instanceof Error ? error.message : String(error));
        return '';
    }
};

export const ytmPoTokenReady = (): boolean => current !== null && Date.now() < (current?.until ?? 0);
export const YTM_PO_TOKEN_TIMEOUT_MS = REQUEST_LIMIT_MS;
