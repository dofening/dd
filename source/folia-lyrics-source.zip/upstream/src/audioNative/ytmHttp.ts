// src/audioNative/ytmHttp.ts
// YouTube 的 HTTP 通道，手机版（WebView）用：
//   - 原生桥（OkHttp）优先，浏览器 fetch 兜底；
//   - youtube.com 系的请求带上登录会话（ytmLogin.ts 存下来的 Cookie）；
//   - 账号接口（歌单、喜欢、电台）还要一个 SAPISIDHASH 授权头，这里按 Cookie 里的
//     SAPISID 现算（YouTube 网页客户端就是这么算的）。
import { readYtmCookie } from './ytmLogin';

export const YTM_ORIGIN = 'https://music.youtube.com';
// 账号类请求走 music.youtube.com：Origin 与 SAPISIDHASH 里的 origin 必须一致，
// 而 music.youtube.com 正是 YouTube Music 网页版自己的源（www.youtube.com 会以 400 拒绝）。
const INNERTUBE_BASE = 'https://music.youtube.com/youtubei/v1';
export const YTM_CLIENT_NAME = '67';
/*
 * 网页客户端的版本号是「1.<当天日期>.01.00」。写死一个过去的日期（原来是 2025-02-19）
 * 会被服务端当成老旧客户端，是判 bot 的常见信号之一；这里按当天日期算，
 * 与 ytmusicapi-rs 的 context.rs 保持一致。
 */
export const YTM_CLIENT_VERSION = (() => {
    const now = new Date();
    const stamp = `${now.getUTCFullYear()}${String(now.getUTCMonth() + 1).padStart(2, '0')}${String(now.getUTCDate()).padStart(2, '0')}`;
    return `1.${stamp}.01.00`;
})();

const YOUTUBE_HOST = /^https:\/\/(?:[a-z0-9-]+\.)*(?:youtube|youtu\.be|google|googlevideo|ytimg)\.com/i;
const SIGNOUT_COOKIE = /(?:^|;\s*)(?:__Secure-3PAPISID|SAPISID)=([^;]+)/;

export interface YtmFetchInit extends RequestInit {
    /** 游客请求：不带登录会话（公开歌单的读取用它，免得账号的读法盖过公开的那份）。 */
    guest?: boolean;
    /**
     * BotGuard（PO Token）专用：它的挑战 / 换票请求**不能带 Origin / Referer**。
     * 实测（真机 WebView，bgutils-js@4.0.3）这两个头只要有一个在场，Google 就下发降级的
     * BotGuard 程序——快照回调不再往 webPoSignalOutput 填 signals，PO Token 铸不出来，
     * 音频直链缺 pot 参数，googlevideo 一律 403。UA 也不补，让桥用默认值，
     * 与实测能跑通的那条路径保持一致。
     */
    botguard?: boolean;
}

const webViewUserAgent = (): string => (
    typeof navigator !== 'undefined' && navigator.userAgent
        ? navigator.userAgent
        : 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36'
);

/**
 * 本机的 visitorData。poToken 是**和 visitor 配对**校验的：请求里的 visitorData 和铸 token
 * 时用的那个对不上，googlevideo 就当没有 token，直链只给开头约 1 MB，后面全 403。
 */
let visitorData = '';

export const ytmVisitorData = (): string => visitorData;

/** 取（并缓存）visitorData：YouTube Music 首页 HTML 的 ytcfg 里就带着。 */
export const ensureVisitorData = async (): Promise<string> => {
    if (visitorData) return visitorData;
    for (const page of [`${YTM_ORIGIN}/`, 'https://www.youtube.com/']) {
        try {
            const response = await ytmFetch(page, { guest: true });
            const html = await response.text();
            const found = /"VISITOR_DATA":"([^"]+)"/.exec(html)?.[1] ?? '';
            if (found) {
                visitorData = found;
                return visitorData;
            }
        } catch (error) {
            console.warn('[YTM] visitorData failed:', error instanceof Error ? error.message : String(error));
        }
    }
    return '';
};

export const innertubeContext = () => ({
    client: {
        hl: 'zh-CN',
        gl: 'US',
        clientName: 'WEB_REMIX',
        clientVersion: YTM_CLIENT_VERSION,
        osName: 'Android',
        osVersion: '16',
        userAgent: webViewUserAgent(),
        ...(visitorData ? { visitorData } : {}),
    },
});

// 最近一次 /youtubei/v1/search 的回答长什么样：0 条结果时据此说清楚是哪一环出的问题
// （网页/同意页、空 shelf、还是解析出的条目被过滤掉了）。只在诊断用，不参与逻辑。
export type YtmLastSearchAnswer = { status: number; length: number; html: boolean; hasMusicShelf: boolean; head: string };
let lastSearchAnswer: YtmLastSearchAnswer | null = null;
export const ytmLastSearchAnswer = (): YtmLastSearchAnswer | null => lastSearchAnswer;

/**
 * 给 youtubei.js 与 InnerTube 直连用的 fetch：原生平台上直接走 FoliaBridge（OkHttp），不依赖全局
 * fetch 垫片。理由有两层：WebView 页面源是 https://localhost，去 YouTube 是跨域；而 youtubei 的
 * 请求既有 JSON 也有较慢的长查询，垫片那 30 秒上限不够稳。这里给 60 秒。
 */
export const ytmFetch = async (input: unknown, init: YtmFetchInit = {}): Promise<Response> => {
    // youtubei.js 的 HTTPClient 先 new Request(request_url, 原始init) 再以
    // fetch(request, { body, headers, ... }) 回调进来——method 在 Request 对象里，
    // init 里只有 body/headers。只读 init.method 的话 POST 会被当成 GET 发出去
    // （表现为 youtubei/v1/player 一律 405）。
    const inputMethod = typeof input === 'object' && input !== null && 'method' in input
        ? String((input as { method?: unknown }).method ?? '')
        : '';
    const method = (String(init.method ?? '') || inputMethod || 'GET').toUpperCase();
    const requestUrl = typeof input === 'string'
        ? input
        : (input as { url?: string } | null)?.url ?? String(input);
    const { isNativeBridgeAvailable, bridgeRequest } = await import('./core');
    if (!isNativeBridgeAvailable()) return await globalThis.fetch(input as RequestInfo, init);
    const headers: Record<string, string> = {};
    new Headers(init.headers ?? {}).forEach((value, key) => {
        headers[key] = value;
    });
    if (init.botguard) {
        // 只用调用方给的头，见 YtmFetchInit.botguard：Origin / Referer 会让 BotGuard 降级。
    } else {
        // 原生桥默认的 UA 是 okhttp/x.y；YouTube 看到和自己出的客户端头（x-youtube-client-name 等）
        // 对不上的 UA，会回一段没有 songs 段的空页面——表现就是"搜索一直没结果"。
        // 这里用 WebView 自己的 UA，和浏览器的请求保持一致。
        if (!Object.keys(headers).some(key => key.toLowerCase() === 'user-agent')) {
            headers['User-Agent'] = webViewUserAgent();
        }
        if (YOUTUBE_HOST.test(requestUrl)) {
            if (!headers.Origin) headers.Origin = 'https://www.youtube.com';
            if (!headers.Referer) headers.Referer = 'https://music.youtube.com/';
            // 登录过就带上会话：歌单、喜欢、推荐才认得出是谁。（游客请求显式不要。）
            if (!init.guest && !Object.keys(headers).some(key => key.toLowerCase() === 'cookie')) {
                const cookie = await readYtmCookie();
                if (cookie) headers.Cookie = cookie;
            }
        }
    }
    const body = typeof init.body === 'string' ? init.body : undefined;
    const answer = await bridgeRequest({
        url: requestUrl,
        method,
        headers,
        ...(body === undefined ? {} : { body }),
        // YouTube 会把未带地区确认的请求 302 到同意页；不跟随就会拿到一段 HTML，
        // JSON 解析失败后表现得像"搜索没有结果"。
        followRedirects: true,
        timeoutMs: 60_000,
    });
    if (answer.status >= 400) {
        console.warn('[YTM] http', answer.status, String(answer.body ?? '').slice(0, 180));
    }
    if (requestUrl.includes('/youtubei/v1/search')) {
        const text = String(answer.body ?? '');
        lastSearchAnswer = {
            status: answer.status,
            length: text.length,
            html: /<!doctype html|<html/i.test(text.slice(0, 400)),
            hasMusicShelf: text.includes('musicShelfRenderer'),
            head: text.slice(0, 120).replace(/\s+/g, ' '),
        };
    }
    const responseHeaders = new Headers();
    for (const [key, value] of Object.entries(answer.headers ?? {})) {
        if (key.toLowerCase() === 'set-cookie') continue;
        responseHeaders.set(key, String(value));
    }
    return new Response(answer.body ?? '', { status: answer.status, headers: responseHeaders });
};

const bytesToHex = (bytes: Uint8Array): string => Array.from(bytes)
    .map(byte => byte.toString(16).padStart(2, '0'))
    .join('');

/** SHA-256 的十六进制串（账号对外只露 24 位摘要，和桌面版一致）。 */
export const sha256Hex = async (text: string): Promise<string> => {
    const subtle = globalThis.crypto?.subtle;
    if (subtle) {
        const digest = await subtle.digest('SHA-256', new TextEncoder().encode(text));
        return bytesToHex(new Uint8Array(digest));
    }
    const { default: CryptoES } = await import('./vendor/crypto-es.mjs');
    return String(CryptoES.SHA256(text).toString(CryptoES.enc.Hex));
};

/** SHA-1 的十六进制串：WebView 的 crypto.subtle 优先（页面源是 https://localhost，算安全上下文）。 */
export const sha1Hex = async (text: string): Promise<string> => {
    const subtle = globalThis.crypto?.subtle;
    if (subtle) {
        const digest = await subtle.digest('SHA-1', new TextEncoder().encode(text));
        return bytesToHex(new Uint8Array(digest));
    }
    const { default: CryptoES } = await import('./vendor/crypto-es.mjs');
    return String(CryptoES.SHA1(text).toString(CryptoES.enc.Hex));
};

/**
 * 账号接口要的授权头：`SAPISIDHASH <时间戳>_<sha1(时间戳 + SAPISID + origin)>`。
 * 没登录（Cookie 里没有 SAPISID）就返回 null：此时按游客发，YouTube 会回"请登录"，
 * 由调用方翻译成一句人话。
 */
export const ytmSessionAuth = async (): Promise<{ authorization: string; cookie: string } | null> => {
    const cookie = await readYtmCookie();
    const sapisid = SIGNOUT_COOKIE.exec(cookie)?.[1] ?? '';
    if (!sapisid) return null;
    const timestamp = Math.floor(Date.now() / 1000);
    const hash = await sha1Hex(`${timestamp} ${sapisid} ${YTM_ORIGIN}`);
    return { authorization: `SAPISIDHASH ${timestamp}_${hash}`, cookie };
};

/** 一个 YouTube 的 InnerTube 回答，解析成 JSON；HTML（同意页、登录页）在这里就说清楚。 */
export const innertubePost = async (
    endpoint: string,
    body: Record<string, unknown>,
    options: { guest?: boolean } = {},
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<any> => {
    const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'X-YouTube-Client-Name': YTM_CLIENT_NAME,
        'X-YouTube-Client-Version': YTM_CLIENT_VERSION,
        Origin: YTM_ORIGIN,
        'X-Origin': YTM_ORIGIN,
        Referer: `${YTM_ORIGIN}/`,
    };
    if (!options.guest) {
        const auth = await ytmSessionAuth();
        if (auth) {
            headers.Authorization = auth.authorization;
            headers['X-Goog-AuthUser'] = '0';
        }
    }
    const response = await ytmFetch(`${INNERTUBE_BASE}/${endpoint}?prettyPrint=false&alt=json`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ context: innertubeContext(), ...body }),
        guest: options.guest === true,
    });
    const text = await response.text();
    if (!response.ok) {
        throw new Error(`YouTube ${endpoint} 请求失败：HTTP ${response.status}（${text.slice(0, 120).replace(/\s+/g, ' ')}）`);
    }
    try {
        return JSON.parse(text);
    } catch {
        throw new Error(`YouTube ${endpoint} 返回的不是 JSON（${text.length} 字节，${text.slice(0, 80).replace(/\s+/g, ' ')}）`);
    }
};
