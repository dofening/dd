// 上游快照缺少此可选在线平台路由；不伪造成功或绕过平台授权。
export async function handleApiRequest(_request: unknown): Promise<never> {
  throw new Error('想要什么资源请联系哥哥');
}
