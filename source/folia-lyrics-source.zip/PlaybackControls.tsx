import React, { useEffect, useRef, useState } from 'react';
import { Shuffle, SkipBack, Play, Pause, SkipForward, Repeat, Repeat1, Sparkles, ListMusic } from 'lucide-react';

export type SpotifyPlayer = { available?: boolean; playing?: boolean; shuffle?: boolean; smartShuffle?: boolean | null; repeat?: string; volume?: number; device?: string; cover?: string; title?: string; artist?: string; album?: string; duration?: number; position?: number; receivedAt?: number };
export default function PlaybackControls({ onPlayer, onNotice, onTimeline, hasLyrics }: { onPlayer: (value: SpotifyPlayer) => void; onNotice: (value: string) => void; onTimeline: () => void; hasLyrics: boolean }) {
  const [player, setPlayer] = useState<SpotifyPlayer>({});
  const [busy, setBusy] = useState(false);
  const handlers = useRef({ onPlayer, onNotice }); handlers.current = { onPlayer, onNotice };
  const refresh = useRef<() => void>(() => {});
  useEffect(() => {
    let stopped = false; let timer: ReturnType<typeof setTimeout>;
    async function poll() {
      clearTimeout(timer);
      try {
        const response = await fetch('/api/spotify/player', { signal: AbortSignal.timeout(12000) });
        const data = await response.json();
        if (!stopped) { const value = response.ok ? data : { available: false }; setPlayer(value); handlers.current.onPlayer(value); }
      } catch { if (!stopped) { setPlayer({ available: false }); handlers.current.onPlayer({ available: false }); } }
      if (!stopped) timer = setTimeout(poll, 1800);
    }
    refresh.current = () => { void poll(); };
    const updated = () => { void poll(); };
    window.addEventListener('spotify-control-updated', updated); void poll();
    return () => { stopped = true; clearTimeout(timer); window.removeEventListener('spotify-control-updated', updated); };
  }, []);
  async function control(action: string) {
    setBusy(true);
    try {
      const response = await fetch('/api/spotify/control', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action }) });
      const result = await response.json(); if (!response.ok) throw new Error(result.error);
      if (result.player) { setPlayer(result.player); handlers.current.onPlayer(result.player); }
      refresh.current();
    } catch (error) { handlers.current.onNotice(error instanceof Error ? error.message : 'Spotify 未执行操作'); }
    finally { setBusy(false); }
  }
  const disabled = busy || !player.available;
  return <div className="transport-group">
    <div className="transport" aria-label="Spotify 播放控制">
      <button disabled={disabled} className={player.shuffle ? 'is-active' : ''} aria-label="随机播放" aria-pressed={!!player.shuffle}
        title={player.smartShuffle === null ? '随机播放（Spotify 接口不区分智能随机）' : '随机播放'} onClick={() => void control('shuffle')}><Shuffle size={17}/></button>
      <button disabled={disabled} aria-label="上一首" onClick={() => void control('previous')}><SkipBack size={20} fill="currentColor"/></button>
      <button disabled={disabled} className="transport-play" aria-label={player.playing ? '暂停' : '播放'} onClick={() => void control('toggle')}>{player.playing ? <Pause size={19} fill="currentColor"/> : <Play size={19} fill="currentColor"/>}</button>
      <button disabled={disabled} aria-label="下一首" onClick={() => void control('next')}><SkipForward size={20} fill="currentColor"/></button>
      <button disabled={disabled} className={player.repeat && player.repeat !== 'off' ? 'is-active' : ''} aria-label="循环模式" title={player.repeat === 'track' ? '单曲循环' : player.repeat === 'context' ? '歌单循环' : '循环关闭'} onClick={() => void control('repeat')}>{player.repeat === 'track' ? <Repeat1 size={17}/> : <Repeat size={17}/>}</button>
      <button disabled className={player.smartShuffle === true ? 'smart-link is-active' : 'smart-link'} aria-label="智能随机暂不支持" title="Spotify 暂未向第三方开放智能随机的独立控制"><Sparkles size={16}/></button>
      <button disabled={!hasLyrics} aria-label="歌词列表与跳转" title="点选歌词跳到对应进度" onClick={onTimeline}><ListMusic size={17}/></button>
    </div>
    <span className="transport-caption">{player.available ? `${player.device || 'Spotify'}${player.volume !== undefined ? ` · 音量 ${player.volume}%` : ''}` : '连接 Spotify 后可控制播放'}</span>
  </div>;
}
