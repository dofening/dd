import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const child = spawn(process.execPath, [path.join(root, 'node_modules/vite/bin/vite.js'), 'build', '--configLoader', 'native', '--outDir', 'dist-next'], { cwd: root, stdio: 'inherit' });
child.on('exit', code => process.exit(code ?? 1));
