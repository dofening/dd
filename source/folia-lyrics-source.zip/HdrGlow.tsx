/// <reference types="@webgpu/types" />
import React, { useEffect, useRef, useState } from 'react';
import type { MotionValue } from 'framer-motion';

export type HdrStatus = 'starting' | 'sdr' | 'unavailable' | 'active';

// 用低分辨率的浮点画布画平滑高光，歌词和背景仍由原来的动画绘制。
const shader = `
struct Glow {
  tint: vec4f,
  view: vec4f,
}
@group(0) @binding(0) var<uniform> glow: Glow;

@vertex fn vertex(@builtin(vertex_index) i: u32) -> @builtin(position) vec4f {
  let points = array<vec2f, 3>(vec2f(-1, -1), vec2f(3, -1), vec2f(-1, 3));
  return vec4f(points[i], 0, 1);
}

fn light(uv: vec2f, center: vec2f, strength: f32) -> vec4f {
  let offset = (uv - center) * vec2f(glow.view.z, 1.0);
  let slant = vec2f(offset.x + offset.y * 0.6, offset.y * 1.8);
  let distance = dot(slant, slant);
  let halo = exp(-38.0 * distance);
  let core = exp(-1450.0 * distance);
  let alpha = strength * (0.14 * halo + 0.70 * core);
  // 高光超过 SDR 白点 1.0。输出按 alpha 预乘，供浏览器与歌词画面合成。
  let color = mix(glow.tint.rgb, vec3f(1.82, 1.77, 1.69), core);
  return vec4f(color * alpha, alpha);
}

@fragment fn fragment(@builtin(position) pixel: vec4f) -> @location(0) vec4f {
  let uv = pixel.xy / glow.view.xy;
  let phase = glow.view.w;
  let drift = vec2f(0.040 * sin(phase), 0.029 * sin(phase * 0.7));
  let upper = light(uv, vec2f(0.79, 0.26) + drift, 1.0);
  let lower = light(uv, vec2f(0.22, 0.73) - drift, 0.48);
  return upper + lower * (1.0 - upper.a);
}`;

export default function HdrGlow({ tint, clock, onStatus }: {
  tint: string; clock: MotionValue<number>; onStatus: (status: HdrStatus) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestDraw = useRef<(() => void) | null>(null);
  const tintRef = useRef(tint);
  tintRef.current = tint;
  const [hasRange, setHasRange] = useState(() => matchMedia('(dynamic-range: high)').matches);

  useEffect(() => {
    const range = matchMedia('(dynamic-range: high)');
    const update = () => setHasRange(range.matches);
    range.addEventListener('change', update);
    update();
    return () => range.removeEventListener('change', update);
  }, []);

  useEffect(() => { requestDraw.current?.(); }, [tint]);

  useEffect(() => {
    if (!hasRange) { onStatus('sdr'); return; }
    const canvas = canvasRef.current;
    const gpu = navigator.gpu;
    if (!canvas || !gpu) { onStatus('unavailable'); return; }

    let device: GPUDevice | undefined;
    let context: GPUCanvasContext | null = null;
    let frame = 0;
    let stopped = false;
    let unsubscribe: (() => void) | undefined;
    let observer: ResizeObserver | undefined;
    let schedule: (() => void) | undefined;
    const motion = matchMedia('(prefers-reduced-motion: reduce)');
    const stop = () => {
      if (stopped) return;
      stopped = true;
      cancelAnimationFrame(frame);
      unsubscribe?.();
      observer?.disconnect();
      if (schedule) {
        document.removeEventListener('visibilitychange', schedule);
        motion.removeEventListener('change', schedule);
      }
      requestDraw.current = null;
      context?.unconfigure();
      device?.destroy();
    };
    const fallback = () => {
      if (stopped) return;
      stop();
      onStatus('unavailable');
    };

    onStatus('starting');
    async function start(surface: HTMLCanvasElement) {
      const adapter = await gpu.requestAdapter({ powerPreference: 'low-power' });
      if (stopped) return;
      if (!adapter) { fallback(); return; }
      const graphics = await adapter.requestDevice();
      if (stopped) { graphics.destroy(); return; }
      device = graphics;
      context = surface.getContext('webgpu');
      if (!context) { fallback(); return; }
      const target = context;
      void graphics.lost.then(fallback);
      graphics.addEventListener('uncapturederror', event => { event.preventDefault(); fallback(); });
      graphics.pushErrorScope('validation');
      target.configure({ device: graphics, format: 'rgba16float', colorSpace: 'srgb', alphaMode: 'premultiplied', toneMapping: { mode: 'extended' } });
      const configuration = target.getConfiguration?.();
      if (configuration?.format !== 'rgba16float' || configuration.toneMapping?.mode !== 'extended') {
        await graphics.popErrorScope();
        fallback();
        return;
      }

      const module = graphics.createShaderModule({ code: shader });
      const pipeline = await graphics.createRenderPipelineAsync({ layout: 'auto',
        vertex: { module, entryPoint: 'vertex' }, fragment: { module, entryPoint: 'fragment', targets: [{ format: 'rgba16float' }] } });
      if (await graphics.popErrorScope()) { fallback(); return; }
      if (stopped) return;
      const uniform = graphics.createBuffer({ size: 32, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
      const binding = graphics.createBindGroup({ layout: pipeline.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: uniform } }] });
      const values = new Float32Array(8);
      let lastPaint = -Infinity;
      let ready = false;

      const draw = (now: number) => {
        frame = 0;
        if (stopped || document.hidden) return;
        const width = surface.clientWidth, height = surface.clientHeight;
        if (!width || !height) return;
        const scale = Math.min(1, 768 / Math.max(width, height));
        const pixelsWide = Math.max(1, Math.round(width * scale));
        const pixelsHigh = Math.max(1, Math.round(height * scale));
        if (surface.width !== pixelsWide) surface.width = pixelsWide;
        if (surface.height !== pixelsHigh) surface.height = pixelsHigh;
        const color = /^#[\da-f]{6}$/i.test(tintRef.current) ? tintRef.current : '#a5bfed';
        values[0] = parseInt(color.slice(1, 3), 16) / 255;
        values[1] = parseInt(color.slice(3, 5), 16) / 255;
        values[2] = parseInt(color.slice(5, 7), 16) / 255;
        values[4] = pixelsWide;
        values[5] = pixelsHigh;
        values[6] = Math.max(0.65, Math.min(2, width / height));
        values[7] = motion.matches ? 0 : clock.get() * 0.24;
        try {
          graphics.queue.writeBuffer(uniform, 0, values);
          const commands = graphics.createCommandEncoder();
          const pass = commands.beginRenderPass({ colorAttachments: [{ view: target.getCurrentTexture().createView(),
            clearValue: { r: 0, g: 0, b: 0, a: 0 }, loadOp: 'clear', storeOp: 'store' }] });
          pass.setPipeline(pipeline);
          pass.setBindGroup(0, binding);
          pass.draw(3);
          pass.end();
          graphics.queue.submit([commands.finish()]);
          lastPaint = now;
          if (!ready) { ready = true; onStatus('active'); }
        } catch { fallback(); }
      };

      schedule = () => {
        if (!stopped && !frame && !document.hidden) frame = requestAnimationFrame(draw);
      };
      requestDraw.current = schedule;
      const redraw = schedule;
      unsubscribe = clock.on('change', () => {
        if (!motion.matches && performance.now() - lastPaint >= 1000 / 30) redraw();
      });
      observer = new ResizeObserver(redraw);
      observer.observe(surface);
      document.addEventListener('visibilitychange', redraw);
      motion.addEventListener('change', redraw);
      redraw();
    }

    void start(canvas).catch(fallback);
    return stop;
  }, [hasRange, clock, onStatus]);

  return <canvas ref={canvasRef} className="hdr-glow" aria-hidden="true"/>;
}
