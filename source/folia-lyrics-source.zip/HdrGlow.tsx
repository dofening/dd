/// <reference types="@webgpu/types" />
import React, { useEffect, useRef, useState } from 'react';
import type { MotionValue } from 'framer-motion';
import type { Line } from './upstream/src/types';
import { buildGlyphs, progressOf, type Glyph } from './styles/glyphs';

export type HdrStatus = 'starting' | 'sdr' | 'unavailable' | 'active' | 'no-text';

// HDR 字形高光：不另画一套歌词，而是在当前动画自己排好的歌词上，把正在唱和刚唱过的字描一层超过 SDR 白点的亮度。
// 1. 每隔一小段时间，在 .stage 里按顺序找出与当前歌词行逐字相同的可见文字（适用于用网页文字绘制歌词的动画）。
// 2. 每帧按歌词时钟算出每个字的演唱进度，用该字所在元素的完整变换（位移、旋转、缩放）把字形画进遮罩。
// 3. WebGPU 浮点画布按遮罩输出扩展亮度。用 WebGL 绘制歌词的动画（商籁、凝彩、绘光、花火、镜台）没有网页文字，报告 no-text。
const shader = `
struct View { tint: vec4f, size: vec4f }
@group(0) @binding(0) var<uniform> view: View;
@group(0) @binding(1) var maskSampler: sampler;
@group(0) @binding(2) var mask: texture_2d<f32>;

struct Out { @builtin(position) position: vec4f, @location(0) uv: vec2f }
@vertex fn vertex(@builtin(vertex_index) i: u32) -> Out {
  let points = array<vec2f, 3>(vec2f(-1, -1), vec2f(3, -1), vec2f(-1, 3));
  var out: Out;
  out.position = vec4f(points[i], 0, 1);
  out.uv = vec2f((points[i].x + 1) * 0.5, (1 - points[i].y) * 0.5);
  return out;
}

@fragment fn fragment(input: Out) -> @location(0) vec4f {
  let texel = 1.0 / view.size.xy;
  let core = textureSample(mask, maskSampler, input.uv).a;
  // 一圈很淡的柔光，让字形边缘与原动画的字自然衔接。
  var halo = 0.0;
  for (var k = 0; k < 8; k++) {
    let angle = f32(k) * 0.7853982;
    halo += textureSample(mask, maskSampler, input.uv + vec2f(cos(angle), sin(angle)) * texel * 2.5).a;
  }
  halo = halo / 8.0;
  let gain = view.size.z;
  let alpha = clamp(core * 0.92 + halo * 0.22, 0.0, 1.0);
  // 字心接近白色、边缘带主题色；数值超过 1.0 的部分即为 HDR 高光。输出按 alpha 预乘。
  let color = mix(view.tint.rgb, vec3f(1.0, 0.985, 0.95), 0.62 * core) * gain;
  return vec4f(color * alpha, alpha);
}`;

type GlyphSlot = { node: Text; start: number; end: number; element: Element; glyph: number };
const segmenter = new Intl.Segmenter('zh', { granularity: 'grapheme' });
const comparable = (text: string) => text.normalize('NFKC').toLocaleLowerCase();
const isMark = (text: string) => !text.trim() || /^[\p{P}\p{S}]+$/u.test(text);

/** 元素自身排版位置连同所有祖先变换，映射到视口坐标的矩阵。 */
function screenMatrix(element: Element) {
  const chain: HTMLElement[] = [];
  for (let node: HTMLElement | null = element instanceof HTMLElement ? element : element.parentElement; node && node !== document.body; node = node.offsetParent as HTMLElement | null) chain.unshift(node);
  let matrix = new DOMMatrix();
  for (const node of chain) {
    const style = getComputedStyle(node);
    const parent = node.offsetParent as HTMLElement | null;
    // offsetLeft/Top 是未变换的排版位置，相对父元素内边距边缘；加上父元素边框宽度，得到相对父元素边框盒的位置。
    matrix = matrix.translate(node.offsetLeft + (parent?.clientLeft ?? 0), node.offsetTop + (parent?.clientTop ?? 0));
    if (style.transform && style.transform !== 'none') {
      const [ox, oy] = style.transformOrigin.split(' ').map(parseFloat);
      matrix = matrix.translate(ox, oy).multiply(new DOMMatrix(style.transform)).translate(-ox, -oy);
    }
  }
  return matrix;
}

/** 在舞台的可见文字里找出与当前歌词行逐字一致的位置（同一行可能出现多次，如字形与发光层）。 */
function mapLine(stage: Element, glyphs: Glyph[]): GlyphSlot[] {
  const wanted = glyphs.map((glyph, index) => ({ text: comparable(glyph.text), index })).filter(item => !isMark(item.text));
  if (!wanted.length) return [];
  const seen: GlyphSlot[] = [];
  const walker = document.createTreeWalker(stage, NodeFilter.SHOW_TEXT);
  for (let node = walker.nextNode() as Text | null; node; node = walker.nextNode() as Text | null) {
    const element = node.parentElement;
    // SVG 等非 HTML 元素没有可用的排版位置，跳过。
    if (!(element instanceof HTMLElement) || !node.data.trim()) continue;
    const style = getComputedStyle(element);
    if (style.visibility === 'hidden' || style.display === 'none') continue;
    let offset = 0;
    for (const { segment } of segmenter.segment(node.data)) {
      if (!isMark(segment)) seen.push({ node, start: offset, end: offset + segment.length, element, glyph: -1 });
      offset += segment.length;
    }
  }
  const texts = seen.map(slot => comparable(slot.node.data.slice(slot.start, slot.end)));
  // 有的动画把同一个字画两层（如发光层与正文层逐词交错），所以按“顺序出现、中间可夹少量别的字”匹配，
  // 每轮取一组完整的一行，最多取四组（同一行的多个图层）。
  const found: GlyphSlot[] = [];
  const used = new Array(texts.length).fill(false);
  for (let round = 0; round < 4; round++) {
    const picked: number[] = [];
    for (let i = 0; i < texts.length && picked.length < wanted.length; i++) {
      if (used[i]) continue;
      if (picked.length && i - picked[picked.length - 1] > 12) picked.length = 0;
      if (texts[i] === wanted[picked.length].text) picked.push(i);
      else if (!picked.length) continue;
    }
    if (picked.length < wanted.length) break;
    picked.forEach((index, k) => { used[index] = true; found.push({ ...seen[index], glyph: wanted[k].index }); });
  }
  return found;
}

/** 文字实际可见程度：沿祖先链相乘的不透明度，再乘文字颜色自身的透明度。 */
function visibility(element: Element) {
  const style = getComputedStyle(element);
  const fill = style.webkitTextFillColor || style.color;
  const alpha = /rgba?\(([^)]+)\)/.exec(fill)?.[1].split(',')[3];
  let opacity = alpha === undefined ? 1 : Number(alpha);
  for (let node: Element | null = element; node && node !== document.body; node = node.parentElement) opacity *= Number(getComputedStyle(node).opacity || 1);
  return opacity;
}

// 唱过的字保持中等亮度，正在唱的字最亮，未唱到的字不加 HDR（保持原动画的清晰字形）。
const glyphLevel = (glyph: Glyph, time: number) => {
  const p = progressOf(glyph, time);
  if (p <= 0) return 0;
  if (p < 1) return 0.55 + 0.45 * Math.sin(p * Math.PI * 0.5);
  return Math.max(0.5, 1 - (time - glyph.end) * 0.35);
};

export default function HdrGlow({ tint, clock, line, onStatus }: {
  tint: string; clock: MotionValue<number>; line: Line | null; onStatus: (status: HdrStatus) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestDraw = useRef<(() => void) | null>(null);
  const tintRef = useRef(tint); tintRef.current = tint;
  const lineRef = useRef(line); lineRef.current = line;
  const [hasRange, setHasRange] = useState(() => matchMedia('(dynamic-range: high)').matches);

  useEffect(() => {
    const range = matchMedia('(dynamic-range: high)');
    const update = () => setHasRange(range.matches);
    range.addEventListener('change', update);
    update();
    return () => range.removeEventListener('change', update);
  }, []);

  useEffect(() => { requestDraw.current?.(); }, [tint, line]);

  useEffect(() => {
    if (!hasRange) { onStatus('sdr'); return; }
    const canvas = canvasRef.current;
    const gpu = navigator.gpu;
    if (!canvas || !gpu) { onStatus('unavailable'); return; }

    let device: GPUDevice | undefined;
    let context: GPUCanvasContext | null = null;
    let frame = 0;
    let stopped = false;
    let unsubscribe: (() => void) | undefined;
    let observer: ResizeObserver | undefined;
    let schedule: (() => void) | undefined;
    const stop = () => {
      if (stopped) return;
      stopped = true;
      cancelAnimationFrame(frame);
      unsubscribe?.();
      observer?.disconnect();
      if (schedule) document.removeEventListener('visibilitychange', schedule);
      requestDraw.current = null;
      context?.unconfigure();
      device?.destroy();
    };
    const fallback = () => { if (stopped) return; stop(); onStatus('unavailable'); };

    onStatus('starting');
    async function start(surface: HTMLCanvasElement) {
      const adapter = await gpu.requestAdapter({ powerPreference: 'low-power' });
      if (stopped) return;
      if (!adapter) { fallback(); return; }
      const graphics = await adapter.requestDevice();
      if (stopped) { graphics.destroy(); return; }
      device = graphics;
      context = surface.getContext('webgpu');
      if (!context) { fallback(); return; }
      const target = context;
      void graphics.lost.then(fallback);
      graphics.addEventListener('uncapturederror', event => { event.preventDefault(); fallback(); });
      graphics.pushErrorScope('validation');
      target.configure({ device: graphics, format: 'rgba16float', colorSpace: 'srgb', alphaMode: 'premultiplied', toneMapping: { mode: 'extended' } });
      const configuration = target.getConfiguration?.();
      if (configuration?.format !== 'rgba16float' || configuration.toneMapping?.mode !== 'extended') {
        await graphics.popErrorScope(); fallback(); return;
      }
      const module = graphics.createShaderModule({ code: shader });
      const pipeline = await graphics.createRenderPipelineAsync({ layout: 'auto',
        vertex: { module, entryPoint: 'vertex' }, fragment: { module, entryPoint: 'fragment', targets: [{ format: 'rgba16float' }] } });
      if (await graphics.popErrorScope()) { fallback(); return; }
      if (stopped) return;
      const uniform = graphics.createBuffer({ size: 32, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
      const sampler = graphics.createSampler({ magFilter: 'linear', minFilter: 'linear' });
      const values = new Float32Array(8);
      // 遮罩：普通 2D 画布按当前动画的字形位置画白字，再上传为纹理。
      const maskCanvas = document.createElement('canvas');
      const mask2d = maskCanvas.getContext('2d', { willReadFrequently: false })!;
      let texture: GPUTexture | null = null; let binding: GPUBindGroup | null = null;
      let slots: GlyphSlot[] = []; let mappedLine: Line | null = null; let mappedAt = 0; let glyphs: Glyph[] = [];
      let missingSince = 0; let lastPaint = -Infinity; let ready = false; let reported: HdrStatus | null = null;
      const report = (status: HdrStatus) => { if (reported !== status) { reported = status; onStatus(status); } };
      const range = document.createRange();

      const draw = (now: number) => {
        frame = 0;
        if (stopped || document.hidden) return;
        const width = surface.clientWidth, height = surface.clientHeight;
        if (!width || !height) return;
        const scale = Math.min(window.devicePixelRatio || 1, 1600 / Math.max(width, height));
        const pixelsWide = Math.max(1, Math.round(width * scale)), pixelsHigh = Math.max(1, Math.round(height * scale));
        if (surface.width !== pixelsWide || surface.height !== pixelsHigh || !texture) {
          surface.width = pixelsWide; surface.height = pixelsHigh; maskCanvas.width = pixelsWide; maskCanvas.height = pixelsHigh;
          texture?.destroy();
          texture = graphics.createTexture({ size: [pixelsWide, pixelsHigh], format: 'rgba8unorm',
            usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST | GPUTextureUsage.RENDER_ATTACHMENT });
          binding = graphics.createBindGroup({ layout: pipeline.getBindGroupLayout(0), entries: [
            { binding: 0, resource: { buffer: uniform } }, { binding: 1, resource: sampler }, { binding: 2, resource: texture.createView() }] });
        }
        const time = clock.get();
        const current = lineRef.current;
        const stage = document.querySelector('.stage');
        // 换行时立即重新对应字形；同一行内每 0.3 秒刷新一次，跟上动画里元素的出现与消失。
        if (current !== mappedLine || now - mappedAt > 300) {
          glyphs = buildGlyphs(current); slots = stage && glyphs.length ? mapLine(stage, glyphs) : [];
          mappedLine = current; mappedAt = now;
          if (glyphs.length && !slots.length) { missingSince ||= now; if (now - missingSince > 2000) report('no-text'); }
          else { missingSince = 0; if (ready) report('active'); }
        }
        mask2d.setTransform(1, 0, 0, 1, 0, 0);
        mask2d.clearRect(0, 0, pixelsWide, pixelsHigh);
        const surfaceBox = surface.getBoundingClientRect();
        const matrices = new Map<Element, { matrix: DOMMatrix; inverse: DOMMatrix; font: string; level: number; spacing: number }>();
        const drawn: { x: number; y: number }[] = [];
        for (const slot of slots) {
          const level = glyphLevel(glyphs[slot.glyph], time);
          if (level <= 0 || !slot.node.isConnected) continue;
          let info = matrices.get(slot.element);
          if (!info) {
            const style = getComputedStyle(slot.element);
            const matrix = screenMatrix(slot.element);
            info = { matrix, inverse: matrix.inverse(), font: `${style.fontStyle} ${style.fontWeight} ${style.fontSize} ${style.fontFamily}`, level: visibility(slot.element), spacing: parseFloat(style.letterSpacing) || 0 };
            matrices.set(slot.element, info);
          }
          if (info.level < 0.25) continue;
          range.setStart(slot.node, slot.start); range.setEnd(slot.node, slot.end);
          const box = range.getBoundingClientRect();
          if (!box.width || !box.height) continue;
          // 字的屏幕中心换回元素自身坐标，再连同元素的旋转、缩放一起画，字形方向与原动画一致。
          const center = info.inverse.transformPoint(new DOMPoint(box.left + box.width / 2, box.top + box.height / 2));
          const m = info.matrix;
          mask2d.setTransform(m.a * scale, m.b * scale, m.c * scale, m.d * scale, (m.e - surfaceBox.left) * scale, (m.f - surfaceBox.top) * scale);
          // 字框是文字的内容区（字体上沿到下沿），按字体度量放回基线；左右按字宽加字距居中，与网页排版逐像素对齐。
          const text = slot.node.data.slice(slot.start, slot.end);
          mask2d.font = info.font; mask2d.textAlign = 'left'; mask2d.textBaseline = 'alphabetic';
          const metrics = mask2d.measureText(text);
          const ascent = metrics.fontBoundingBoxAscent ?? metrics.actualBoundingBoxAscent;
          const descent = metrics.fontBoundingBoxDescent ?? metrics.actualBoundingBoxDescent;
          // 原动画里半透明（正在淡入或位于弧线边缘）的字，高光也相应减弱，但不随透明度线性消失，正在唱的字仍明显亮过白色。
          const strength = level * Math.min(1, 0.35 + info.level);
          mask2d.fillStyle = `rgba(255,255,255,${strength.toFixed(3)})`;
          mask2d.fillText(text, center.x - (metrics.width + info.spacing) / 2, center.y + (ascent - descent) / 2);
          drawn.push({ x: (box.left + box.width / 2 - surfaceBox.left) * scale, y: (box.top + box.height / 2 - surfaceBox.top) * scale,
            // 供检查脚本核对：字框大小、元素矩阵缩放与字体（不含任何用户数据）。
            w: box.width, h: box.height, sx: Math.hypot(m.a, m.b), font: info.font, alpha: strength, text });
        }
        (window as any).__foliaHdrGlyphs = drawn;
        const color = /^#[\da-f]{6}$/i.test(tintRef.current) ? tintRef.current : '#a5bfed';
        values[0] = parseInt(color.slice(1, 3), 16) / 255; values[1] = parseInt(color.slice(3, 5), 16) / 255; values[2] = parseInt(color.slice(5, 7), 16) / 255;
        values[4] = pixelsWide; values[5] = pixelsHigh; values[6] = 2.4;
        try {
          graphics.queue.copyExternalImageToTexture({ source: maskCanvas }, { texture: texture! }, [pixelsWide, pixelsHigh]);
          graphics.queue.writeBuffer(uniform, 0, values);
          const commands = graphics.createCommandEncoder();
          const pass = commands.beginRenderPass({ colorAttachments: [{ view: target.getCurrentTexture().createView(),
            clearValue: { r: 0, g: 0, b: 0, a: 0 }, loadOp: 'clear', storeOp: 'store' }] });
          pass.setPipeline(pipeline); pass.setBindGroup(0, binding!); pass.draw(3); pass.end();
          graphics.queue.submit([commands.finish()]);
          lastPaint = now;
          if (!ready) { ready = true; report(slots.length || !glyphs.length ? 'active' : reported ?? 'active'); }
        } catch { fallback(); }
      };

      schedule = () => { if (!stopped && !frame && !document.hidden) frame = requestAnimationFrame(draw); };
      requestDraw.current = schedule;
      const redraw = schedule;
      // 跟随歌词时钟（含同步微调）重画，最多每秒 30 次；暂停时时钟不动，画面也不动。
      unsubscribe = clock.on('change', () => { if (performance.now() - lastPaint >= 1000 / 30) redraw(); });
      observer = new ResizeObserver(redraw);
      observer.observe(surface);
      document.addEventListener('visibilitychange', redraw);
      redraw();
    }

    void start(canvas).catch(fallback);
    return stop;
  }, [hasRange, clock, onStatus]);

  return <canvas ref={canvasRef} className="hdr-glow" aria-hidden="true"/>;
}
