/// <reference types="@webgpu/types" />
import React, { useEffect, useRef, useState } from 'react';
import type { MotionValue } from 'framer-motion';
import type { Line } from './upstream/src/types';
import { buildGlyphs, groupGlyphs, type Glyph } from './styles/glyphs';

export type HdrStatus = 'starting' | 'sdr' | 'unavailable' | 'active';

// 一张字形纹理和一套字。每个字的亮度由播放时间决定，换行前不重新画字。
const shader = `
struct View { tint: vec4f, canvas: vec4f }
@group(0) @binding(0) var<uniform> view: View;
@group(0) @binding(1) var glyphMask: texture_2d<f32>;

struct GlyphVertex {
  @builtin(position) position: vec4f,
  @location(0) @interpolate(flat) timing: vec2f,
  @location(1) column: f32,
}

@vertex fn vertex(@location(0) xy: vec2f, @location(1) timing: vec2f, @location(2) column: f32) -> GlyphVertex {
  let normalized = xy / view.canvas.xy;
  return GlyphVertex(vec4f(normalized.x * 2.0 - 1.0, 1.0 - normalized.y * 2.0, 0.0, 1.0), timing, column);
}

@fragment fn fragment(input: GlyphVertex) -> @location(0) vec4f {
  let alpha = textureLoad(glyphMask, vec2i(input.position.xy), 0).a;
  let elapsed = view.canvas.z - input.timing.x;
  let progress = clamp(elapsed / max(0.01, input.timing.y - input.timing.x), 0.0, 1.0);
  let sung = select(0.0, smoothstep(input.column - 0.12, input.column + 0.02, progress), elapsed > 0.0);
  let after = max(0.0, view.canvas.z - input.timing.y);
  let peak = 2.12 - min(0.65, after * 0.19);
  let white = vec3f(1.0, 0.99, 0.97);
  let base = mix(view.tint.rgb, white, 0.35) * 0.54;
  let bright = mix(view.tint.rgb, white, 0.84) * peak;
  return vec4f(mix(base, bright, sung) * alpha, alpha);
}`;

type Font = { family: string; weight: number; scale: number };
type GlyphBox = Glyph & { x: number; y: number; width: number; height: number };

function drawLine(mask: CanvasRenderingContext2D, line: Line | null, width: number, height: number, font: Font) {
  const glyphs = buildGlyphs(line);
  if (!glyphs.length) return [];
  const groups = groupGlyphs(glyphs);
  const available = width * 0.94;
  let fontSize = Math.min(width * 0.078, height * 0.27, 95) * font.scale;
  let widths: number[] = [];
  let rows: { indices: number[]; width: number }[] = [];

  // 拉丁单词整组换行，遇到超长字词或多行时缩小字号以保持完整。
  for (let attempt = 0; attempt < 5; attempt++) {
    mask.font = `${font.weight} ${fontSize}px ${font.family}`;
    widths = glyphs.map(glyph => mask.measureText(glyph.text).width + fontSize * 0.035);
    rows = [{ indices: [], width: 0 }];
    let widestGroup = 0;
    for (const group of groups) {
      const groupWidth = group.items.reduce((total, index) => total + widths[index], 0);
      widestGroup = Math.max(widestGroup, groupWidth);
      let row = rows[rows.length - 1];
      if (row.indices.length && row.width + groupWidth > available) {
        row = { indices: [], width: 0 };
        rows.push(row);
      }
      row.indices.push(...group.items);
      row.width += groupWidth;
    }
    const fit = Math.min(available / Math.max(1, widestGroup), height * 0.90 / (rows.length * fontSize * 1.36));
    if (fit >= 1 || attempt === 4) break;
    fontSize *= fit * 0.96;
  }

  const rowHeight = fontSize * 1.36;
  const boxes: GlyphBox[] = [];
  mask.textBaseline = 'middle';
  mask.textAlign = 'center';
  mask.fillStyle = '#fff';
  for (const [rowIndex, row] of rows.entries()) {
    let x = (width - row.width) / 2;
    const y = (height - rows.length * rowHeight) / 2 + rowIndex * rowHeight;
    for (const index of row.indices) {
      const glyph = glyphs[index];
      const advance = widths[index];
      if (!glyph.space) {
        mask.fillText(glyph.text, x + advance / 2, y + rowHeight / 2);
        boxes.push({ ...glyph, x, y, width: advance, height: rowHeight });
      }
      x += advance;
    }
  }
  return boxes;
}

function verticesFor(boxes: GlyphBox[]) {
  const vertices = new Float32Array(boxes.length * 6 * 5);
  let offset = 0;
  for (const { x, y, width, height, start, end } of boxes) {
    vertices.set([
      x, y, start, end, 0, x + width, y, start, end, 1, x, y + height, start, end, 0,
      x, y + height, start, end, 0, x + width, y, start, end, 1, x + width, y + height, start, end, 1,
    ], offset);
    offset += 30;
  }
  return vertices;
}

export default function HdrGlow({ tint, clock, line, family, weight, fontScale, visible, onStatus }: {
  tint: string; clock: MotionValue<number>; line: Line | null;
  family: string; weight: number; fontScale: number; visible: boolean; onStatus: (status: HdrStatus) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestDraw = useRef<(() => void) | null>(null);
  const current = useRef({ tint, line, family, weight, fontScale });
  current.current = { tint, line, family, weight, fontScale };
  const [hasRange, setHasRange] = useState(() => matchMedia('(dynamic-range: high)').matches);

  useEffect(() => {
    const range = matchMedia('(dynamic-range: high)');
    const update = () => setHasRange(range.matches);
    range.addEventListener('change', update);
    update();
    return () => range.removeEventListener('change', update);
  }, []);

  useEffect(() => { requestDraw.current?.(); }, [tint, line, family, weight, fontScale]);

  useEffect(() => {
    if (!hasRange) { onStatus('sdr'); return; }
    const canvas = canvasRef.current;
    const gpu = navigator.gpu;
    if (!canvas || !gpu) { onStatus('unavailable'); return; }

    let device: GPUDevice | undefined;
    let context: GPUCanvasContext | null = null;
    let frame = 0;
    let stopped = false;
    let unsubscribe: (() => void) | undefined;
    let observer: ResizeObserver | undefined;
    let schedule: (() => void) | undefined;
    const stop = () => {
      if (stopped) return;
      stopped = true;
      cancelAnimationFrame(frame);
      unsubscribe?.();
      observer?.disconnect();
      if (schedule) document.removeEventListener('visibilitychange', schedule);
      requestDraw.current = null;
      context?.unconfigure();
      device?.destroy();
    };
    const fallback = () => { if (!stopped) { stop(); onStatus('unavailable'); } };

    onStatus('starting');
    async function start(surface: HTMLCanvasElement) {
      const adapter = await gpu.requestAdapter({ powerPreference: 'low-power' });
      if (stopped) return;
      if (!adapter) { fallback(); return; }
      const graphics = await adapter.requestDevice();
      if (stopped) { graphics.destroy(); return; }
      device = graphics;
      context = surface.getContext('webgpu');
      if (!context) { fallback(); return; }
      const target = context;
      void graphics.lost.then(fallback);
      graphics.addEventListener('uncapturederror', event => { event.preventDefault(); fallback(); });
      graphics.pushErrorScope('validation');
      target.configure({ device: graphics, format: 'rgba16float', colorSpace: 'srgb', alphaMode: 'premultiplied', toneMapping: { mode: 'extended' } });
      const configuration = target.getConfiguration?.();
      if (configuration?.format !== 'rgba16float' || configuration.toneMapping?.mode !== 'extended') {
        await graphics.popErrorScope(); fallback(); return;
      }
      const module = graphics.createShaderModule({ code: shader });
      const pipeline = await graphics.createRenderPipelineAsync({
        layout: 'auto',
        vertex: { module, entryPoint: 'vertex', buffers: [{ arrayStride: 20, attributes: [
          { shaderLocation: 0, offset: 0, format: 'float32x2' },
          { shaderLocation: 1, offset: 8, format: 'float32x2' },
          { shaderLocation: 2, offset: 16, format: 'float32' },
        ] }] },
        fragment: { module, entryPoint: 'fragment', targets: [{ format: 'rgba16float' }] },
      });
      if (await graphics.popErrorScope()) { fallback(); return; }
      if (stopped) return;

      const uniform = graphics.createBuffer({ size: 32, usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST });
      const maskCanvas = document.createElement('canvas');
      const mask = maskCanvas.getContext('2d');
      if (!mask) { fallback(); return; }
      const values = new Float32Array(8);
      let texture: GPUTexture | undefined;
      let buffer: GPUBuffer | undefined;
      let binding: GPUBindGroup | undefined;
      let boxes: GlyphBox[] = [];
      let layout: { line: Line | null; font: string; width: number; height: number } | undefined;
      let width = surface.clientWidth, height = surface.clientHeight;
      let lastPaint = -Infinity;
      let ready = false;

      const draw = (now: number) => {
        frame = 0;
        if (stopped || document.hidden) return;
        if (!width || !height) return;
        const ratio = Math.min(window.devicePixelRatio || 1, 1.5, 1280 / Math.max(width, height));
        const pixelsWide = Math.max(1, Math.round(width * ratio));
        const pixelsHigh = Math.max(1, Math.round(height * ratio));
        const { line: activeLine, tint: accent, family: fontFamily, weight: fontWeight, fontScale: size } = current.current;
        const font = `${fontFamily}:${fontWeight}:${size}`;
        const time = clock.get();
        try {
          if (layout?.line !== activeLine || layout.font !== font || layout.width !== pixelsWide || layout.height !== pixelsHigh) {
            if (surface.width !== pixelsWide || surface.height !== pixelsHigh || !texture) {
              surface.width = maskCanvas.width = pixelsWide;
              surface.height = maskCanvas.height = pixelsHigh;
              texture?.destroy();
              texture = graphics.createTexture({ label: 'Folia HDR lyric mask', size: [pixelsWide, pixelsHigh], format: 'rgba8unorm',
                usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST | GPUTextureUsage.RENDER_ATTACHMENT });
              binding = graphics.createBindGroup({ layout: pipeline.getBindGroupLayout(0), entries: [
                { binding: 0, resource: { buffer: uniform } }, { binding: 1, resource: texture.createView() },
              ] });
            }
            mask.clearRect(0, 0, pixelsWide, pixelsHigh);
            boxes = drawLine(mask, activeLine, pixelsWide, pixelsHigh, { family: fontFamily, weight: fontWeight, scale: size });
            if (boxes.length && texture) {
              graphics.queue.copyExternalImageToTexture({ source: maskCanvas }, { texture }, [pixelsWide, pixelsHigh]);
              const vertices = verticesFor(boxes);
              if (!buffer || buffer.size < vertices.byteLength) {
                buffer?.destroy();
                buffer = graphics.createBuffer({ size: vertices.byteLength, usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST });
              }
              graphics.queue.writeBuffer(buffer, 0, vertices);
            }
            layout = { line: activeLine, font, width: pixelsWide, height: pixelsHigh };
          }
          const color = /^#[\da-f]{6}$/i.test(accent) ? accent : '#a5bfed';
          values[0] = parseInt(color.slice(1, 3), 16) / 255;
          values[1] = parseInt(color.slice(3, 5), 16) / 255;
          values[2] = parseInt(color.slice(5, 7), 16) / 255;
          values[4] = pixelsWide;
          values[5] = pixelsHigh;
          values[6] = time;

          // 只有测试脚本请求读回时，才记录实际点亮的字框。
          if ((window as any).hdrSample === 'request') {
            (window as any).__foliaHdrGlyphs = boxes.filter(box => time > box.start).map(box => ({
              x: box.x + box.width / 2, y: box.y + box.height / 2,
              alpha: Math.min(1, (time - box.start) / Math.max(0.01, box.end - box.start)),
            }));
          }
          graphics.queue.writeBuffer(uniform, 0, values);
          const commands = graphics.createCommandEncoder();
          const pass = commands.beginRenderPass({ colorAttachments: [{ view: target.getCurrentTexture().createView(),
            clearValue: { r: 0, g: 0, b: 0, a: 0 }, loadOp: 'clear', storeOp: 'store' }] });
          if (boxes.length && binding && buffer) {
            pass.setPipeline(pipeline);
            pass.setBindGroup(0, binding);
            pass.setVertexBuffer(0, buffer);
            pass.draw(boxes.length * 6);
          }
          pass.end();
          graphics.queue.submit([commands.finish()]);
          lastPaint = now;
          if (!ready) { ready = true; onStatus('active'); }
        } catch { fallback(); }
      };

      schedule = () => { if (!stopped && !frame && !document.hidden) frame = requestAnimationFrame(draw); };
      requestDraw.current = schedule;
      const redraw = schedule;
      unsubscribe = clock.on('change', () => { if (performance.now() - lastPaint >= 1000 / 30) redraw(); });
      observer = new ResizeObserver(([entry]) => {
        width = entry.contentRect.width;
        height = entry.contentRect.height;
        redraw();
      });
      observer.observe(surface);
      document.addEventListener('visibilitychange', redraw);
      redraw();
    }

    void start(canvas).catch(fallback);
    return stop;
  }, [hasRange, clock, onStatus]);

  return <canvas ref={canvasRef} className="hdr-glow" aria-hidden="true" style={{ visibility: visible ? 'visible' : 'hidden' }}/>;
}
