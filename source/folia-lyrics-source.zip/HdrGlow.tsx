import { useEffect, useState } from 'react';

const HDR_DISPLAY = '(dynamic-range: high)';
const HDR_STYLES = new Set(['classic', 'partita', 'tilt', 'ink', 'vertical', 'orbit']);
const hdrWhiteUrl = new URL('./standalone/hdr-lyric-white.jpg', import.meta.url).href;
export const hdrGlyphImage = `url("${hdrWhiteUrl}")`;

type ImageStatus = 'starting' | 'unavailable' | 'active';

export function useHdrGlyphFill(enabled: boolean, mode: string) {
  const [highRange, setHighRange] = useState(false);
  const [imageStatus, setImageStatus] = useState<ImageStatus>('starting');
  const supported = HDR_STYLES.has(mode);

  useEffect(() => {
    if (!enabled) return;
    const display = window.matchMedia(HDR_DISPLAY);
    const update = () => setHighRange(display.matches);
    update();
    display.addEventListener('change', update);
    return () => display.removeEventListener('change', update);
  }, [enabled]);

  useEffect(() => {
    if (!enabled || !supported || !highRange || imageStatus !== 'starting') return;
    if (!CSS.supports('background-clip', 'text') && !CSS.supports('-webkit-background-clip', 'text')) {
      setImageStatus('unavailable');
      return;
    }
    const image = new Image();
    image.src = hdrWhiteUrl;
    let cancelled = false;
    image.decode().then(
      () => { if (!cancelled) setImageStatus('active'); },
      () => { if (!cancelled) setImageStatus('unavailable'); },
    );
    return () => { cancelled = true; };
  }, [enabled, supported, highRange, imageStatus]);

  if (!enabled) return 'starting';
  if (!supported) return 'unsupported';
  if (!highRange) return 'sdr';
  return imageStatus;
}
